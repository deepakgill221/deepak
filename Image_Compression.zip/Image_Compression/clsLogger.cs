﻿using log4net;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Image_Compression
{
    public class clsLogger
    {
        private static readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public void InitializeLogFile(int Process)
        {
            try
            {
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\Log_Process_" + Process + ".xls"))
                {

                    File.Move(AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\Log_Process_" + Process + ".xls", AppDomain.CurrentDomain.BaseDirectory + "\\Bkp_Logs\\Logs_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".xls");

                    File.Delete(AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\Log_Process_" + Process + ".xls");
                    logger.Info("Previous log moved to backup folder");
                }
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (xlApp == null)
                {
                    //MessageBox.Show("Excel is not properly installed!!");
                    return;
                }
                else
                {
                    Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                    Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                    object misValue = System.Reflection.Missing.Value;
                    xlWorkBook = xlApp.Workbooks.Add(misValue);
                    xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                    xlWorkSheet.Cells[1, 1] = "PolicyNo";
                    //xlWorkSheet.Cells[1, 2] = "Image";
                    xlWorkSheet.Cells[1, 2] = "Time";
                    xlWorkSheet.Cells[1, 3] = "FileName";
                    xlWorkSheet.Cells[1, 4] = "Description";

                    xlWorkBook.SaveAs(AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\Log_Process_" + Process + ".xls", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                    xlWorkBook.Close(true, misValue, misValue);
                    xlApp.Quit();

                    Marshal.ReleaseComObject(xlWorkSheet);
                    Marshal.ReleaseComObject(xlWorkBook);
                    Marshal.ReleaseComObject(xlApp);
                    logger.Info("Excel for log created");


                }


            }
            catch (Exception ex)
            {
                logger.Info("Errore while creating excel log file");
            }
        }

        public void WriteLogs(string policyNo, string Description, string filename,int  Process)
        {
            string fileName = AppDomain.CurrentDomain.BaseDirectory.ToString() + @"Logs\Log_Process_"+Process+".xls";

            using (OleDbConnection cn = MyCon(fileName))
            {
                try
                {
                    cn.Open();
                    OleDbCommand cmd1 = new OleDbCommand("INSERT INTO [Sheet1$] " +
                         "([PolicyNo],[Time],[FileName],[Description]) " +
                         "VALUES(@PolicyNo, @date,@filename,@Description)", cn);
                    cmd1.Parameters.AddWithValue("@PolicyNo", policyNo.ToString());
                    //    cmd1.Parameters.AddWithValue("@imageName", imageName.ToString());
                    cmd1.Parameters.AddWithValue("@date", DateTime.Now.ToString());
                    //cmd1.Parameters.AddWithValue("@Description", Description.ToString());
                    if (filename.ToString().Length > 255)
                        cmd1.Parameters.AddWithValue("@filename", filename.ToString().Substring(0, 255));
                    else
                        cmd1.Parameters.AddWithValue("@filename", filename.ToString());

                    if (Description.ToString().Length > 255)
                        cmd1.Parameters.AddWithValue("@Description", Description.ToString().Substring(0, 255));
                    else
                        cmd1.Parameters.AddWithValue("@Description", Description.ToString());

                    cmd1.ExecuteNonQuery();
                    cn.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

        }

        public static OleDbConnection MyCon(string FilePath)
        {
            OleDbConnection con;
            if ((FilePath.Contains("xlsx")))
            {
                con = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + "'" + FilePath + "'" + ";Mode=ReadWrite;Extended Properties=\"Excel 12.0 Xml;HDR=YES;IMEX=1\"");
            }
            else
            {
                con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" + "'" + FilePath + "'" + "; Extended Properties=Excel 8.0;");
            }

            return con;
        }

        bool status_Photofile;
        public bool FileStatus
        {
            get
            {
                return status_Photofile;
            }
            set
            {
                status_Photofile = value;
            }
        }

    }
}
