package com.lead.agent.commons;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

/**
 * @author ad01084
 *
 */
@Service
public class DataFromJson 
{
	private static Logger logger = LogManager.getLogger(DataFromJson.class);

	/**
	 * @param object 
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	private static final String RESULT ="result";
	private static final String PARAMETERS ="parameters";
	private static final String NAME = "name";
	private static final String GENDER = "gender";
	private static final String CUSTOMERNAME ="customername";
	private static final String EMAIL ="email";
	private static final String MOBILENUM ="mobilenum";
	private static final String DATE ="date";
	private static final String SMOKE ="smoke";
	
	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String customerNameVariable(JSONObject object, String sessionId,
			Map<String, Map<String, String>> externalMap) {
		String name;
		if (externalMap.containsKey(sessionId)) {
			try {
				name = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(CUSTOMERNAME) + "";
				String[] str = name.split(" ");
				name = str[0];
				name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
				externalMap.get(sessionId).put(NAME, name);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer name from json when session id exist : "+sessionId+" : " + e);
				name = "";
			}
		} else {
			try {
				name = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(CUSTOMERNAME) + "";
				String[] str = name.split(" ");
				name = str[0];
				name = name.substring(0, 1).toUpperCase() + name.substring(1).toLowerCase();
				externalMap.get(sessionId).put(NAME, name);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer name from json : " + e);
				name = "";
			}
		}
		return name;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String genderVariable(JSONObject object, String sessionId, Map<String, Map<String, String>> externalMap) {
		final String male="M";
		final String female="F";
		String genderStr;
		if (externalMap.containsKey(sessionId)) {
			try {
				genderStr = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(GENDER) + "";
				if ("male".equalsIgnoreCase(genderStr)) {
					genderStr = male;
					externalMap.get(sessionId).put(GENDER, genderStr);
				} else {
					genderStr = female;
					externalMap.get(sessionId).put(GENDER, genderStr);
				}
			} catch (Exception e) {
				logger.error("We face Exception while getting gender from json when session id exist : "+sessionId+" : " + e);
				genderStr = "";
			}
		} else {
			try {
				genderStr = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(GENDER) + "";
				if ("male".equalsIgnoreCase(genderStr)) {
					genderStr = male;
					externalMap.get(sessionId).put(GENDER, genderStr);
				} else {
					genderStr = female;
					externalMap.get(sessionId).put(GENDER, genderStr);
				}
			} catch (Exception e) {
				logger.error("We face Exception while getting gender from json" + e);
				genderStr = "";
			}
		}
		return genderStr;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String emailVariable(JSONObject object, String sessionId, Map<String, Map<String, String>> externalMap) {
		String custEmail;
		if (externalMap.containsKey(sessionId)) {
			try {
				custEmail = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(EMAIL) + "";
				custEmail = custEmail.replaceAll("\\s", "");
				externalMap.get(sessionId).put("custEmail", custEmail);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer email from json when session id exist : "+sessionId+" : " + e);
				custEmail = "";
			}
		} else {
			try {
				custEmail = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(EMAIL) + "";
				custEmail = custEmail.replaceAll("\\s", "");
				externalMap.get(sessionId).put("custEmail", custEmail);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer email from json" + e);
				custEmail = "";
			}
		}
		return custEmail;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String mobileVariable(JSONObject object, String sessionId, Map<String, Map<String, String>> externalMap) {
		String mobileNum;
		if (externalMap.containsKey(sessionId)) {
			try {
				mobileNum = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(MOBILENUM) + "";
				externalMap.get(sessionId).put(MOBILENUM, mobileNum);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer mobileNum from json when session id exist : "+sessionId+" : " + e);
				mobileNum = "";
			}
		} else {
			try {
				mobileNum = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(MOBILENUM) + "";
				externalMap.get(sessionId).put(MOBILENUM, mobileNum);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer mobileNum from json" + e);
				mobileNum = "";
			}
		}
		return mobileNum;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String dateVariable(JSONObject object, String sessionId, Map<String, Map<String, String>> externalMap) {
		String date;
		if (externalMap.containsKey(sessionId)) {
			try 
			{
				date = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(DATE) + "";
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat sdfFormat = new SimpleDateFormat("dd-MM-yyyy");
				Date date1 = sdf.parse(date);
				String strDate1 = sdfFormat.format(date1);
				date = strDate1;
				externalMap.get(sessionId).put(DATE, date);
			} catch (Exception e) {
				logger.error("We face Exception while getting customer date from json when session id exist : "+sessionId+" : " + e);
				date = "";
			}
		} else {
			try {
				date = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(DATE) + "";
			} catch (Exception e) {
				logger.error("We face Exception while getting date from json" + e);
				date = "";
			}
		}
		return date;
	}

	/**
	 * @param object
	 * @param sessionId
	 * @param externalMap
	 * @return
	 */
	public String smokeVariable(JSONObject object, String sessionId, Map<String, Map<String, String>> externalMap) {
		String smoke;
		if (externalMap.containsKey(sessionId)) {
			try {
				smoke = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(SMOKE) + "";
				if ("smoker".equalsIgnoreCase(smoke) || "Yes".equalsIgnoreCase(smoke)
						|| SMOKE.equalsIgnoreCase(smoke)) {
					smoke = "Y";
					externalMap.get(sessionId).put(SMOKE, smoke);
				} else {
					smoke = "N";
					externalMap.get(sessionId).put(SMOKE, smoke);
				}
			} catch (Exception e) {
				logger.error("We face Exception while getting customer smoke from json when session id exist : "+sessionId+" : " + e);
				smoke = "";
			}
		} else {
			try {
				smoke = object.getJSONObject(RESULT).getJSONObject(PARAMETERS).get(SMOKE) + "";
			} catch (Exception e) {
				logger.error("We face Exception while getting smoke from json" + e);
				smoke = "";
			}
		}
		return smoke;
	}
}
