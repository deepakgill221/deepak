package com.lead.agent.service;

import com.lead.agent.response.WebhookResponse;

/**
 * @author ad01084
 *
 */
public interface LeadBotService 
{
	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 */
	public WebhookResponse leadBotProcess(String jsonStr);
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	public void removeUnUsedSessionFromCache();
}
