package com.lead.agent.controller;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.lead.agent.response.WebhookResponse;
import com.lead.agent.service.LeadBotService;

/**
 * @author ad01084
 *
 */
@RestController
@RequestMapping("/leadAgent")
public class Controller {
	private static Logger logger = LogManager.getLogger(Controller.class);
	@Autowired
	private LeadBotService leadBotService;
	/**
	 * Schedular is configured to run on every 10Min and remove all un-used session's from cache
	 * i.e. those sessions which are ideal from past 10 Min.
	 */
	@Scheduled(cron = "0 0/10 * * * ?")
	public void removeCashethirtyminute() 
	{
		logger.info("Cron job to remove un-used session from cache : Start");
		leadBotService.removeUnUsedSessionFromCache();
	}

	/**
	 * @param jsonStr : Request data in JSON Format
	 * @return
	 */
	@RequestMapping(method = RequestMethod.POST)
	public WebhookResponse webhook(@RequestBody String jsonStr) 
	{
		logger.info("LeadBotProcess Start");
		return leadBotService.leadBotProcess(jsonStr);
	}

}
