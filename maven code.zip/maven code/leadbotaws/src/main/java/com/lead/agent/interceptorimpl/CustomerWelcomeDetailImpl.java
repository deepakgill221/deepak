package com.lead.agent.interceptorimpl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.lead.agent.interceptor.CustomerWelcomeDetail;

/**
 * @author ad01084
 *
 */
@Service
public class CustomerWelcomeDetailImpl implements CustomerWelcomeDetail
{
	String speech="";
	/** (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	@Override
	public String welcomeCall(Map<String,Map<String,String>> map, String sessionId) 
	{
		speech=" Hi, Thanks for showing interest in Max Life Term insurance. I am your online assistant."; 
		if("second".equalsIgnoreCase(map.get(sessionId).get("name")+""))
		{
			speech="I need a few details to calculate customised premium for you.\n Please share your first name.";
		}
		return speech;
	}

}
