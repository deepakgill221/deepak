package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class Ntued 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(PaidCases.class);
	public String ntuedIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		else
		{
			finalresponse="As of "+bean.getBTCH_TIMSTAMP()+
					" Your total count of NTU policies is " +bean.getNtu_policy_count()
					+ " for this month, with AFYP Rs."+bean.getNtu_policy_afyp()+" Lacs.";
					
		}
		System.out.println("Ntued--"+ finalresponse);
		logger.info("Ntued--"+ finalresponse);
		return finalresponse;
	}
}
