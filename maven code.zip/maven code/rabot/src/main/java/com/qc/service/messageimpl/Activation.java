package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class Activation 
{
	String finalresponse="";
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(Activation.class);
	public String activationIntent(String channel)
	{
		if("Axis Bank".equalsIgnoreCase(channel))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+" Activation % MTD is "+bean.getActivisa_mtd_prcntg()+"%. "
					+ "Total Manmonth is : "+bean.getActivisa_mtd_manmonth()+" and Active is "+bean.getActivisa_mtd_active(); 
		}
		else if("BancAssurance".equalsIgnoreCase(channel))
		{
           finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()+" Activation % MTD is "+bean.getActivisa_mtd_prcntg()+"%."
           		+ " Total Manmonth is : "+bean.getActivisa_mtd_manmonth()+" and Active is "+bean.getActivisa_mtd_active(); 
		}
		else{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		logger.info("Activation :- "+finalresponse);
		return finalresponse;
	}
}
