package com.qc.service.messageimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class GPA 
{
	@Autowired
	private Bean bean;
	String finalresponse="";
	public String gpaIntent(String channel)
	{
		if("BancAssurance".equalsIgnoreCase(channel))
		{
		   finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+", Your GPA score is : "+bean.getGpa_score();	
		}
		else if("Agency".equalsIgnoreCase(channel))
		{
			finalresponse=" As of "+bean.getREAL_TIM_TIMSTAMP()+", Your GPA score is :"+bean.getAdm_tot_gpa_scor_extra_credit();
		}
		else
		{
			finalresponse="Not Applicable for "+channel+" channel";
		}
		return finalresponse;
	}
}
