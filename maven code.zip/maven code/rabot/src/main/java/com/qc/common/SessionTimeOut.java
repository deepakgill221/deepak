package com.qc.common;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qc.common.CalculateTimeDiff;
import com.qc.controller.RABotController;

@Service
public class SessionTimeOut {
	@Autowired
	private CalculateTimeDiff calculateTimeDiff;
	public void cashRemovetimeout()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		for(Map.Entry<String, Map<String, String>> entry : RABotController.sessionMapcontainssoinfo.entrySet())
		{
			String keytoremove = entry.getKey();
			Map<String,String> valueMap = entry.getValue();
			for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
			{
				if(getKeyValueMap.getKey().contains("loginTime"))
				{
					String logntimevalue = getKeyValueMap.getValue();
					String currentTime = dtf.format(now);
					long diffminutes = calculateTimeDiff.timediff(currentTime, logntimevalue);
					if(diffminutes > 30)
					{
						RABotController.sessionMapcontainssoinfo.remove(keytoremove);
					}
					break;
				}
			}
		}
	}
}
