package com.qc.service.messageimpl;

import java.text.DecimalFormat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class WIPCases 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(WIPCases.class);
	public String wipCasesIntent(JSONObject object, String wipyes)
	{
		String finalresponse="";
		double wip_Count=0;
		double wip_ADJ_MFYP=0;
		double wip_ADJ_MFYP1=0;
		String real_TIM_TIMSTAMP="";
		
		double wipAfyp=0;
		double hoWipAfyp=0;
		double goWipAfyp=0;
		double itWipAfyp=0;
		double finWipAfyp=0;
		double miscWipAfyp=0;
		double welcomeWipAfyp=0;
		double hoWipCount=0;
		double goWipCount=0;
		double itWipCount=0;
		double finWipCount=0;
		double miscWipCount=0;
		double welcomeWipCount=0;
		
		double hoWipAdjMfyp=0;
		double goWipAdjMfyp=0;
		double itWipAdjMfyp=0;
		double finWipAdjMfyp=0;
		double miscWipAdjMfyp=0;
		double welcomeWipAdjMfyp=0;
		
		String location="";
		
		DecimalFormat df = new DecimalFormat("####");
		StringBuffer message = new StringBuffer();
		try{
			JSONArray array=object.getJSONObject("payload").getJSONArray("wipCases");
			{
				for(int i=0; i<array.length();i++)
				{
					if("".equalsIgnoreCase(wipyes))
					{
						try{
							wip_Count=wip_Count+Double.parseDouble(array.getJSONObject(i).get("wip_COUNT")+"");
						}catch(Exception ex)
						{
							wip_Count=0;
						}
						try{
							wip_ADJ_MFYP=wip_ADJ_MFYP+Double.parseDouble(array.getJSONObject(i).get("wip_ADJ_MFYP")+"");
						}catch(Exception ex)
						{
							wip_ADJ_MFYP=0;
						}
						try{
							real_TIM_TIMSTAMP=array.getJSONObject(i).get("real_TIM_TIMSTAMP")+"";
						}catch(Exception ex)
						{
							real_TIM_TIMSTAMP="";
						}
					}
					else
					{
						try{
							wip_ADJ_MFYP1=wip_ADJ_MFYP1+Double.parseDouble(array.getJSONObject(i).get("wip_ADJ_MFYP")+"");
						}catch(Exception ex)
						{
							wip_ADJ_MFYP1=0;
						}
						try{
							wipAfyp=Double.parseDouble(array.getJSONObject(i).get("wipAfyp")+"");
						}catch(Exception ex)
						{
							wipAfyp=0;
						}
						try{
							hoWipAfyp=Double.parseDouble(array.getJSONObject(i).get("hoWipAfyp")+"");
						}catch(Exception ex)
						{
							hoWipAfyp=0;
						}
						try{
							goWipAfyp=Double.parseDouble(array.getJSONObject(i).get("goWipAfyp")+"");
						}catch(Exception ex)
						{
							goWipAfyp=0;
						}
						try{
							itWipAfyp=Double.parseDouble(array.getJSONObject(i).get("itWipAfyp")+"");
						}catch(Exception ex)
						{
							itWipAfyp=0;
						}
						try{
							finWipAfyp=Double.parseDouble(array.getJSONObject(i).get("finWipAfyp")+"");
						}catch(Exception ex)
						{
							finWipAfyp=0;
						}
						try{
							miscWipAfyp=Double.parseDouble(array.getJSONObject(i).get("miscWipAfyp")+"");
						}catch(Exception ex)
						{
							miscWipAfyp=0;
						}
						try{
							welcomeWipAfyp=Double.parseDouble(array.getJSONObject(i).get("welcomeWipAfyp")+"");
						}catch(Exception ex)
						{
							welcomeWipAfyp=0;
						}
						try{
							hoWipCount=Double.parseDouble(array.getJSONObject(i).get("hoWipCount")+"");
						}catch(Exception ex)
						{
							hoWipCount=0;
						}
						try{
							goWipCount=Double.parseDouble(array.getJSONObject(i).get("goWipCount")+"");
						}catch(Exception ex)
						{
							goWipCount=0;
						}
						try{
							itWipCount=Double.parseDouble(array.getJSONObject(i).get("itWipCount")+"");
						}catch(Exception ex)
						{
							itWipCount=0;
						}
						try{
							finWipCount=Double.parseDouble(array.getJSONObject(i).get("finWipCount")+"");
						}catch(Exception ex)
						{
							finWipCount=0;
						}
						try{
							miscWipCount=Double.parseDouble(array.getJSONObject(i).get("miscWipCount")+"");
						}catch(Exception ex)
						{
							miscWipCount=0;
						}
						
						try{
							welcomeWipCount=Double.parseDouble(array.getJSONObject(i).get("welcomeWipCount")+"");
						}catch(Exception ex)
						{
							welcomeWipCount=0;
						}
						try{
							hoWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("hoWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							hoWipAdjMfyp=0;
						}
						try{
							goWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("goWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							goWipAdjMfyp=0;
						}
						try{
							itWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("itWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							itWipAdjMfyp=0;
						}
						try{
							finWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("finWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							finWipAdjMfyp=0;
						}
						try{
							miscWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("miscWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							miscWipAdjMfyp=0;
						}
						try{
							welcomeWipAdjMfyp=Double.parseDouble(array.getJSONObject(i).get("welcomeWipAdjMfyp")+"");
						}catch(Exception ex)
						{
							welcomeWipAdjMfyp=0;
						}
						
						try{
							location=array.getJSONObject(i).get("wip_STAGE")+"";
						}catch(Exception ex)
						{
							location="";
						}
						//if("HO".equalsIgnoreCase(location)||"GO".equalsIgnoreCase(location)||"FIN".equalsIgnoreCase(location)
							//	||"IT".equalsIgnoreCase(location) ||"MISC".equalsIgnoreCase(location)||"WELCOME".equalsIgnoreCase(location))
						//{
							message.append(/*location+": WIP ADJ MFYP "+wip_ADJ_MFYP1+", "+"\n\n HO WIP Adj MFYP: "*/"HO WIP Adj MFYP: "+hoWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(hoWipCount)+" "
									+"\n\n GO WIP Adj MFYP: "+goWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(goWipCount)+" "
									+"\n\n IT WIP Adj MFYP: "+itWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(itWipCount)+" "
									+"\n\n FIN WIP Adj MFYP: "+finWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(finWipCount)+" "
									+"\n\n MISC WIP Adj MFYP: "+miscWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(miscWipCount)+" "
									+"\n\n WELCOME WIP Adj MFYP: "+welcomeWipAdjMfyp+" " + "Lacs" +". and Policies "+df.format(welcomeWipCount)+"");
							
						/*}
						else
						{
							message.append(", "+location+": WIP ADJ MFYP "+wip_ADJ_MFYP1);
						}*/
					}
				}
			}
		}catch(Exception ex)
		{
			finalresponse="Somthing went wrong in wip logic, Please contact to concern team.";
		}
		if("".equalsIgnoreCase(wipyes))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel()) || "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
			else
			{
				finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
						+" Your current WIP is "+wip_Count+" policies with AFYP "+wip_ADJ_MFYP+" Lacs."
						+" Do you wish to see the stage wise data?";
			}
		}
		else
		{
			finalresponse=message.toString();
		}
		logger.info("WIPCases--"+ finalresponse);
		return finalresponse;
	}
}
