package com.qc.api.response;

import java.io.Serializable;

public class WebhookResponse implements Serializable 
{
	private static final long serialVersionUID = 2961398315239217695L;
	
	  String speech;
	  String displayText;
	  
	public WebhookResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WebhookResponse(String speech, String displayText) {
		super();
		this.speech = speech;
		this.displayText = displayText;
	}


	public String getSpeech() {
		return speech;
	}


	public void setSpeech(String speech) {
		this.speech = speech;
	}


	public String getDisplayText() {
		return displayText;
	}


	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}
	 
	
}
