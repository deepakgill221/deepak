package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class RenewalPremium 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(RenewalPremium.class);
	public String renewalPremiumIntent(String policyNumber)
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		else
		{
			finalresponse="The renewal Premium for "+policyNumber+" is Rs "+bean.getPol_renewal_prm();
		}
		logger.info("RenewalPremium--"+ finalresponse);
		return finalresponse;
	}
}
