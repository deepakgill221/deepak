package com.qc.api.service;


import com.qc.api.response.WebhookResponse;

public interface APIConsumerService {
	
	public WebhookResponse getWipDataAll(String action, String channel, String period, String policyNumber,
			String user_ssoid,  String user_sub_channel, String sessionId, String source, String raAdmAgtId, String customerName);
	
}



