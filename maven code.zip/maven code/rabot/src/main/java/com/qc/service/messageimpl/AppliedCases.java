package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class AppliedCases 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(AppliedCases.class);
	public String appliedCasesIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			 +" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		else
		{
			finalresponse="As of "+bean.getREAL_TIM_TIMSTAMP()
			+" Your total count of Applied Cases FTD is "+bean.getApplied_count_ftd()+", MTD is "+bean.getApplied_count_mtd()
					+ ", QTD is "+bean.getApplied_count_qtd()+", YTD is "+bean.getApplied_count_ytd()+".";
		}
		logger.info("AppliedCases--"+ finalresponse);
		return finalresponse;
	}

}
