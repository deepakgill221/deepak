package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class Mpersistency 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(Mpersistency.class);
	public String mPersistencyIntent(String segmentAction)
	{
		String finalresponse="";
		if("FLS.MPERSISTENCY".equalsIgnoreCase(segmentAction))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency acheivement is "+bean.getAchievement_13m_pers()
				+"% for collected amount Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs against collectable amount "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			logger.info("WelcomeCallingStatus--"+ finalresponse);
			
		}
		else if("FLS.MPERSISTENCYBASE".equalsIgnoreCase(segmentAction))
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency base is Rs. "+bean.getTotal_base_13m_pers()+" Lacs.";
			}
			logger.info("WelcomeCallingStatus--"+ finalresponse);
		}
		else
		{
			if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
				
			}
			else if("Agency".equalsIgnoreCase(bean.getChannel()))
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
			}
			else
			{
				finalresponse="As of "+bean.getBTCH_TIMSTAMP()+", Your 13M Persistency unpaid base is Rs. "+bean.getUnpaid_base_13m_pers()+" Lacs.";
			}
			logger.info("WelcomeCallingStatus--"+ finalresponse);
		}
		return finalresponse;
	}
}
