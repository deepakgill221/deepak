/*package com.qc.api.dao.impl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.qc.api.dao.APIConsumerDao;
import com.qc.api.entity.WipEntity;
import com.qc.api.service.impl.BotApiServiceImpl;

@Repository
@Transactional
public class APIConsumerDaoImpl implements APIConsumerDao 
{
	private static Logger logger = LogManager.getLogger(APIConsumerDaoImpl.class);
	
	@Autowired
	private LocalSessionFactoryBean sessionFactory;

	public Session getSession() {
		return sessionFactory.getObject().getCurrentSession();
	}
	@Override
	public String insertWipEntity(WipEntity entity) 
	{
		logger.info("Came Inside to Insert DATA Method");
		try {
			getSession().save(entity);
		} catch (Exception e) {
			logger.info(e);
		}
		logger.info("OutSide to Insert DATA Method");
		return "success";
	}
}

*/