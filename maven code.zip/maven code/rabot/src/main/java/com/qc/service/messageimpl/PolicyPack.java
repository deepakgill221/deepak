package com.qc.service.messageimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.entity.Bean;

@Service
public class PolicyPack 
{
	@Autowired
	private Bean bean;
	private static Logger logger = LogManager.getLogger(PolicyPack.class);
	public String policyPackIntent()
	{
		String finalresponse="";
		if("Axis Bank".equalsIgnoreCase(bean.getChannel())|| "YBL".equalsIgnoreCase(bean.getSub_channel()))
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		else if("Agency".equalsIgnoreCase(bean.getChannel()))
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		else
		{
			finalresponse="The policy pack for policy "+bean.getPolicy_number()+" has been delivered on "
					+bean.getPol_pack_delvry_dt();
		}
		System.out.println("PolicyPack--"+ finalresponse);
		logger.info("PolicyPack--"+ finalresponse);
		return finalresponse;
	}
}
