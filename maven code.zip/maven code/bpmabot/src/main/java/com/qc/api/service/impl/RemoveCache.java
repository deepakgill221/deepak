package com.qc.api.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class RemoveCache 
{
	
	public static void main(String []args)
//	public void removeCache(String action, String sessionId)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm");
		Calendar cal =null;
		int weekDay=0;
		int weekMin=0;
		int weekHr=0;
		cal=Calendar.getInstance();
		weekDay = cal.get(Calendar.DAY_OF_WEEK);//get the Weekday , from 1 to 7
		weekHr = cal.get(Calendar.HOUR_OF_DAY);//get the Weekday , from 0 to 23
		weekMin = cal.get(Calendar.MINUTE);
		//System.out.println("Week Hrs:-"+weekHr+", Week Min:-"+weekMin);	
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
      //  System.out.println(timestamp);
        System.out.println(sdf.format(timestamp));
	}

}
