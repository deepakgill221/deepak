package com.qc.api.service;

public interface BpmaBotHelperService
{
	public String randomNumber();
}
