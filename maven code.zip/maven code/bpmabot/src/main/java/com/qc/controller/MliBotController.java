package com.qc.controller;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.response.WebhookResponse;
import com.qc.api.service.MliBotService;
import com.qc.utils.SessionTimeOut;

@RestController
public class MliBotController 
{
	private static Logger logger = LogManager.getLogger(MliBotController.class);
	public static Map<String, Map<String, String>> sessionMapcontainssoinfo = new ConcurrentHashMap<String, Map<String, String>>();

	@Autowired private SessionTimeOut sessiontimeOut;
	
	@Autowired private MliBotService mliBotService;
	
	@Scheduled(cron="0 0/15 * * * ?")
	public void removeCashethirtyminute()
	{

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		logger.info("Cash Removed :: START---"+dtf.format(now));
		sessiontimeOut.cashRemovetimeout();
		logger.info("Cash Removed :: END---"+dtf.format(now));
	}
	@RequestMapping(value = "/webhook", method = RequestMethod.POST, consumes = { "application/json" }, produces = {"application/json" })

	public @ResponseBody WebhookResponse webhook(@RequestBody String obj,  Model model, HttpSession httpSession) 
	{
		logger.info("CameInside :- Controller: Webhook");
		
		WebhookResponse responseObj = mliBotService.getBpmaData(obj);
		
		return responseObj;
		
	}
		
}
