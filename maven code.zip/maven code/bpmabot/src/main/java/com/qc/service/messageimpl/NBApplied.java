package com.qc.service.messageimpl;

public class NBApplied 
{
	public static String nbAppliedIntent(String channel, String period, String user_circle, String user_region, String userzone, 
			String real_tim_timstamp, String mtdAppliedAFYP, String ytd_applied_afyp, String daily_inforced_count, String subchannel,
			String user_clusters, String user_go, String LacsCr)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{
			channel="";
		}
		if("Monthly".equalsIgnoreCase(period))
		{
			period="";
		}else
		{
			period=period.toUpperCase();
		}if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Go "+user_go;
		}
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}

		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for MLI is  "
					+ mtdAppliedAFYP + " " + LacsCr +" Applied Business AFYP YTD for MLI is " + ytd_applied_afyp + 
					" If you want to see the channel wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + channel +
						" is " + mtdAppliedAFYP + " " + LacsCr +" Applied Business AFYP YTD for " +channel + " is "+ ytd_applied_afyp +
						"If you want to see the data for sub-channels, please enter sub-channel name � Defence, Office within office, APC, Greenfield.";
			}
			else{
				finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + channel +
						" is " + mtdAppliedAFYP + " " + LacsCr +" Applied Business AFYP YTD for " +channel + " is "+ ytd_applied_afyp +
						" If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + userzone + " zone is "
					+ mtdAppliedAFYP + " " + LacsCr +" Applied Business AFYP YTD for " + userzone + " zone is " + ytd_applied_afyp +
					" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + user_region + " is " 
					+ mtdAppliedAFYP + " Applied Business AFYP YTD for " + user_region + " is " + ytd_applied_afyp + " " + LacsCr;

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + user_clusters + " is " 
					+ mtdAppliedAFYP + " Applied Business AFYP YTD for " + user_clusters + " is " + ytd_applied_afyp + " " + LacsCr;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + user_clusters + " is " 
					+ mtdAppliedAFYP + " Applied Business AFYP YTD for " + user_clusters + " is " + ytd_applied_afyp + " " + LacsCr;

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + user_clusters + " is " 
					+ mtdAppliedAFYP + " Applied Business AFYP YTD for " + user_clusters + " is " + ytd_applied_afyp + " " + LacsCr;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " + real_tim_timstamp + " Applied Business AFYP MTD for " + user_region + " is " 
					+ mtdAppliedAFYP + " Applied Business AFYP YTD for " + user_region + " is " + ytd_applied_afyp + " " + LacsCr;

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " + real_tim_timstamp + " Applied Business AFYP " + period + " for " +channel+ " is " +ytd_applied_afyp+
						" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " + real_tim_timstamp + " Applied Business AFYP " + period + " for " +channel+ " is " +mtdAppliedAFYP+
						" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}else
			{
				finalresponse="As of " + real_tim_timstamp + " Applied Business AFYP " + period + " for " +channel+ " is " +daily_inforced_count+
						" " + LacsCr +". If you want to see the Zone/Region wise business numbers, please specify the same.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " +userzone+ " zone is " +ytd_applied_afyp+
						" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " +userzone+ " zone is " +mtdAppliedAFYP+
						" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " +userzone+ " zone is " +daily_inforced_count+
						" " + LacsCr +". If you want to see the region wise business numbers, please specify the same.";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +ytd_applied_afyp+ " " + LacsCr;
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +mtdAppliedAFYP+ " " + LacsCr;
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +daily_inforced_count+ " " + LacsCr;
			}
		}
		/*--------------------------------------Channel & GO------start----------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +ytd_applied_afyp+ " " + LacsCr;
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +mtdAppliedAFYP+ " " + LacsCr;
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +daily_inforced_count+ " " + LacsCr;
			}
		}
		/*---------------added by bhavneet*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +ytd_applied_afyp+ " " + LacsCr;
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +mtdAppliedAFYP+ " " + LacsCr;
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +daily_inforced_count+ " " + LacsCr;
			}
		}
		/*--------------------------------------Channel & GO----------end------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +ytd_applied_afyp+ " " + LacsCr;
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +mtdAppliedAFYP+ " " + LacsCr;
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_region+ " is " +daily_inforced_count+ " " + LacsCr;
			}
		}
		/*-----------------------------------------start----------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +ytd_applied_afyp+ " " + LacsCr;
			}
			else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +mtdAppliedAFYP+ " " + LacsCr;
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for " + user_clusters+ " is " +daily_inforced_count+ " " + LacsCr;
			}
		}
		/*-------------------------------------------end--------------------------------------------------------------------------*/
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for MLI is " +ytd_applied_afyp+ " " + LacsCr +"." 
						+ " If you want to see the channel wise business numbers, please specify the same.";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for MLI is " +ytd_applied_afyp+ " " + LacsCr +"." 
						+ " If you want to see the channel wise business numbers, please specify the same.";
			}else
			{
				finalresponse="As of " +real_tim_timstamp+ " Applied Business AFYP " +period+ " for MLI is " +ytd_applied_afyp+ " " + LacsCr +"." 
						+ " If you want to see the channel wise business numbers, please specify the same.";
			}
		}
		return finalresponse.toString();
	}
}