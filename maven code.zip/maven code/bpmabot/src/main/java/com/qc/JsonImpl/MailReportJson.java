package com.qc.JsonImpl;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.DataBean.AprReportDataBean;


public class MailReportJson {
	
	@Autowired
	private AprReportDataBean aprReportDataBean;
	
	public Map<Integer, Object> getMailReport(JSONObject obj){
		
		HashMap<Integer, Object> dataMap = new HashMap<Integer, Object>();
		JSONArray dataToDumpInExcel = null;
		
		try {
			 dataToDumpInExcel = obj.getJSONObject("payload").getJSONArray("mailReportDataPayloadRes");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		try{
			if(dataToDumpInExcel!= null)
			{
				for(int i=0; i<=dataToDumpInExcel.length()-1; i++){
					
					aprReportDataBean.setAgentId(validateData(dataToDumpInExcel.getJSONObject(i).get("agentId")));
					aprReportDataBean.setBotType(validateData(dataToDumpInExcel.getJSONObject(i).get("botType")));
					aprReportDataBean.setAgentName(validateData(dataToDumpInExcel.getJSONObject(i).get("agentName")));
					aprReportDataBean.setAgentJoinDate(validateData(dataToDumpInExcel.getJSONObject(i).get("agentJoinDate")));
					aprReportDataBean.setAgentStatus(validateData(dataToDumpInExcel.getJSONObject(i).get("agentStatus")));
					aprReportDataBean.setRole(validateData(dataToDumpInExcel.getJSONObject(i).get("role")));
					aprReportDataBean.setSegment(validateData(dataToDumpInExcel.getJSONObject(i).get("segment")));
					aprReportDataBean.setReportingToId(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToId")));
					aprReportDataBean.setReportingToName(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToName")));
					aprReportDataBean.setReportingToRole(validateData(dataToDumpInExcel.getJSONObject(i).get("reportingToRole")));
					aprReportDataBean.setGo(validateData(dataToDumpInExcel.getJSONObject(i).get("go")));
					aprReportDataBean.setAgentClass(validateData(dataToDumpInExcel.getJSONObject(i).get("agentClass")));
					aprReportDataBean.setActivityYtdVintage(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdVintage")));
					aprReportDataBean.setPaidCasesMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCasesMtd")));
					aprReportDataBean.setAdjMfypMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("adjMfypMtd")));
					aprReportDataBean.setWeightMfypMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("weightMfypMtd")));
					aprReportDataBean.setFycMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("fycMtd")));
					aprReportDataBean.setMtdGrowthPer(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdGrowthPer")));
					aprReportDataBean.setYtdPaidCases(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdPaidCases")));
					aprReportDataBean.setAdjMfypYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("adjMfypYtd")));
					aprReportDataBean.setWeightMfypYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("weightMfypYtd")));
					aprReportDataBean.setYtdFycWithoutSgBonus(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdFycWithoutSgBonus")));
					aprReportDataBean.setYtdGrowthPer(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdGrowthPer")));
					aprReportDataBean.setMtdAppliedNops(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdAppliedNops")));
					aprReportDataBean.setMtdAppliedWfyp(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdAppliedWfyp")));
					aprReportDataBean.setAplAdjIfypMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("aplAdjIfypMtd")));
					aprReportDataBean.setEarlySuccessCases(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessCases")));
					aprReportDataBean.setEarlySuccessFyc(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessFyc")));
					aprReportDataBean.setEarlySuccessCasesShortfall(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessCasesShortfall")));
					aprReportDataBean.setEarlySuccessFycShortfalll(validateData(dataToDumpInExcel.getJSONObject(i).get("earlySuccessFycShortfalll")));
					aprReportDataBean.setFinalEarlySuccess(validateData(dataToDumpInExcel.getJSONObject(i).get("finalEarlySuccess")));
					aprReportDataBean.setFycActualMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("fycActualMtd")));
					aprReportDataBean.setFycTargetMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("fycTargetMtd")));
					aprReportDataBean.setShortInFycMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFycMtd")));
					aprReportDataBean.setProactiveManMonthsMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("proactiveManMonthsMtd")));
					aprReportDataBean.setProStatusMtd(validateData(dataToDumpInExcel.getJSONObject(i).get("proStatusMtd")));
					aprReportDataBean.setFycActualYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("fycActualYtd")));
					aprReportDataBean.setFycYtdTarget(validateData(dataToDumpInExcel.getJSONObject(i).get("fycYtdTarget")));
					aprReportDataBean.setShortInFycYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFycYtd")));
					aprReportDataBean.setProStatusYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("proStatusYtd")));
					aprReportDataBean.setPaidCsYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCsYtd")));
					aprReportDataBean.setShortInPaidCase(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInPaidCase")));
					aprReportDataBean.setManMonthYtd(validateData(dataToDumpInExcel.getJSONObject(i).get("manMonthYtd")));
					aprReportDataBean.setActivityYtdLastActiveDate(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdLastActiveDate")));
					aprReportDataBean.setActivityYtdYtdActiveStatus(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdYtdActiveStatus")));
					aprReportDataBean.setActivityYtdMtdActiveStatus(validateData(dataToDumpInExcel.getJSONObject(i).get("activityYtdMtdActiveStatus")));
					aprReportDataBean.setQrFyc(validateData(dataToDumpInExcel.getJSONObject(i).get("qrFyc")));
					aprReportDataBean.setShortfallQrFyc(validateData(dataToDumpInExcel.getJSONObject(i).get("shortfallQrFyc")));
					aprReportDataBean.setQrQualifyingMonth(validateData(dataToDumpInExcel.getJSONObject(i).get("qrQualifyingMonth")));
					aprReportDataBean.setPaidCase9In90(validateData(dataToDumpInExcel.getJSONObject(i).get("paidCase9In90")));
					aprReportDataBean.setFyc9In90(validateData(dataToDumpInExcel.getJSONObject(i).get("fyc9In90")));
					aprReportDataBean.setShortInPaidCase9In90(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInPaidCase9In90")));
					aprReportDataBean.setShortInFyc9In90(validateData(dataToDumpInExcel.getJSONObject(i).get("shortInFyc9In90")));
					aprReportDataBean.setNineIn90Month(validateData(dataToDumpInExcel.getJSONObject(i).get("nineIn90Month")));
					aprReportDataBean.setComisionDtlCarerAgtSchmSt(validateData(dataToDumpInExcel.getJSONObject(i).get("comisionDtlCarerAgtSchmSt")));
					aprReportDataBean.setFycqtr1(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr1")));
					aprReportDataBean.setFycqtr2(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr2")));
					aprReportDataBean.setFycqtr3(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr3")));
					aprReportDataBean.setFycqtr4(validateData(dataToDumpInExcel.getJSONObject(i).get("fycqtr4")));
					aprReportDataBean.setMtdProtectionUpdateNop(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateNop")));
					aprReportDataBean.setMtdProtectionUpdateAdjMfyp(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateAdjMfyp")));
					aprReportDataBean.setMtdProtectionUpdateWfyp(validateData(dataToDumpInExcel.getJSONObject(i).get("mtdProtectionUpdateWfyp")));
					aprReportDataBean.setYtdProtectionUpdateNop(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateNop")));
					aprReportDataBean.setYtdProtectionUpdateAdjMfyp(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateAdjMfyp")));
					aprReportDataBean.setYtdProtectionUpdateWfyp(validateData(dataToDumpInExcel.getJSONObject(i).get("ytdProtectionUpdateWfyp")));
					aprReportDataBean.setRenewalBusiUpdtCollectible(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdtCollectible")));
					aprReportDataBean.setRenewalBusiUpdtCollected(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdtCollected")));
					aprReportDataBean.setRenewalBusiUpdt13mPersis(validateData(dataToDumpInExcel.getJSONObject(i).get("renewalBusiUpdt13mPersis")));

					dataMap.put(i+1, aprReportDataBean);
				}
			}
		}
		catch(Exception ex){
			
		}
		return dataMap;
		
	}

	private String validateData(Object object) {
		String nullCheck="";
		try{
			if(object != null && object.toString().isEmpty())
			{
				nullCheck=object.toString();
			}
		}
		catch(Exception ex){
			
		}
		
		return nullCheck;
	}

}
