package com.qc.api.service;

import com.qc.common.InnerData;

public interface Button {
	public InnerData getButtonApr();

}
