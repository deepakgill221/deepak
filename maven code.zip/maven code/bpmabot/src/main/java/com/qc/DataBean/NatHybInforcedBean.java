package com.qc.DataBean;

public class NatHybInforcedBean 
{
	private String nativ_daily_inforced_afyp;
	private String nativ_daily_inforced_count;
	private String nativ_daily_adj_mfyp;
	private String nativ_mtd_inforced_afyp;
	private String nativ_mtd_inforced_count;
	private String nativ_mtd_adj_mfyp;
	private String nativ_ytd_inforced_afyp;
	private String nativ_ytd_inforced_count;
	private String nativ_ytd_adj_mfyp;
	private String hybride_daily_inforced_afyp;
	private String hybride_daily_inforced_count;
	private String hybride_daily_adj_mfyp;
	private String hybride_mtd_inforced_afyp;
	private String hybride_mtd_inforced_count;
	private String hybride_mtd_adj_mfyp;
	private String hybride_ytd_inforced_afyp;
	private String hybride_ytd_inforced_count;
	private String hybride_ytd_adj_mfyp;
	private String btch_timstamp;
	private String real_tim_timstamp;
	
	public String getNativ_daily_inforced_afyp() {
		return nativ_daily_inforced_afyp;
	}
	public void setNativ_daily_inforced_afyp(String nativ_daily_inforced_afyp) {
		this.nativ_daily_inforced_afyp = nativ_daily_inforced_afyp;
	}
	public String getNativ_daily_inforced_count() {
		return nativ_daily_inforced_count;
	}
	public void setNativ_daily_inforced_count(String nativ_daily_inforced_count) {
		this.nativ_daily_inforced_count = nativ_daily_inforced_count;
	}
	public String getNativ_daily_adj_mfyp() {
		return nativ_daily_adj_mfyp;
	}
	public void setNativ_daily_adj_mfyp(String nativ_daily_adj_mfyp) {
		this.nativ_daily_adj_mfyp = nativ_daily_adj_mfyp;
	}
	public String getNativ_mtd_inforced_afyp() {
		return nativ_mtd_inforced_afyp;
	}
	public void setNativ_mtd_inforced_afyp(String nativ_mtd_inforced_afyp) {
		this.nativ_mtd_inforced_afyp = nativ_mtd_inforced_afyp;
	}
	public String getNativ_mtd_inforced_count() {
		return nativ_mtd_inforced_count;
	}
	public void setNativ_mtd_inforced_count(String nativ_mtd_inforced_count) {
		this.nativ_mtd_inforced_count = nativ_mtd_inforced_count;
	}
	public String getNativ_mtd_adj_mfyp() {
		return nativ_mtd_adj_mfyp;
	}
	public void setNativ_mtd_adj_mfyp(String nativ_mtd_adj_mfyp) {
		this.nativ_mtd_adj_mfyp = nativ_mtd_adj_mfyp;
	}
	public String getNativ_ytd_inforced_afyp() {
		return nativ_ytd_inforced_afyp;
	}
	public void setNativ_ytd_inforced_afyp(String nativ_ytd_inforced_afyp) {
		this.nativ_ytd_inforced_afyp = nativ_ytd_inforced_afyp;
	}
	public String getNativ_ytd_inforced_count() {
		return nativ_ytd_inforced_count;
	}
	public void setNativ_ytd_inforced_count(String nativ_ytd_inforced_count) {
		this.nativ_ytd_inforced_count = nativ_ytd_inforced_count;
	}
	public String getNativ_ytd_adj_mfyp() {
		return nativ_ytd_adj_mfyp;
	}
	public void setNativ_ytd_adj_mfyp(String nativ_ytd_adj_mfyp) {
		this.nativ_ytd_adj_mfyp = nativ_ytd_adj_mfyp;
	}
	public String getHybride_daily_inforced_afyp() {
		return hybride_daily_inforced_afyp;
	}
	public void setHybride_daily_inforced_afyp(String hybride_daily_inforced_afyp) {
		this.hybride_daily_inforced_afyp = hybride_daily_inforced_afyp;
	}
	public String getHybride_daily_inforced_count() {
		return hybride_daily_inforced_count;
	}
	public void setHybride_daily_inforced_count(String hybride_daily_inforced_count) {
		this.hybride_daily_inforced_count = hybride_daily_inforced_count;
	}
	public String getHybride_daily_adj_mfyp() {
		return hybride_daily_adj_mfyp;
	}
	public void setHybride_daily_adj_mfyp(String hybride_daily_adj_mfyp) {
		this.hybride_daily_adj_mfyp = hybride_daily_adj_mfyp;
	}
	public String getHybride_mtd_inforced_afyp() {
		return hybride_mtd_inforced_afyp;
	}
	public void setHybride_mtd_inforced_afyp(String hybride_mtd_inforced_afyp) {
		this.hybride_mtd_inforced_afyp = hybride_mtd_inforced_afyp;
	}
	public String getHybride_mtd_inforced_count() {
		return hybride_mtd_inforced_count;
	}
	public void setHybride_mtd_inforced_count(String hybride_mtd_inforced_count) {
		this.hybride_mtd_inforced_count = hybride_mtd_inforced_count;
	}
	public String getHybride_mtd_adj_mfyp() {
		return hybride_mtd_adj_mfyp;
	}
	public void setHybride_mtd_adj_mfyp(String hybride_mtd_adj_mfyp) {
		this.hybride_mtd_adj_mfyp = hybride_mtd_adj_mfyp;
	}
	public String getHybride_ytd_inforced_afyp() {
		return hybride_ytd_inforced_afyp;
	}
	public void setHybride_ytd_inforced_afyp(String hybride_ytd_inforced_afyp) {
		this.hybride_ytd_inforced_afyp = hybride_ytd_inforced_afyp;
	}
	public String getHybride_ytd_inforced_count() {
		return hybride_ytd_inforced_count;
	}
	public void setHybride_ytd_inforced_count(String hybride_ytd_inforced_count) {
		this.hybride_ytd_inforced_count = hybride_ytd_inforced_count;
	}
	public String getHybride_ytd_adj_mfyp() {
		return hybride_ytd_adj_mfyp;
	}
	public void setHybride_ytd_adj_mfyp(String hybride_ytd_adj_mfyp) {
		this.hybride_ytd_adj_mfyp = hybride_ytd_adj_mfyp;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
