package com.qc.service.messageimpl;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.JsonImpl.MailReportJson;
import com.qc.utils.AprApiCall;
/*import com.work.service.Cell;
import com.work.service.Row;
import com.work.service.XSSFSheet;
import com.work.service.XSSFWorkbook;*/

@Service
public class ReportMail {
	
	@Autowired
	private AprApiCall aprApiCall;
	
	MailReportJson mailReportJson = new MailReportJson();
	
	public String getMailReport(Map<String, Map<String, String>> map, String sessionId){
		String ssoId=map.get(sessionId).get("validSSOID");
		String agentId = map.get(sessionId).get("agentId");
		String emailField ="YES";
		String aprResponse = aprApiCall.getAprData( ssoId,  agentId,  emailField);
		try{
		JSONObject obj = new JSONObject(aprResponse);
		String status = obj.getJSONObject("errorInfo").get("status").toString();
		
		if("SUCCESS".equalsIgnoreCase(status)){
			
			
			Map<Integer, Object > newMap = mailReportJson.getMailReport(obj);
//			writeIntoExcel(dataToDumpInExcel);
			
		}
		}
		catch(Exception ex){
			
		}
		
	return "";
	}
	
	/*public void writeIntoExcel(Object obj) {

		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("sheet");
        Map<Integer, Object[]> data = new TreeMap<Integer, Object[]>();
		
		Object [] objArray = (Object[]) obj;
		data.put(1, objArray);
		try {
				if(objArray!=null) 
				{
						Set<Integer> keyset = data.keySet();
						int rownum = 0;
			        
						for (Integer key : keyset) 
						{
			            
				            Row row = sheet.createRow(rownum++);
				            Object[] objArr = data.get(key);
				            int cellnum = 0;
			            
				            for (Object object : objArr) 
				            {
			                
				                Cell cell = row.createCell(cellnum++);
				                if (object instanceof String)
				                    cell.setCellValue((String)object);
				                else if (object instanceof Integer)
				                    cell.setCellValue((Integer)object);
				            }
						}
	        
	        
	     LocalDate date = java.time.LocalDate.now();
	     File directory = new File("E:\\" +File.separator+date);
	     
	        	 if(!directory.exists()) {
	        		 directory.mkdir();
	        		
		 	            FileOutputStream out = new FileOutputStream(directory+File.separator+"BpmpBotExcel.xlsx");
		 	            workbook.write(out);
		 	            out.close();
		 	            System.out.println("RaBotExcel.xlsx written successfully on disk.");
	        	 }else {
	        		
		 	            FileOutputStream out = new FileOutputStream(directory+File.separator+"BpmpBotExcel.xlsx");
		 	            workbook.write(out);
		 	            out.close();
		 	            System.out.println("RaBotExcel.xlsx written successfully on disk.");
	        	 }
	        
		}
		}
        catch (Exception e) { e.printStackTrace(); }

		
	}  */
	
	

}
