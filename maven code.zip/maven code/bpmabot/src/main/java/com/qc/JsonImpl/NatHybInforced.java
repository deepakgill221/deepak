package com.qc.JsonImpl;

import org.json.JSONObject;

import com.qc.DataBean.NatHybInforcedBean;

public class NatHybInforced 
{
	public static NatHybInforcedBean inforcedBean = new NatHybInforcedBean();
	
	public void natHybInforced(JSONObject object)
	{
		try{
			inforcedBean.setNativ_daily_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_daily_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_daily_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_daily_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_daily_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_daily_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_mtd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_mtd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_mtd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_mtd_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_ytd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_ytd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_ytd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_ytd_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setNativ_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("nativ_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_daily_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_daily_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_daily_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_daily_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_daily_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_daily_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_mtd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_mtd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_mtd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_mtd_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_ytd_inforced_afyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_ytd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_ytd_inforced_count(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_ytd_inforced_count").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setHybride_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("hybride_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			inforcedBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybInforced").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}
