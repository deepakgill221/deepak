package com.qc.common;

import org.json.JSONObject;
import org.springframework.stereotype.Service;
@Service
public class TimeStamp 
{
	public String getTimeStamp(JSONObject object)
	{
		String real_tim_timstamp="";
		for(int i=0;i<1;i++)
		{
			try{
				real_tim_timstamp = object.getJSONObject("payload").getJSONObject("paid").get("real_tim_timstamp").toString();
				if(real_tim_timstamp!=null){break;}
			}catch(Exception ex){}
			try{
				real_tim_timstamp = object.getJSONObject("payload").getJSONObject("applied").get("real_tim_timstamp").toString();
				if(real_tim_timstamp!=null){break;}
			}catch(Exception ex){}
			try{
				real_tim_timstamp= object.getJSONObject("payload").getJSONObject("penetration").get("real_tim_timstamp").toString();
				if(real_tim_timstamp!=null){break;}
			}catch(Exception ex){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("growth").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("achievement").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("wip").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("casesize").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("lpcperformance").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("rec").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
			try{
				real_tim_timstamp = (object.getJSONObject("payload").getJSONObject("modemix").get("real_tim_timstamp").toString());
				if(real_tim_timstamp!=null){break;}
			}catch(Exception e){}
		}
		return real_tim_timstamp;
	}
}
