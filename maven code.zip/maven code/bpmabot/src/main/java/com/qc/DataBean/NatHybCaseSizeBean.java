package com.qc.DataBean;

public class NatHybCaseSizeBean 
{
	private String nativ_case_size_afyp_mtd;
	private String nativ_case_size_afyp_ytd;
	private String hybrd_case_size_afyp_mtd;
	private String hybrd_case_size_afyp_ytd;
	private String real_tim_timstamp;
	
	public String getNativ_case_size_afyp_mtd() {
		return nativ_case_size_afyp_mtd;
	}
	public void setNativ_case_size_afyp_mtd(String nativ_case_size_afyp_mtd) {
		this.nativ_case_size_afyp_mtd = nativ_case_size_afyp_mtd;
	}
	public String getNativ_case_size_afyp_ytd() {
		return nativ_case_size_afyp_ytd;
	}
	public void setNativ_case_size_afyp_ytd(String nativ_case_size_afyp_ytd) {
		this.nativ_case_size_afyp_ytd = nativ_case_size_afyp_ytd;
	}
	public String getHybrd_case_size_afyp_mtd() {
		return hybrd_case_size_afyp_mtd;
	}
	public void setHybrd_case_size_afyp_mtd(String hybrd_case_size_afyp_mtd) {
		this.hybrd_case_size_afyp_mtd = hybrd_case_size_afyp_mtd;
	}
	public String getHybrd_case_size_afyp_ytd() {
		return hybrd_case_size_afyp_ytd;
	}
	public void setHybrd_case_size_afyp_ytd(String hybrd_case_size_afyp_ytd) {
		this.hybrd_case_size_afyp_ytd = hybrd_case_size_afyp_ytd;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}