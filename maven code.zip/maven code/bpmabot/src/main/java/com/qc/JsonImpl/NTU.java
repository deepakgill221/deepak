package com.qc.JsonImpl;

import org.json.JSONObject;

import com.qc.DataBean.NTUBean;

public class NTU 
{
	public NTUBean ntumethod(JSONObject object)
	{
		NTUBean ntuBean = new NTUBean();
		try{
			ntuBean.setNtu_daily_inforced_afyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_daily_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_daily_inforced_count(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_daily_inforced_count").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_daily_adj_mfyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_daily_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_mtd_inforced_afyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_mtd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_mtd_inforced_count(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_mtd_inforced_count").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_mtd_adj_mfyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_mtd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_ytd_inforced_afyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_ytd_inforced_afyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_ytd_inforced_count(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_ytd_inforced_count").toString());
		}catch(Exception e){}
		try{
			ntuBean.setNtu_ytd_adj_mfyp(object.getJSONObject("payload").getJSONObject("ntu").get("ntu_ytd_adj_mfyp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setBtch_timstamp(object.getJSONObject("payload").getJSONObject("ntu").get("btch_timstamp").toString());
		}catch(Exception e){}
		try{
			ntuBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("ntu").get("real_tim_timstamp").toString());
		}catch(Exception e){}
		return ntuBean;
	}		
}
