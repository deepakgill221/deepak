package com.qc.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.qc.common.XTrustProvider;
import com.qc.utils.HttpUrlConnection_GetDetails;

@Component
public class AprApiCall {

	private static Logger logger = LogManager.getLogger(HttpUrlConnection_GetDetails.class);
	public String getAprData(String ssoId, String agentId, String emailFields)
	{
		logger.info("START :- Inside : - getUserDetail :- SSOID:- "+ssoId);
		ResourceBundle res = ResourceBundle.getBundle("com.qc.bot.resources.application");
		HttpURLConnection conn = null;
		StringBuilder result = new StringBuilder();
		String output = ""; 
		try
		{
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String serviceurl = res.getString("serviceAprData");
			URL url = new URL(serviceurl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata=new StringBuilder();
			UUID uniqueId = UUID.randomUUID();
			requestdata.append("	{	");
			requestdata.append("	  \"header\": {	");
			requestdata.append("	    \"correlationId\": \""+uniqueId+"\",	");
			requestdata.append("	    \"msgVersion\": \"\",	");
			requestdata.append("	    \"appId\": \"\",	");
			requestdata.append("	    \"userId\": \"\",	");
			requestdata.append("	    \"password\": \"\",	");
			requestdata.append("	    \"rollId\":\"\"	");
			requestdata.append("	  },	");
			requestdata.append("	  \"payload\": {	");
			requestdata.append("	    \"ssoId\": \""+ssoId+"\",	");
			requestdata.append("	    \"agentId\": \""+agentId+"\", ");
			requestdata.append("	    \"botType\": \""+"FLS"+"\", ");
			requestdata.append("	    \"emailFields\": \""+emailFields+"\" ");
			requestdata.append("	  }	");
			requestdata.append("	}	");
			logger.info("API to get user detail :: "+ serviceurl);
			logger.info("Request to call getUserDetail API :: " +requestdata);
			
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {writer.close(); } 
			catch (Exception e1) 
			{
				logger.info(e1);
			}

			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END : servicegetUserDetail : User Validation");

			}
			else
			{
				logger.info("Unable to connect External GetUserDetail API");
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling getUserDetail API :: "+e);
		}
		logger.info("END :- OutSide : - getUserDetail :- SSOID:- "+ssoId);
		return result.toString();
	}
}
