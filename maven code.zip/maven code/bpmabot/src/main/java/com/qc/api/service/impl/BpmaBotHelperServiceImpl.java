package com.qc.api.service.impl;

import java.util.Random;

import org.springframework.stereotype.Service;

import com.qc.api.service.BpmaBotHelperService;

@Service
public class BpmaBotHelperServiceImpl implements BpmaBotHelperService
{
	public String randomNumber() {
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i < 6; i++) {
			bf = bf.append(getRandomNumberInRange(1, 9));
		}
		return bf.toString();
	}
	
	public static int getRandomNumberInRange(int min, int max) {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
	

}
