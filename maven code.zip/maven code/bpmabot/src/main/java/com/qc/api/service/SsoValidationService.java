package com.qc.api.service;

import java.util.Map;

public interface SsoValidationService 

{
public Map<String, Map<String, String>> APICallSSOValidation(String ssoId, String sessionId,String actionperformed, Map<String, Map<String, String>> sessionMapcontainssoinfo);

}
