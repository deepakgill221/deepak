package com.qc.DataBean;

public class NatHybWipBean 
{
	private String nativ_wip_count;  
	private String nativ_wip_afyp;  
	private String nativ_ho_wip_afyp;    
	private String nativ_go_wip_afyp;   
	private String nativ_it_wip_afyp;     
	private String nativ_fin_wip_afyp;     
	private String nativ_misc_wip_afyp;     
	private String nativ_welcome_wip_afyp;    
	private String nativ_ho_wip_count;    
	private String nativ_go_wip_count;    
	private String nativ_it_wip_count;    
	private String nativ_fin_wip_count;    
	private String nativ_misc_wip_count;    
	private String nativ_welcome_wip_count;    
	private String nativ_ho_wip_adj_mfyp;    
	private String nativ_go_wip_adj_mfyp;    
	private String nativ_it_wip_adj_mfyp;    
	private String nativ_fin_wip_adj_mfyp;    
	private String nativ_misc_wip_adj_mfyp;    
	private String nativ_welcome_wip_adj_mfyp;    
	private String nativ_wip_adj_mfyp;    
	private String hybrd_wip_count;    
	private String hybrd_wip_afyp;   
	private String hybrd_ho_wip_afyp;    
	private String hybrd_go_wip_afyp;    
	private String hybrd_it_wip_afyp;     
	private String hybrd_fin_wip_afyp;     
	private String hybrd_misc_wip_afyp;     
	private String hybrd_welcome_wip_afyp;    
	private String hybrd_ho_wip_count;    
	private String hybrd_go_wip_count;    
	private String hybrd_it_wip_count;    
	private String hybrd_fin_wip_count;    
	private String hybrd_misc_wip_count;    
	private String hybrd_welcome_wip_count;    
	private String hybrd_ho_wip_adj_mfyp;    
	private String hybrd_go_wip_adj_mfyp;    
	private String hybrd_it_wip_adj_mfyp;    
	private String hybrd_fin_wip_adj_mfyp;    
	private String hybrd_misc_wip_adj_mfyp;    
	private String hybrd_welcome_wip_adj_mfyp;    
	private String hybrd_wip_adj_mfyp;
	private String real_tim_timstamp;
	
	public String getNativ_wip_count() {
		return nativ_wip_count;
	}
	public void setNativ_wip_count(String nativ_wip_count) {
		this.nativ_wip_count = nativ_wip_count;
	}
	public String getNativ_wip_afyp() {
		return nativ_wip_afyp;
	}
	public void setNativ_wip_afyp(String nativ_wip_afyp) {
		this.nativ_wip_afyp = nativ_wip_afyp;
	}
	public String getNativ_ho_wip_afyp() {
		return nativ_ho_wip_afyp;
	}
	public void setNativ_ho_wip_afyp(String nativ_ho_wip_afyp) {
		this.nativ_ho_wip_afyp = nativ_ho_wip_afyp;
	}
	public String getNativ_go_wip_afyp() {
		return nativ_go_wip_afyp;
	}
	public void setNativ_go_wip_afyp(String nativ_go_wip_afyp) {
		this.nativ_go_wip_afyp = nativ_go_wip_afyp;
	}
	public String getNativ_it_wip_afyp() {
		return nativ_it_wip_afyp;
	}
	public void setNativ_it_wip_afyp(String nativ_it_wip_afyp) {
		this.nativ_it_wip_afyp = nativ_it_wip_afyp;
	}
	public String getNativ_fin_wip_afyp() {
		return nativ_fin_wip_afyp;
	}
	public void setNativ_fin_wip_afyp(String nativ_fin_wip_afyp) {
		this.nativ_fin_wip_afyp = nativ_fin_wip_afyp;
	}
	public String getNativ_misc_wip_afyp() {
		return nativ_misc_wip_afyp;
	}
	public void setNativ_misc_wip_afyp(String nativ_misc_wip_afyp) {
		this.nativ_misc_wip_afyp = nativ_misc_wip_afyp;
	}
	public String getNativ_welcome_wip_afyp() {
		return nativ_welcome_wip_afyp;
	}
	public void setNativ_welcome_wip_afyp(String nativ_welcome_wip_afyp) {
		this.nativ_welcome_wip_afyp = nativ_welcome_wip_afyp;
	}
	public String getNativ_ho_wip_count() {
		return nativ_ho_wip_count;
	}
	public void setNativ_ho_wip_count(String nativ_ho_wip_count) {
		this.nativ_ho_wip_count = nativ_ho_wip_count;
	}
	public String getNativ_go_wip_count() {
		return nativ_go_wip_count;
	}
	public void setNativ_go_wip_count(String nativ_go_wip_count) {
		this.nativ_go_wip_count = nativ_go_wip_count;
	}
	public String getNativ_it_wip_count() {
		return nativ_it_wip_count;
	}
	public void setNativ_it_wip_count(String nativ_it_wip_count) {
		this.nativ_it_wip_count = nativ_it_wip_count;
	}
	public String getNativ_fin_wip_count() {
		return nativ_fin_wip_count;
	}
	public void setNativ_fin_wip_count(String nativ_fin_wip_count) {
		this.nativ_fin_wip_count = nativ_fin_wip_count;
	}
	public String getNativ_misc_wip_count() {
		return nativ_misc_wip_count;
	}
	public void setNativ_misc_wip_count(String nativ_misc_wip_count) {
		this.nativ_misc_wip_count = nativ_misc_wip_count;
	}
	public String getNativ_welcome_wip_count() {
		return nativ_welcome_wip_count;
	}
	public void setNativ_welcome_wip_count(String nativ_welcome_wip_count) {
		this.nativ_welcome_wip_count = nativ_welcome_wip_count;
	}
	public String getNativ_ho_wip_adj_mfyp() {
		return nativ_ho_wip_adj_mfyp;
	}
	public void setNativ_ho_wip_adj_mfyp(String nativ_ho_wip_adj_mfyp) {
		this.nativ_ho_wip_adj_mfyp = nativ_ho_wip_adj_mfyp;
	}
	public String getNativ_go_wip_adj_mfyp() {
		return nativ_go_wip_adj_mfyp;
	}
	public void setNativ_go_wip_adj_mfyp(String nativ_go_wip_adj_mfyp) {
		this.nativ_go_wip_adj_mfyp = nativ_go_wip_adj_mfyp;
	}
	public String getNativ_it_wip_adj_mfyp() {
		return nativ_it_wip_adj_mfyp;
	}
	public void setNativ_it_wip_adj_mfyp(String nativ_it_wip_adj_mfyp) {
		this.nativ_it_wip_adj_mfyp = nativ_it_wip_adj_mfyp;
	}
	public String getNativ_fin_wip_adj_mfyp() {
		return nativ_fin_wip_adj_mfyp;
	}
	public void setNativ_fin_wip_adj_mfyp(String nativ_fin_wip_adj_mfyp) {
		this.nativ_fin_wip_adj_mfyp = nativ_fin_wip_adj_mfyp;
	}
	public String getNativ_misc_wip_adj_mfyp() {
		return nativ_misc_wip_adj_mfyp;
	}
	public void setNativ_misc_wip_adj_mfyp(String nativ_misc_wip_adj_mfyp) {
		this.nativ_misc_wip_adj_mfyp = nativ_misc_wip_adj_mfyp;
	}
	public String getNativ_welcome_wip_adj_mfyp() {
		return nativ_welcome_wip_adj_mfyp;
	}
	public void setNativ_welcome_wip_adj_mfyp(String nativ_welcome_wip_adj_mfyp) {
		this.nativ_welcome_wip_adj_mfyp = nativ_welcome_wip_adj_mfyp;
	}
	public String getNativ_wip_adj_mfyp() {
		return nativ_wip_adj_mfyp;
	}
	public void setNativ_wip_adj_mfyp(String nativ_wip_adj_mfyp) {
		this.nativ_wip_adj_mfyp = nativ_wip_adj_mfyp;
	}
	public String getHybrd_wip_count() {
		return hybrd_wip_count;
	}
	public void setHybrd_wip_count(String hybrd_wip_count) {
		this.hybrd_wip_count = hybrd_wip_count;
	}
	public String getHybrd_wip_afyp() {
		return hybrd_wip_afyp;
	}
	public void setHybrd_wip_afyp(String hybrd_wip_afyp) {
		this.hybrd_wip_afyp = hybrd_wip_afyp;
	}
	public String getHybrd_ho_wip_afyp() {
		return hybrd_ho_wip_afyp;
	}
	public void setHybrd_ho_wip_afyp(String hybrd_ho_wip_afyp) {
		this.hybrd_ho_wip_afyp = hybrd_ho_wip_afyp;
	}
	public String getHybrd_go_wip_afyp() {
		return hybrd_go_wip_afyp;
	}
	public void setHybrd_go_wip_afyp(String hybrd_go_wip_afyp) {
		this.hybrd_go_wip_afyp = hybrd_go_wip_afyp;
	}
	public String getHybrd_it_wip_afyp() {
		return hybrd_it_wip_afyp;
	}
	public void setHybrd_it_wip_afyp(String hybrd_it_wip_afyp) {
		this.hybrd_it_wip_afyp = hybrd_it_wip_afyp;
	}
	public String getHybrd_fin_wip_afyp() {
		return hybrd_fin_wip_afyp;
	}
	public void setHybrd_fin_wip_afyp(String hybrd_fin_wip_afyp) {
		this.hybrd_fin_wip_afyp = hybrd_fin_wip_afyp;
	}
	public String getHybrd_misc_wip_afyp() {
		return hybrd_misc_wip_afyp;
	}
	public void setHybrd_misc_wip_afyp(String hybrd_misc_wip_afyp) {
		this.hybrd_misc_wip_afyp = hybrd_misc_wip_afyp;
	}
	public String getHybrd_welcome_wip_afyp() {
		return hybrd_welcome_wip_afyp;
	}
	public void setHybrd_welcome_wip_afyp(String hybrd_welcome_wip_afyp) {
		this.hybrd_welcome_wip_afyp = hybrd_welcome_wip_afyp;
	}
	public String getHybrd_ho_wip_count() {
		return hybrd_ho_wip_count;
	}
	public void setHybrd_ho_wip_count(String hybrd_ho_wip_count) {
		this.hybrd_ho_wip_count = hybrd_ho_wip_count;
	}
	public String getHybrd_go_wip_count() {
		return hybrd_go_wip_count;
	}
	public void setHybrd_go_wip_count(String hybrd_go_wip_count) {
		this.hybrd_go_wip_count = hybrd_go_wip_count;
	}
	public String getHybrd_it_wip_count() {
		return hybrd_it_wip_count;
	}
	public void setHybrd_it_wip_count(String hybrd_it_wip_count) {
		this.hybrd_it_wip_count = hybrd_it_wip_count;
	}
	public String getHybrd_fin_wip_count() {
		return hybrd_fin_wip_count;
	}
	public void setHybrd_fin_wip_count(String hybrd_fin_wip_count) {
		this.hybrd_fin_wip_count = hybrd_fin_wip_count;
	}
	public String getHybrd_misc_wip_count() {
		return hybrd_misc_wip_count;
	}
	public void setHybrd_misc_wip_count(String hybrd_misc_wip_count) {
		this.hybrd_misc_wip_count = hybrd_misc_wip_count;
	}
	public String getHybrd_welcome_wip_count() {
		return hybrd_welcome_wip_count;
	}
	public void setHybrd_welcome_wip_count(String hybrd_welcome_wip_count) {
		this.hybrd_welcome_wip_count = hybrd_welcome_wip_count;
	}
	public String getHybrd_ho_wip_adj_mfyp() {
		return hybrd_ho_wip_adj_mfyp;
	}
	public void setHybrd_ho_wip_adj_mfyp(String hybrd_ho_wip_adj_mfyp) {
		this.hybrd_ho_wip_adj_mfyp = hybrd_ho_wip_adj_mfyp;
	}
	public String getHybrd_go_wip_adj_mfyp() {
		return hybrd_go_wip_adj_mfyp;
	}
	public void setHybrd_go_wip_adj_mfyp(String hybrd_go_wip_adj_mfyp) {
		this.hybrd_go_wip_adj_mfyp = hybrd_go_wip_adj_mfyp;
	}
	public String getHybrd_it_wip_adj_mfyp() {
		return hybrd_it_wip_adj_mfyp;
	}
	public void setHybrd_it_wip_adj_mfyp(String hybrd_it_wip_adj_mfyp) {
		this.hybrd_it_wip_adj_mfyp = hybrd_it_wip_adj_mfyp;
	}
	public String getHybrd_fin_wip_adj_mfyp() {
		return hybrd_fin_wip_adj_mfyp;
	}
	public void setHybrd_fin_wip_adj_mfyp(String hybrd_fin_wip_adj_mfyp) {
		this.hybrd_fin_wip_adj_mfyp = hybrd_fin_wip_adj_mfyp;
	}
	public String getHybrd_misc_wip_adj_mfyp() {
		return hybrd_misc_wip_adj_mfyp;
	}
	public void setHybrd_misc_wip_adj_mfyp(String hybrd_misc_wip_adj_mfyp) {
		this.hybrd_misc_wip_adj_mfyp = hybrd_misc_wip_adj_mfyp;
	}
	public String getHybrd_welcome_wip_adj_mfyp() {
		return hybrd_welcome_wip_adj_mfyp;
	}
	public void setHybrd_welcome_wip_adj_mfyp(String hybrd_welcome_wip_adj_mfyp) {
		this.hybrd_welcome_wip_adj_mfyp = hybrd_welcome_wip_adj_mfyp;
	}
	public String getHybrd_wip_adj_mfyp() {
		return hybrd_wip_adj_mfyp;
	}
	public void setHybrd_wip_adj_mfyp(String hybrd_wip_adj_mfyp) {
		this.hybrd_wip_adj_mfyp = hybrd_wip_adj_mfyp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
