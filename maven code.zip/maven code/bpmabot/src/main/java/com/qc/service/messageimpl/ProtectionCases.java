package com.qc.service.messageimpl;

import com.qc.DataBean.ProtectionBean;

public class ProtectionCases {

	public static String protectionIntent(String channel, String period, String userzone, String user_region, 
			String user_circle, String subchannel, String user_clusters, String user_go, String LacsCr, ProtectionBean protectionBean)
	{
		String finalresponse="";
		if("MLI".equalsIgnoreCase(channel))
		{channel="";}
		if("Monthly".equalsIgnoreCase(period))
		{period="";}
		else
		{
			period=period.toUpperCase();
		}
		if(!"".equalsIgnoreCase(user_circle))
		{
			user_region="Circle "+user_circle;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(user_go))
		{
			user_clusters="Office "+user_go;
		}
		/*------------------------------------------------*/
		if(!"".equalsIgnoreCase(subchannel))
		{
			channel = subchannel;
		}
		if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for MLI is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n"+
					" Plan achv: "+ protectionBean.getProtec_paid_achv_mtd_adj_mfyp() + 
					"% with adj. MFYP " + protectionBean.getProtec_paid_mtd_adj_mfyp() + " " + LacsCr +
					" against the plan of " +protectionBean.getProtec_plan_paid_mtd_adj_mfyp() + " " + LacsCr+".\n "+
					protectionBean.getProtec_paid_achv_mtd_afyp()+"% with Paid AFYP " + 
					protectionBean.getProtec_paid_mtd_afyp()+ " " + LacsCr +" against the plan of "+ 
					protectionBean.getProtec_plan_paid_mtd_afyp() +" " +LacsCr +".\n " +
					protectionBean.getProtec_paid_achv_mtd_nop() +"% with " + protectionBean.getProtec_paid_mtd_pol_cnt() +
					" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_mtd_pol_count()+".\n"+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
					" Do you wish to see the stage wise snapshot for WIP?";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+channel+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n";
					//if(!"Defence".equalsIgnoreCase(channel) && !"POSP".equalsIgnoreCase(channel))
					//{
						finalresponse=finalresponse+
								" Plan achv: "+ protectionBean.getProtec_paid_achv_mtd_adj_mfyp() + "% with adj. MFYP " + 
								protectionBean.getProtec_paid_mtd_adj_mfyp() + " " + LacsCr +
								" against the plan of " +protectionBean.getProtec_plan_paid_mtd_adj_mfyp() + " " + LacsCr+".\n ";
					//}
				
						finalresponse=finalresponse+
								protectionBean.getProtec_paid_achv_mtd_afyp()+"% with Paid AFYP " + 
								protectionBean.getProtec_paid_mtd_afyp()+ " " + LacsCr +" against the plan of "+ 
								protectionBean.getProtec_plan_paid_mtd_afyp() +" " +LacsCr +". \n" +
								protectionBean.getProtec_paid_achv_mtd_nop() +"% with " + protectionBean.getProtec_paid_mtd_pol_cnt() +
								" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_mtd_pol_count()+".\n"+
								" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
								protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
								" Do you wish to see the stage wise snapshot for WIP?";
					//" Plan achv: "+ protectionBean.getProtec_paid_achv_mtd_adj_mfyp() + "% with adj. MFYP " + protectionBean.getProtec_paid_mtd_adj_mfyp() + " " + LacsCr +" against the plan of " +protectionBean.getProtec_plan_paid_mtd_adj_mfyp() + " " + LacsCr+".\n"+
					//" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
					//" Do you wish to see the stage wise snapshot for WIP?";
			
			if("Agency".equalsIgnoreCase(channel))
			{
				finalresponse=finalresponse+" If you want to see the data for sub-channels, please enter sub-channel name Defence, Office within office, APC, Greenfield.";
			}
		}else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+userzone+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr+"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
					" Do you wish to see the stage wise snapshot for WIP?";
			
		}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) && "".equalsIgnoreCase(user_clusters)
				&& "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+user_region+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +""+"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +""+"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +""+"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
					" Do you wish to see the stage wise snapshot for WIP?";

		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+user_clusters+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
			      		" Do you wish to see the stage wise snapshot for WIP?";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+user_clusters+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
			        	" Do you wish to see the stage wise snapshot for WIP?";
		}
		/*--------------------------------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+user_clusters+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
			        	" Do you wish to see the stage wise snapshot for WIP?";

		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && "".equalsIgnoreCase(period))
		{
			finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the MTD Protection business for "+user_region+" is: "+"\n"+
					"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
					" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
					" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
					" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
					" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
					" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
					" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
					protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
			        	" Do you wish to see the stage wise snapshot for WIP?";
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" Plan achv: "+ protectionBean.getProtec_paid_achv_ytd_adj_mfyp() + "% with adj. MFYP " + 
						protectionBean.getProtec_paid_ytd_adj_mfyp() + " " + LacsCr +" against the plan of " +
						protectionBean.getProtec_plan_paid_ytd_adj_mfyp() + " " + LacsCr+".\n"+
						protectionBean.getProtec_paid_achv_ytd_afyp()+"% with Paid AFYP " + 
						protectionBean.getProtec_paid_ytd_afyp()+ " " + LacsCr +" against the plan of "+ 
						protectionBean.getProtec_paln_paid_ytd_afyp() +" " +LacsCr +". \n" +
						protectionBean.getProtec_paid_achv_ytd_nop() +"% with " + protectionBean.getProtec_paid_ytd_pol_cnt()+ 
						" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_ytd_pol_count()+".\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" Plan achv: "+ protectionBean.getProtec_paid_achv_mtd_adj_mfyp() + "% with adj. MFYP " + 
						protectionBean.getProtec_paid_mtd_adj_mfyp() + " " + LacsCr +" against the plan of " +
						protectionBean.getProtec_plan_paid_mtd_adj_mfyp() + " " + LacsCr+".\n"+
						protectionBean.getProtec_paid_achv_mtd_afyp()+"% with Paid AFYP " + 
						protectionBean.getProtec_paid_mtd_afyp()+ " " + LacsCr +" against the plan of "+ 
						protectionBean.getProtec_plan_paid_mtd_afyp() +" " +LacsCr +". \n" +
						protectionBean.getProtec_paid_achv_mtd_nop() +"% with " + protectionBean.getProtec_paid_mtd_pol_cnt() +
						" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_mtd_pol_count()+".\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?"; 
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		
		else if("".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
				&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " +protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
							" Plan achv: "+ protectionBean.getProtec_paid_achv_ytd_adj_mfyp() + "% with adj. MFYP " + 
							protectionBean.getProtec_paid_ytd_adj_mfyp() + " " + LacsCr +" against the plan of " +
							protectionBean.getProtec_plan_paid_ytd_adj_mfyp() + " " + LacsCr+".\n"+
							protectionBean.getProtec_paid_achv_ytd_afyp()+"% with Paid AFYP " + 
							protectionBean.getProtec_paid_ytd_afyp()+ " " + LacsCr +" against the plan of "+ 
							protectionBean.getProtec_paln_paid_ytd_afyp() +" " +LacsCr +". \n" +
							protectionBean.getProtec_paid_achv_ytd_nop() +"% with " + protectionBean.getProtec_paid_ytd_pol_cnt() +
							" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_ytd_pol_count()+".\n"+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?";
				}
				else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " +protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
							" Plan achv: "+ protectionBean.getProtec_paid_achv_mtd_adj_mfyp() + "% with adj. MFYP " + 
							protectionBean.getProtec_paid_mtd_adj_mfyp() + " " + LacsCr +" against the plan of " +
							protectionBean.getProtec_plan_paid_mtd_adj_mfyp() + " " + LacsCr+".\n"+
							protectionBean.getProtec_paid_achv_mtd_afyp()+"% with Paid AFYP " + 
							protectionBean.getProtec_paid_mtd_afyp()+ " " + LacsCr +" against the plan of "+ 
							protectionBean.getProtec_plan_paid_mtd_afyp() +" " +LacsCr +". \n" +
							protectionBean.getProtec_paid_achv_mtd_nop() +"% with " + protectionBean.getProtec_paid_mtd_pol_cnt() +
							" Paid cases against the plan of " +protectionBean.getProtec_plan_paid_mtd_pol_count()+".\n"+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?"; 
				}else
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?";
				}
			}
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			 && "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+userzone+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
				
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+userzone+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+userzone+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		/*--------------------------------------Channel & GO------start----------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && "".equalsIgnoreCase(user_region) 
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		/*-------------added by bhavneet---------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && "".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region) 
				&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
			{
				if("YTD".equalsIgnoreCase(period))
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " + protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?";
				}else if("MTD".equalsIgnoreCase(period))
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?";
				}else
				{
					finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
							"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
							" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
							" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
							" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
							" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
							" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+" " + LacsCr +"\n"+
							" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
							protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
							" Do you wish to see the stage wise snapshot for WIP?";
				}
			}
		/*--------------------------------------Channel & GO----------end------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& "".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+" " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_region+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+" " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+" " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+ " " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		/*-----------------------------------------start----------------------------------------------------------------------------*/
		else if(!"".equalsIgnoreCase(channel) && !"".equalsIgnoreCase(userzone) && !"".equalsIgnoreCase(user_region)
			&& !"".equalsIgnoreCase(user_clusters) && !"".equalsIgnoreCase(period))
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+ " " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
			else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+ " " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+user_clusters+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+ " " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		/*-------------------------------------------end--------------------------------------------------------------------------*/
		else
		{
			if("YTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_ytd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_ytd_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " +protectionBean.getProtec_paid_ytd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_ytd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_ytd_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_ytd_applied_adj_ifyp()+ " " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else if("MTD".equalsIgnoreCase(period))
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_mtd_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_mtd_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_mtd_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_mtd_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_mtd_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_mtd_applied_adj_ifyp()+ " " + LacsCr +"\n "+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}else
			{
				finalresponse= "As of " +protectionBean.getReal_tim_timstamp()+", the "+period+" Protection business for "+channel+" is: "+"\n"+
						"Paid Cases: " +protectionBean.getProtec_paid_daily_pol_cnt()+"\n"+
						" Paid adj. MFYP: "+protectionBean.getProtec_paid_daily_adj_mfyp()+ " " + LacsCr +"\n"+
						" Paid AFYP : " + protectionBean.getProtec_paid_daily_afyp() +" "+ LacsCr + "\n"+
						" Applied Cases: "+protectionBean.getProtec_daily_applied_count()+"\n"+
						" Applied AFYP: "+protectionBean.getProtec_daily_applied_afyp()+ " " + LacsCr +"\n"+
						" Applied adj. IFYP: "+protectionBean.getProtec_daily_applied_adj_ifyp()+ " " + LacsCr +"\n"+
						" WIP: "+protectionBean.getProtec_total_wip_count()+" policies with adj. MFYP: "+
						protectionBean.getProtec_total_wip_adj_mfyp()+ " " + LacsCr + "."+"\n"+
						" Do you wish to see the stage wise snapshot for WIP?";
			}
		}
		return finalresponse.toString();

	}
}

