package com.qc.DataBean;

public class NatHybAppliedBean 
{
	private String nativ_daily_applied_afyp;
	private String nativ_daily_applied_count;
	private String nativ_mtd_applied_afyp;
	private String nativ_mtd_applied_count;
	private String nativ_ytd_applied_afyp;
	private String nativ_ytd_applied_count;
	private String nativ_mtd_applied_adj_ifyp;
	private String nativ_ytd_applied_adj_ifyp;
	private String nativ_daily_applied_adj_ifyp; 
	private String hybride_daily_applied_afyp;
	private String hybride_daily_applied_count;
	private String hybride_mtd_applied_afyp;
	private String hybride_mtd_applied_count;
	private String hybride_ytd_applied_afyp;
	private String hybride_ytd_applied_count;
	private String hybride_mtd_applied_adj_ifyp;
	private String hybride_ytd_applied_adj_ifyp;
	private String hybride_daily_applied_adj_ifyp;
	private String real_tim_timstamp;
	
	
	public String getNativ_daily_applied_afyp() {
		return nativ_daily_applied_afyp;
	}
	public void setNativ_daily_applied_afyp(String nativ_daily_applied_afyp) {
		this.nativ_daily_applied_afyp = nativ_daily_applied_afyp;
	}
	public String getNativ_daily_applied_count() {
		return nativ_daily_applied_count;
	}
	public void setNativ_daily_applied_count(String nativ_daily_applied_count) {
		this.nativ_daily_applied_count = nativ_daily_applied_count;
	}
	public String getNativ_mtd_applied_afyp() {
		return nativ_mtd_applied_afyp;
	}
	public void setNativ_mtd_applied_afyp(String nativ_mtd_applied_afyp) {
		this.nativ_mtd_applied_afyp = nativ_mtd_applied_afyp;
	}
	public String getNativ_mtd_applied_count() {
		return nativ_mtd_applied_count;
	}
	public void setNativ_mtd_applied_count(String nativ_mtd_applied_count) {
		this.nativ_mtd_applied_count = nativ_mtd_applied_count;
	}
	public String getNativ_ytd_applied_afyp() {
		return nativ_ytd_applied_afyp;
	}
	public void setNativ_ytd_applied_afyp(String nativ_ytd_applied_afyp) {
		this.nativ_ytd_applied_afyp = nativ_ytd_applied_afyp;
	}
	public String getNativ_ytd_applied_count() {
		return nativ_ytd_applied_count;
	}
	public void setNativ_ytd_applied_count(String nativ_ytd_applied_count) {
		this.nativ_ytd_applied_count = nativ_ytd_applied_count;
	}
	public String getNativ_mtd_applied_adj_ifyp() {
		return nativ_mtd_applied_adj_ifyp;
	}
	public void setNativ_mtd_applied_adj_ifyp(String nativ_mtd_applied_adj_ifyp) {
		this.nativ_mtd_applied_adj_ifyp = nativ_mtd_applied_adj_ifyp;
	}
	public String getNativ_ytd_applied_adj_ifyp() {
		return nativ_ytd_applied_adj_ifyp;
	}
	public void setNativ_ytd_applied_adj_ifyp(String nativ_ytd_applied_adj_ifyp) {
		this.nativ_ytd_applied_adj_ifyp = nativ_ytd_applied_adj_ifyp;
	}
	public String getNativ_daily_applied_adj_ifyp() {
		return nativ_daily_applied_adj_ifyp;
	}
	public void setNativ_daily_applied_adj_ifyp(String nativ_daily_applied_adj_ifyp) {
		this.nativ_daily_applied_adj_ifyp = nativ_daily_applied_adj_ifyp;
	}
	public String getHybride_daily_applied_afyp() {
		return hybride_daily_applied_afyp;
	}
	public void setHybride_daily_applied_afyp(String hybride_daily_applied_afyp) {
		this.hybride_daily_applied_afyp = hybride_daily_applied_afyp;
	}
	public String getHybride_daily_applied_count() {
		return hybride_daily_applied_count;
	}
	public void setHybride_daily_applied_count(String hybride_daily_applied_count) {
		this.hybride_daily_applied_count = hybride_daily_applied_count;
	}
	public String getHybride_mtd_applied_afyp() {
		return hybride_mtd_applied_afyp;
	}
	public void setHybride_mtd_applied_afyp(String hybride_mtd_applied_afyp) {
		this.hybride_mtd_applied_afyp = hybride_mtd_applied_afyp;
	}
	public String getHybride_mtd_applied_count() {
		return hybride_mtd_applied_count;
	}
	public void setHybride_mtd_applied_count(String hybride_mtd_applied_count) {
		this.hybride_mtd_applied_count = hybride_mtd_applied_count;
	}
	public String getHybride_ytd_applied_afyp() {
		return hybride_ytd_applied_afyp;
	}
	public void setHybride_ytd_applied_afyp(String hybride_ytd_applied_afyp) {
		this.hybride_ytd_applied_afyp = hybride_ytd_applied_afyp;
	}
	public String getHybride_ytd_applied_count() {
		return hybride_ytd_applied_count;
	}
	public void setHybride_ytd_applied_count(String hybride_ytd_applied_count) {
		this.hybride_ytd_applied_count = hybride_ytd_applied_count;
	}
	public String getHybride_mtd_applied_adj_ifyp() {
		return hybride_mtd_applied_adj_ifyp;
	}
	public void setHybride_mtd_applied_adj_ifyp(String hybride_mtd_applied_adj_ifyp) {
		this.hybride_mtd_applied_adj_ifyp = hybride_mtd_applied_adj_ifyp;
	}
	public String getHybride_ytd_applied_adj_ifyp() {
		return hybride_ytd_applied_adj_ifyp;
	}
	public void setHybride_ytd_applied_adj_ifyp(String hybride_ytd_applied_adj_ifyp) {
		this.hybride_ytd_applied_adj_ifyp = hybride_ytd_applied_adj_ifyp;
	}
	public String getHybride_daily_applied_adj_ifyp() {
		return hybride_daily_applied_adj_ifyp;
	}
	public void setHybride_daily_applied_adj_ifyp(String hybride_daily_applied_adj_ifyp) {
		this.hybride_daily_applied_adj_ifyp = hybride_daily_applied_adj_ifyp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
