package com.qc.service.messageimpl;

import com.qc.JsonImpl.NatHybApplied;

public class Applied 
{
	public static String appliedIntent(String period, String source, String msgChannel, String mtdAppliedAFYP, String real_tim_timstamp,
			String channel, String dailyAppliedAFYP, String ytd_applied_afyp,String mtd_applied_adj_ifyp, String ytd_applied_adj_ifyp,
			String daily_applied_adj_ifyp,
			String daily_applied_afyp2, String daily_applied_count2, String daily_applied_adj_ifyp2, String LacsCr)
	{
		String finalresponse="";

		if("MONTHLY".equalsIgnoreCase(period) ||"MTD".equalsIgnoreCase(period) ||"MONTH".equalsIgnoreCase(period))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse=" Monthly Applied Business for "+msgChannel+
						" as of now is : "+mtdAppliedAFYP+" " + LacsCr +". "+"Applied Business Adj IFYP MTD is "+mtd_applied_adj_ifyp+" " + LacsCr +".";
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(msgChannel))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+", for Native ecomm - Applied Business AFYP MTD is "
							+ NatHybApplied.appliedBean.getNativ_mtd_applied_afyp()+" " + LacsCr +", Applied Business Adj IFYP MTD is "
							+ NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". \n\n"
							+ " For Hybrid ecomm - Applied Business AFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_afyp()+" " + LacsCr +", "
							+ " Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +".";
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+" Applied Business AFYP MTD For "+msgChannel+
							": "+mtdAppliedAFYP+" " + LacsCr +". Applied Business Adj IFYP MTD is "+mtd_applied_adj_ifyp+" " + LacsCr +".";
				}
			}
		}
		else if(!"Internet Sales".equalsIgnoreCase(channel) && "YTD".equalsIgnoreCase(period))
		{
			finalresponse="As of "+real_tim_timstamp+" Applied Business AFYP YTD For "+msgChannel+
					": "+ytd_applied_afyp+" " + LacsCr +". Applied Business Adj IFYP YTD is "+ytd_applied_adj_ifyp+" " + LacsCr +".";
		}
		else if(!"Internet Sales".equalsIgnoreCase(channel) && "FTD".equalsIgnoreCase(period))
		{
			//Previous Message After given the CR by Bhavneet we have changed the message 
			/*finalresponse="As of "+real_tim_timstamp+" Applied Business AFYP FTD For "+msgChannel+
					": "+dailyAppliedAFYP+" Cr. "+"Applied Business Adj IFYP FTD is "+daily_applied_adj_ifyp+" Cr.";*/
			finalresponse= "As of "+real_tim_timstamp+", for "+msgChannel+", Applied AFYP - FTD (as on last batch) is "+dailyAppliedAFYP+" " + LacsCr +", "
					+ "and FTD (as on current date) is "+daily_applied_afyp2+" " + LacsCr
							+ "Applied Business Adj IFYP - FTD (as on last batch) is "+daily_applied_adj_ifyp+" " + LacsCr +", and FTD (as on current date) is "+daily_applied_adj_ifyp2+" " + LacsCr;
		}
		else if(!"".equalsIgnoreCase(channel))
		{
			if("google".equalsIgnoreCase(source))
			{
				finalresponse="Current Update for Applied Business of "+msgChannel+" : "
						+ " For the day is, : " +dailyAppliedAFYP+" " + LacsCr
						+", For the month is, : " +mtdAppliedAFYP+" " + LacsCr
						+", For the year is, : " +ytd_applied_afyp+" " + LacsCr;
			}
			else
			{
				if("Internet Sales".equalsIgnoreCase(channel) && "YTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" for Native ecomm - Applied Business AFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getNativ_ytd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\n For Hybrid ecomm - Applied Business AFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP YTD is "+NatHybApplied.appliedBean.getHybride_ytd_applied_adj_ifyp()+" " + LacsCr +".";
				}
				else if("Internet Sales".equalsIgnoreCase(channel) && "FTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" for Native ecomm - Applied Business AFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getNativ_daily_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\n Hybrid ecomm - Applied Business AFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP FTD is "+NatHybApplied.appliedBean.getHybride_daily_applied_adj_ifyp()+" " + LacsCr +".";
				}
				else if("Internet Sales".equalsIgnoreCase(channel) && "MTD".equalsIgnoreCase(period))
				{
					finalresponse="As of "+NatHybApplied.appliedBean.getReal_tim_timstamp()+" for Native ecomm - Applied Business AFYP  is "+NatHybApplied.appliedBean.getNativ_mtd_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getNativ_mtd_applied_adj_ifyp()+" " + LacsCr +". "
							+ "\n\n Hybrid ecomm - Applied Business AFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_afyp()+" " + LacsCr +", "
							+ "Applied Business Adj IFYP MTD is "+NatHybApplied.appliedBean.getHybride_mtd_applied_adj_ifyp()+" " + LacsCr +".";
				}
				else
				{
					finalresponse="As of "+real_tim_timstamp+" Applied AFYP For "+msgChannel+"  is: "
							+ " FTD : " +dailyAppliedAFYP+" " + LacsCr
							+", MTD : " +mtdAppliedAFYP+" " + LacsCr
							+", YTD : " +ytd_applied_afyp+" " + LacsCr +"."
							+" Applied Business Adj IFYP"
							+" MTD : "+mtd_applied_adj_ifyp+" " + LacsCr
							+", YTD :"+ytd_applied_adj_ifyp+" " + LacsCr
							+", FTD : "+daily_applied_adj_ifyp+" " + LacsCr;
				}
				if("Agency".equalsIgnoreCase(msgChannel))
				{
					finalresponse=finalresponse+"\n If you want to see the data for sub-channels, please enter sub-channel name � Defence, Office within office, APC, Greenfield.";
				}
			}
		}
		else
		{
			finalresponse="As of "+real_tim_timstamp+" Applied AFYP"+
					"  is: "
					+ " FTD : " +dailyAppliedAFYP+" " + LacsCr
					+", MTD : " +mtdAppliedAFYP+" " + LacsCr
					+", YTD : " +ytd_applied_afyp+" " + LacsCr +"."
					+" Applied Business Adj IFYP"
					+" MTD : "+mtd_applied_adj_ifyp+" " + LacsCr
					+", YTD :"+ytd_applied_adj_ifyp+" " + LacsCr
					+", FTD : "+daily_applied_adj_ifyp+" " + LacsCr+".";
		}
		return finalresponse.toString();
	}
}