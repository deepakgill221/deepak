package com.qc.DataBean;

public class HubHoldBean 
{
	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String mtd_hub_hold_cases;
	private String ytd_hub_hold_cases;
	private String daily_hub_hold_cases;
	private String mtd_hub_hold_adj_mfyp;
	private String ytd_hub_hold_adj_mfyp;
	private String daily_hub_hold_adj_mfyp;
	private String total_hub_hold_cases;
	private String total_hub_hold_adj_mfyp;
	private String btch_timstamp;
	private String real_tim_timstamp;
	
	
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getMtd_hub_hold_cases() {
		return mtd_hub_hold_cases;
	}
	public void setMtd_hub_hold_cases(String mtd_hub_hold_cases) {
		this.mtd_hub_hold_cases = mtd_hub_hold_cases;
	}
	public String getYtd_hub_hold_cases() {
		return ytd_hub_hold_cases;
	}
	public void setYtd_hub_hold_cases(String ytd_hub_hold_cases) {
		this.ytd_hub_hold_cases = ytd_hub_hold_cases;
	}
	public String getDaily_hub_hold_cases() {
		return daily_hub_hold_cases;
	}
	public void setDaily_hub_hold_cases(String daily_hub_hold_cases) {
		this.daily_hub_hold_cases = daily_hub_hold_cases;
	}
	public String getMtd_hub_hold_adj_mfyp() {
		return mtd_hub_hold_adj_mfyp;
	}
	public void setMtd_hub_hold_adj_mfyp(String mtd_hub_hold_adj_mfyp) {
		this.mtd_hub_hold_adj_mfyp = mtd_hub_hold_adj_mfyp;
	}
	public String getYtd_hub_hold_adj_mfyp() {
		return ytd_hub_hold_adj_mfyp;
	}
	public void setYtd_hub_hold_adj_mfyp(String ytd_hub_hold_adj_mfyp) {
		this.ytd_hub_hold_adj_mfyp = ytd_hub_hold_adj_mfyp;
	}
	public String getDaily_hub_hold_adj_mfyp() {
		return daily_hub_hold_adj_mfyp;
	}
	public void setDaily_hub_hold_adj_mfyp(String daily_hub_hold_adj_mfyp) {
		this.daily_hub_hold_adj_mfyp = daily_hub_hold_adj_mfyp;
	}
	public String getTotal_hub_hold_cases() {
		return total_hub_hold_cases;
	}
	public void setTotal_hub_hold_cases(String total_hub_hold_cases) {
		this.total_hub_hold_cases = total_hub_hold_cases;
	}
	public String getTotal_hub_hold_adj_mfyp() {
		return total_hub_hold_adj_mfyp;
	}
	public void setTotal_hub_hold_adj_mfyp(String total_hub_hold_adj_mfyp) {
		this.total_hub_hold_adj_mfyp = total_hub_hold_adj_mfyp;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
}
