package com.qc.service.messageimpl;
import java.text.DecimalFormat;

import com.qc.DataBean.ProtectionBean;

public class ProtectionYes {

	public static String protectionyesIntent(String channel, String msgChannel, String LacsCr, ProtectionBean protectionBean)
	{
		DecimalFormat df = new DecimalFormat("####");
		
		String finalresponse="";
		if(!"".equalsIgnoreCase(channel))
		{
			
			finalresponse="WIP for "+msgChannel+" Adj MFYP :" +protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_total_wip_count()+" "
					+"\n\n HO WIP Adj MFYP: "+protectionBean.getProtec_ho_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_ho_wip_count()+" "
					+"\n\n GO WIP Adj MFYP: "+protectionBean.getProtec_go_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_go_wip_count()+" "
					+"\n\n IT WIP Adj MFYP: "+protectionBean.getProtec_it_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_it_wip_count()+" "
					+"\n\n FIN WIP Adj MFYP: "+protectionBean.getProtec_fin_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_fin_wip_count()+" "
					+"\n\n MISC WIP Adj MFYP: "+protectionBean.getProtec_misc_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_misc_wip_count()+" "
					+"\n\n WELCOME WIP Adj MFYP: "+protectionBean.getProtec_welcome_wip_adj_mfyp()+" " + LacsCr +". and Policies "+protectionBean.getProtec_welcome_wip_count()+"";
		}
		else
		{
			finalresponse="WIP AdjMFYP: " +protectionBean.getProtec_total_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n HO WIP Adj MFYP: "+protectionBean.getProtec_ho_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n GO WIP Adj MFYP: "+protectionBean.getProtec_go_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n IT WIP Adj MFYP: "+protectionBean.getProtec_it_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n FIN WIP Adj MFYP: "+protectionBean.getProtec_fin_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n MISC WIP Adj MFYP: "+protectionBean.getProtec_misc_wip_adj_mfyp()+" " + LacsCr +"."
					+"\n\n WELCOME WIP Adj MFYP: "+protectionBean.getProtec_welcome_wip_adj_mfyp()+" " + LacsCr +".";
		}
		return finalresponse.toString();
	}
}