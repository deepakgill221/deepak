package com.qc.JsonImpl;

import org.json.JSONObject;

import com.qc.DataBean.NatHybCaseSizeBean;

public class NatHybCaseSize 
{
	public static NatHybCaseSizeBean casesizeBean = new NatHybCaseSizeBean();
	public void natHybCaseSize(JSONObject object)
	{
		try{
			casesizeBean.setNativ_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybCaseSize").get("nativ_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		try{
			casesizeBean.setNativ_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybCaseSize").get("nativ_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		try{
			casesizeBean.setHybrd_case_size_afyp_mtd(object.getJSONObject("payload").getJSONObject("natHybCaseSize").get("hybrd_case_size_afyp_mtd").toString());
		}catch(Exception e){}
		try{
			casesizeBean.setHybrd_case_size_afyp_ytd(object.getJSONObject("payload").getJSONObject("natHybCaseSize").get("hybrd_case_size_afyp_ytd").toString());
		}catch(Exception e){}
		try{
			casesizeBean.setReal_tim_timstamp(object.getJSONObject("payload").getJSONObject("natHybCaseSize").get("real_tim_timstamp").toString());
		}catch(Exception e){}
	}
}
