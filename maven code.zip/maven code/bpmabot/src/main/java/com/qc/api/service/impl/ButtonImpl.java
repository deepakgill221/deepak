package com.qc.api.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.qc.api.service.Button;
import com.qc.common.Facebook;
import com.qc.common.InnerButton;
import com.qc.common.InnerData;

@Component
public class ButtonImpl implements Button {

	List<InnerButton> innerbuttonlist = new ArrayList<InnerButton>();
	Facebook fb = new Facebook();
	InnerData innerData = new InnerData();
	InnerButton button = new InnerButton();
	@Override
	public InnerData getButtonApr() 
	{
		innerbuttonlist=new ArrayList<InnerButton>();
		innerData=new InnerData();
		
		button.setText("APR");
		button.setPostback("APR");
		innerbuttonlist.add(button);

		fb.setButtons(innerbuttonlist);
		fb.setTitle("MLIChatBot");
		fb.setPlatform("API.AI");
		fb.setType("Chatbot");
		fb.setImageUrl("BOT");
		innerData.setFacebook(fb);
		return innerData;
	}
}
