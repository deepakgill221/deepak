package com.qc.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
/**
 * @author sc05216
 * MVC ChatbotController
 *
 */
@Controller
public class ChatBotControllerMVC 
{
	/**
	 * @return : show index page
	 */
	static final String RETURNPAGE="index";
	/**
	 * @return
	 * Root handler i.e. display Home Page
	 */
	@GetMapping("/")
	public String index()
	{
		return RETURNPAGE;
	}
	
}
