package com.qc.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateDiff {

	public static void main(String[] args) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

		try{
		String dateStop = "2019-01-31"; 
		String dateStart = "2019-08-28";  
		
		Date d1 = null;
		Date d2 = null;
		d1 = format.parse(dateStop);
		d2 = format.parse(dateStart);
		int month=0;
		
		/*long diff = d2.getTime() - d1.getTime();
		long diffDays = diff / (24 * 60 * 60 * 1000);
		month = (int) Math.round(diffDays/30.4);
		System.out.println(month);*/
		//Code changed to get value as round off
		/*String[] arr=String.valueOf(monthInDouble).split("\\.");
		int b = Integer.parseInt(arr[1]);*/
		/*int[] intArr=new int[2];
		intArr[1]=Integer.parseInt(arr[1]);*/
		/*for (int number : intArr) {
			decimalpart=number;
	         System.out.println(decimalpart);
	      }
		if(b>=1)
		{
			month=month+1;
		}
		else{
			month=month;
		}*/
		Calendar startCalendar = new GregorianCalendar();
		startCalendar.setTime(d2);
		Calendar endCalendar = new GregorianCalendar();
		endCalendar.setTime(d1);
		
		int diffYear = startCalendar.get(Calendar.YEAR) - endCalendar.get(Calendar.YEAR);
		int diffMonth = diffYear * 12 + startCalendar.get(Calendar.MONTH) - endCalendar.get(Calendar.MONTH);
		int finaldate = Math.abs(diffMonth);
		System.out.println(finaldate);
		}
		catch(Exception ex)
		{
			System.out.println("");
		}
			
	}

}
