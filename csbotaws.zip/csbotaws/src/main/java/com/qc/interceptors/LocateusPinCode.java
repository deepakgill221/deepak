package com.qc.interceptors;

public interface LocateusPinCode 
{
	public String getLocateUsPinCode(String pinCode);

}
