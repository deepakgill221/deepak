package com.qc.interceptors;

import java.util.Map;

public interface PremiumPaymentTerm {

	 public String getPremiumPaymentTerm(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
