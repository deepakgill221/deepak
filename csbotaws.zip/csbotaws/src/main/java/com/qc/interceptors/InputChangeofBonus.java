package com.qc.interceptors;

public interface InputChangeofBonus {
	
	public String getChangeOfBonus(String sessionId);

}
