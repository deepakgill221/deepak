package com.qc.interceptors;

import java.util.Map;

public interface UpdatePAN {
	public String getUpdatePan(String sessionId, String pan, Map<String, Map> personalDetail);
	public String getUpdatePanYes(String sessionId, String policyNo, String pan);

}

