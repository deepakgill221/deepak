package com.qc.interceptors;

public interface LifeStage 
{
	public String getLifeStage(String lifeStage);
	

}
