package com.qc.interceptors;

import java.util.Map;

public interface InputSurrender 
{

	public String getInputSurrender(String sessionId, Map<String, Map> responsecacheOnSessionId);

}
