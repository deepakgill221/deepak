package com.qc.interceptorsimpl;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.qc.common.Commons;
import com.qc.common.CustomizeDate;
import com.qc.interceptors.PremiumPaymentTerm;

@Service
public class PremiumPaymentTermImpl implements PremiumPaymentTerm 
{
	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(PremiumPaymentTermImpl.class);
	
	private static final String BASICDETAILS;
	private static final String RESPONSE;
	private static final String RESPONSEDATA;
	
	
	static
	{
		BASICDETAILS="BasicDetails";
		RESPONSE="response";
		RESPONSEDATA="responseData";
	}
	@Override
	public String getPremiumPaymentTerm(String sessionId, Map<String, Map> responsecacheOnSessionId) 
	{
		
			logger.info("Action Invoded:- Policy.PremiumPaymentTerm");
			String premChngeDtCd = "";
			String premChngAgeDur = "";
			String cvgMatXpryDt = "";
			String cvgIssEffDt = "";
			String cvgPlanIdCd = "";
			String origPlanIdCd = "";
			String maturitycashdata="";
			String policyNumber = "";
			String policyStatusCd = "";
			String policyStatusDesc = "";
			String polDueDate = "";
			String billingFreqCd = "";
			String billingFreqDesc = "";
			List cvgDetails = null;
			String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
			
			Map<String, Object> cashdata = (Map) responsecacheOnSessionId.get(sessionId).get("OverAllMaturityCashData");
			try
			{
				maturitycashdata=cashdata.get("MaturityCashData")+"";
			}
			catch(Exception ex){
				logger.error("exception while extracting data from Map :: "+ex );
			}
			if(maturitycashdata==null || "".equalsIgnoreCase(maturitycashdata))
			{
				maturitycashdata=resProp.getString("validateOTP");
			}
			Map<String, Object> resultData = Commons.getGsonData(maturitycashdata);
			try
			{
			 policyNumber = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get(BASICDETAILS)).get("policyNum").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting policy number from map ::"+ex);
			}
			try{
			 policyStatusCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get(BASICDETAILS)).get("policyStatusCd").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting policyStatusCd from Map :: "+ex);
			}
			try{
			 policyStatusDesc = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get(BASICDETAILS)).get("policyStatusDesc").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting policyStatusDesc from Map :: "+ex);
			}
			try{
			 polDueDate = ((Map) ((Map) ((Map) resultData.get("response")).get(RESPONSEDATA))
					.get("BasicDetails")).get("polDueDate").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting polDueDate from Map :: "+ex);
			}
			try{
			 billingFreqCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get(BASICDETAILS)).get("billingFreqCd").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting billingFreqCd from Map :: "+ex);
			}
			try{
			 billingFreqDesc = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get(BASICDETAILS)).get("billingFreqDesc").toString();
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting billingFreqDesc from Map :: "+ex);
			}
			try{
			 cvgDetails = (List) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
					.get("coverageDetailsArray");
			}
			catch(Exception ex)
			{
				logger.error("Exception in getting billingFreqDesc from Map :: "+ex);
			}
			
			if (cvgDetails != null && cvgDetails.size()>0)
			{
				for (int i = 0; i < cvgDetails.size(); i++)
				{
					String cvgNum = ((Map) cvgDetails.get(i)).get("cvgNum") + "";
					
						if ("01".equals(cvgNum))
						{
							premChngeDtCd = ((Map) cvgDetails.get(i)).get("premChngeDtCd") + "";
							premChngAgeDur = ((Map) cvgDetails.get(i)).get("premChngAgeDur") + "";
							cvgMatXpryDt = ((Map) cvgDetails.get(i)).get("cvgMatXpryDt") + "";
							cvgIssEffDt = ((Map) cvgDetails.get(i)).get("cvgIssEffDt") + "";
							cvgPlanIdCd = ((Map) cvgDetails.get(i)).get("cvgPlanIdCd") + "";
							origPlanIdCd = ((Map) cvgDetails.get(i)).get("origPlanIdCd") + "";
						}
				}
			}
			if ("1".equalsIgnoreCase(policyStatusCd) && 
					!"".equalsIgnoreCase(premChngeDtCd) && 
					!"".equalsIgnoreCase(premChngAgeDur) && 
					!"".equalsIgnoreCase(cvgMatXpryDt) && 
					!"".equalsIgnoreCase(cvgIssEffDt))
			{
				CustomizeDate custdate = new CustomizeDate();
				if (!"A".equalsIgnoreCase(premChngeDtCd))
				{
					int i=0;
					try
					{
						i = custdate.comparetwoDates(polDueDate, cvgMatXpryDt);
					} catch (Exception e)
					{
						logger.error("Exception Occoured while parsing date"+PremiumPaymentTermImpl.class);
					}
					if (i == 2)
					{
						speech = resProp.getString("maturity21");
					} 
					else
					{
						int month = custdate.getMonth(cvgMatXpryDt, polDueDate);
						String customizeDate = custdate.subtractMonth(cvgMatXpryDt, billingFreqCd);
						int billingFreqcd = Integer.parseInt(billingFreqCd);
						int premDueCount1 = month / billingFreqcd;
						speech = resProp.getString("maturity22") + " " + cachePolicyNo + " "
								+ resProp.getString("maturity8") + " "
								+ Commons.convertDateFormat(customizeDate) + " "
								+ resProp.getString("premium25") + " " + premDueCount1
								+ " " + billingFreqDesc + " " + resProp.getString("premium26");
					}
				} else 
				{
					String premChngAgeDurYear = custdate.addYear(cvgIssEffDt, premChngAgeDur);
					int ir=0;
					try 
					{
						ir = custdate.comparetwoDates(polDueDate, premChngAgeDurYear);
					} catch (ParseException e) 
					{
						logger.error("Exception Occoured while parsing date"+e.getMessage()+"  "+e);
					}
					if (ir == 2)
					{
							speech = resProp.getString("maturity21");
					} else
					{
						String getYear = custdate.addYear(cvgIssEffDt, premChngAgeDur);
						String customizeDate = custdate.subtractMonth(getYear, billingFreqCd);
						int month = custdate.getMonth(getYear, polDueDate);
						int billingFreqcd = Integer.parseInt(billingFreqCd);
						int premDueCount2 = month / billingFreqcd;
 						speech = resProp.getString("maturity22") + " " + cachePolicyNo + " "
								+ resProp.getString("maturity8") + " "
								+ Commons.convertDateFormat(customizeDate) + " "
								+ resProp.getString("premium25") + " " + premDueCount2 + " " + billingFreqDesc
								+ " " + resProp.getString("premium26");
					}
				}
			} else {
				if (("3".equalsIgnoreCase(policyStatusCd) || "4".equalsIgnoreCase(policyStatusCd)) && 
						cvgPlanIdCd.equalsIgnoreCase(origPlanIdCd))
				{
						speech=resProp.getString("maturity21");
					} else {
					speech = resProp.getString("maturity22") + " "+policyNumber +" "
							+ resProp.getString("maturity23")+ " "+ policyStatusDesc + " "
							+ resProp.getString("maturity24");
				}
			}
		
		return speech;
	}
}
