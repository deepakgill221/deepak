package com.qc.interceptorsimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.PersonalDetailUpdate;
import com.qc.api.service.PolicyPackHandlerService;
import com.qc.interceptors.InputPolicyPack;

@Service
public class InputPolicyPackImpl implements InputPolicyPack
{
	@Autowired
	PolicyPackHandlerService policyPackHandlerService;
	
	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(InputPolicyPackImpl.class);
	@Override
	public String getInputPolicyPock(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		logger.info("Action Invoded:- Input.PolicyPack");
		String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
		String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
		
		if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
			speech = resProp.getString("validPolicyMessage");
		} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
			speech = resProp.getString("validateOTP").concat(cachePolicyNo);
		} else 
		{
			speech = policyPackHandlerService.getPolicyPackService(cachePolicyNo).get("Message");
			speech = speech + resProp.getString("CTP_CON1_4");
		}
		
		return speech;
	}
}
