package com.qc.interceptorsimpl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.service.PolicyDetailServiceFundValue;
import com.qc.interceptors.InputFund;

@Service
public class InputFundImpl implements InputFund 
{
	@Autowired
	private PolicyDetailServiceFundValue policyDetailServiceFundValue;
	String speech="";
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private Logger logger = LogManager.getLogger(InputReceiptImpl.class);
	
	private static final String MESSAGE;
	
	static 
	{
		MESSAGE="Message";
	}
	@Override
	public String getInputFund(String sessionId, Map<String, Map> responsecacheOnSessionId) {
		logger.info("Action Invoded:- input.Fund");
		String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
		String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
		Map data = (Map) responsecacheOnSessionId.get(sessionId).get("PolData");
		if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
			speech = resProp.getString("validPolicyMessage");
		} else if ("".equalsIgnoreCase(cachevalidOTP) || cachevalidOTP == null) {
			speech = resProp.getString("validateOTP").concat(cachePolicyNo);
		} else {
			if (data.get("FV") == null) {
				speech = ((Map) data.get("ErrorMessage")).get(MESSAGE).toString();
			} else {
				Map fv = (Map) data.get("FV");
				if (fv.get("fundValAsonDate") != null) {

					if (fv.get("FVErrorMessage") != null)
						speech = fv.get("FVErrorMessage").toString();
					else {
						String fvdata = fv.get("fundValAsonDate").toString();
						speech = fv.get(MESSAGE).toString() + " "
								+ Math.round(Double.parseDouble(fvdata) * 100.0) / 100.0;
						String mirDvEffDt = policyDetailServiceFundValue.policyDetilfunValue(cachePolicyNo);
						logger.info("Date retrun from backend ::" + mirDvEffDt);
					}
				} else {
					speech = fv.get(MESSAGE).toString();
				}
			}
		}
		return speech;
	}
}
