package com.qc.interceptorsimpl;

import java.util.ResourceBundle;

import org.springframework.stereotype.Service;

import com.qc.interceptors.InputChangeofBonus;

@Service
public class InputChangeofBonusImpl implements InputChangeofBonus {
	
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");

	String speech;
	
	@Override
	public String getChangeOfBonus(String sessionId) {
		
		speech=resProp.getString("changeofbonus.response");
		return speech;
	}

}
