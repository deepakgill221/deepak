package com.qc.api.service.impl;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.qc.api.hello.InnerData;
import com.qc.api.response.WebhookResponse;
import com.qc.api.service.AddressDetail;
import com.qc.api.service.CsBotService;
import com.qc.api.service.MaturityDate;
import com.qc.api.service.NavDeregistration;
import com.qc.api.service.NavRegistration;
import com.qc.api.service.OTPHandlerService;
import com.qc.api.service.PersonalDetailUpdate;
import com.qc.api.service.PolicyInfoHandlerService;
import com.qc.api.service.PolicyLoanDetail;
import com.qc.api.service.SurrenderProcedureService;
import com.qc.api.service.UpdateAadhaarPanService;
import com.qc.common.AddressDetailService;
import com.qc.common.Adoptionlogs;
import com.qc.common.DateValidator;
import com.qc.common.DbData;
import com.qc.common.RegexMatcher;
import com.qc.common.SessionTimeOut;
import com.qc.interceptors.InputCTP;
import com.qc.interceptors.InputChangeofBonus;
import com.qc.interceptors.InputChangeofNFO;
import com.qc.interceptors.InputFund;
import com.qc.interceptors.InputMaturity;
import com.qc.interceptors.InputPolicyPack;
import com.qc.interceptors.InputProposalStatus;
import com.qc.interceptors.InputReceipt;
import com.qc.interceptors.InputSurrender;
import com.qc.interceptors.LifeStage;
import com.qc.interceptors.LocateusPinCode;
import com.qc.interceptors.PremiumPaymentTerm;
import com.qc.interceptors.UpdateAadhaar;
import com.qc.interceptors.UpdatePAN;

@Service
public class CsBotServiceImpl implements CsBotService{
	
	private static Logger logger = LogManager.getLogger(CsBotServiceImpl.class);
	
	public static final ResourceBundle resProp = ResourceBundle.getBundle("errorMessages");
	private static Map<String, Object> serviceResp;
	private static Map<String, Map> responsecacheOnSessionId;
	private static Map<String, String> mapforcashbeforevalidation;
	private static Map<String, String> mapforrenewalPayment;
	private static Map<String, String> removefromcash;
	private static Map<String, Map> personalDetailMap;
	private static Map<String, String> goalButtons;
	
	private static final String PRODUCT_NAME;
	private static final String POLICY_NUMBER_NOT_FOUND;

	static
	{
		serviceResp = new HashMap<>();
		responsecacheOnSessionId = new ConcurrentHashMap<>();
		mapforcashbeforevalidation = new ConcurrentHashMap<>();
		mapforrenewalPayment = new ConcurrentHashMap<>();
		removefromcash = new ConcurrentHashMap<>();
		personalDetailMap = new ConcurrentHashMap<>();
		goalButtons = new ConcurrentHashMap<>();
		PRODUCT_NAME="Productname";
		POLICY_NUMBER_NOT_FOUND="PolicyNumberNotFound";
	}
	
	
	@Autowired
	OTPHandlerService oTPHandlerService;
	@Autowired
	private PolicyInfoHandlerService policyInfoHandlerService;
	@Autowired
	private MaturityDate maturityDate;
	@Autowired
	private AddressDetail addressDetail;
	@Autowired
	private AddressDetailService addressDetailService;
	@Autowired
	private Adoptionlogs adoption;
	@Autowired
	private PolicyLoanDetail policyLoan;
	@Autowired
	private DateValidator dateValidator;
	@Autowired
	PersonalDetailUpdate personalDetailUpdate;
	@Autowired
	RegexMatcher regexMatcher;
	@Autowired
	private ButtonImpl buttons;
	@Autowired
	private DbData dbData;
	@Autowired
	private PremiumPaymentTerm premiumPaymentTerm;
	@Autowired
	private InputCTP inputCTP;
	@Autowired
	private InputSurrender inputSurrender;
	@Autowired
	private InputReceipt inputReceipt;
	@Autowired
	private InputFund inputFund;
	@Autowired
	private InputMaturity inputMaturity;
	@Autowired
	private InputPolicyPack inputPolicyPack;
	@Autowired
	private LocateusPinCode locateusPinCode;
	@Autowired
	private LifeStage lifeStage;
	@Autowired
	private NavRegistration navRegistration;
	@Autowired
	private NavDeregistration navDeregistration;
	@Autowired
	private UpdateAadhaar updateAadhaar;
	@Autowired
	private UpdatePAN updatePAN;
	@Autowired
	private UpdateAadhaarPanService updateAadhaarService;
	@Autowired
	private SurrenderProcedureService surrenderProcedureService;
	@Autowired
	private InputProposalStatus inputProposalStatus;
	@Autowired
	private InputChangeofNFO inputChangeofNFO;
	@Autowired
	private SessionTimeOut sessionTimeOut;
	@Autowired
	private InputChangeofBonus inputChangeofBonus;
	
	
	@Override
	public WebhookResponse csBotProcess(String jsonStr) {
		
		logger.info("---Inside the Controller----");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		InnerData innerData = new InnerData();
		String speech = null;
		String regex = "^[0-9]{10}$";
		String sessionId = "";
		String action = "";
		String policyNumber = "";
		String resolvedQuery = "";
		String pincode = "";
		String dob = "";
		String newMobileNumber = "";
		String newEmail = "";
		String lifeStages = "";
		String goals = "";
		String productName = "";
		String pan="";
		String ticketId="";
		String otpStatus;
		String otpEnvType = resProp.getString("otp.environment.type");
		try {
			logger.info("Controller : ChatBotController : START");
			JSONObject object = new JSONObject(jsonStr);
			sessionId = object.get("sessionId").toString();
			logger.info("Request Session Id :- " + sessionId);
			action = object.getJSONObject("result").get("action") + "";
			logger.info("--------------Testing----" + action);
			
			resolvedQuery=getResolvedQuery(object);
			
			

			ObjectMapper mapperObj = new ObjectMapper();
			try {
				policyNumber = object.getJSONObject("result").getJSONObject("parameters").getJSONObject("PolicyNumber")
						.get("Given-PolicyNumber") + "";
			} catch (Exception e) {
				policyNumber = "";
			}
			try {
				pincode = object.getJSONObject("result").getJSONObject("parameters").get("pin") + "";
				logger.info("pincode --- testing " + pincode);
			} catch (Exception e) {
				pincode = "";
			}
			try {
				dob = object.getJSONObject("result").getJSONObject("parameters").get("dob") + "";
				logger.info("pincode --- testing " + dob);
			} catch (Exception e) {
				dob = "";
			}
			try {
				newMobileNumber = object.getJSONObject("result").getJSONObject("parameters").get("mobile") + "";
			} catch (Exception e) {
				newMobileNumber = "";
			}
			try {
				newEmail = object.getJSONObject("result").getJSONObject("parameters").get("email") + "";
			} catch (Exception e) {
				newEmail = "";
			}

			try {
				pan = object.getJSONObject("result").getJSONObject("parameters").get("pan") + "".toUpperCase();
				pan=pan.toUpperCase();
			} catch (Exception e) {
				pan = "";
			}
			logger.info("Request PolicyNo :- " + policyNumber);
			if (true) {
				removefromcash.put(sessionId, dtf.format(now));
				if (!"PolicyNumberValidation".equalsIgnoreCase(action) && !"OTPValidation".equalsIgnoreCase(action)
						&& !"OTP.NotAvailable".equalsIgnoreCase(action) && !"HI".equalsIgnoreCase(action)
						&& !"close.conversation".equalsIgnoreCase(action) && !"dobvalidate".equalsIgnoreCase(action)) {
					mapforcashbeforevalidation.put(sessionId, action);
				}
			}
			switch (action) {
			case "HI":
			case "locateus-pincode.locateus-pincode-yes":
			case "PolicyCTP.PolicyCTP-yes":
			case "PolicySurrenderValue.PolicySurrenderValue-yes":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-yes":
			case "PolicyFundValue.PolicyFundValue-yes":
			case "InputMaturity.InputMaturity-yes":
			case "InputPPT.InputPPT-yes":
			case "Policypolicydocument.Policypolicydocument-yes":
			case "PolicyPolicyNumberValidation.PolicyPolicyNumberValidation-yes":
			case "Client-DOB.Client-DOB-yes":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-yes":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-yes":
			case "UpdateAadhar.UpdateAadhar-yes":
			case "credit.credit-yes-2": 
			case "BuyNow.BuyNow-yes":
			case "RequestanAgent.RequestanAgent-yes":
			case "KnowMoreOnline.KnowMoreOnline-yes":
			case "KnowMoreOffline.KnowMoreOffline-yes":
			case "NomineeChange.NomineeChange-yes":
			case "AddressChange.AddressChange-yes":
			case "NAVRegistration.NAVRegistration-yes.NAVRegistration-yes-yes":
			case "NAVDeregistration.NAVDeregistration-yes.NAVDeregistration-yes-yes":
			case "MobileEntered.MobileEntered-no.MobileEntered-no-yes":
			case "EmailEntered.EmailEntered-no.EmailEntered-no-yes":
			case "Final-yes":
			
				logger.info("Action Invoded:- HI");
				if ("HI".equalsIgnoreCase(action)) {
					speech = resProp.getString("initial.message");
					innerData = buttons.getButtonHello(action);
				} else {
					speech = resProp.getString("initial.message.default");
				}
				innerData = buttons.getButtonHello(action);
			
			break;
			case "OTP.NotAvailable": {
				logger.info("CASE :: OTP.NotAvailable :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Action Invoded:- OTP.NotAvailable");
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					Map<String, String> orignalData = oTPHandlerService.getOtpMethod(cachePolicyNo, sessionId, 1, otpEnvType);
					if (orignalData.get("policyotp") != null) {
						responsecacheOnSessionId.put(sessionId, orignalData);
						speech = orignalData.get("Message");
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: OTP.NotAvailable :: END");
			}
			break;
			case "PolicyNumberValidation": 
			{
				logger.info("CASE :: PolicyNumberValidation :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					logger.info("Action Invoded:- PolicyNumberValidation");
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
					String cacheOTP = responsecacheOnSessionId.get(sessionId).get("policyotp") + "";

					logger.info("Inside :: PolicyNumberInSession Check !=null");
					if (cachePolicyNo != null && (cachevalidOTP != null && !"".equalsIgnoreCase(cachevalidOTP))) {
						if (!(policyNumber.equals(cachePolicyNo))) {
							logger.info("A new policy number entered by the customer " + policyNumber	+ "First clear the Cach then Go to api Call");
							responsecacheOnSessionId.clear();
							Map<String, String> orignalData = oTPHandlerService.getOtpMethod(policyNumber, sessionId,0, otpEnvType);
							responsecacheOnSessionId.put(sessionId, orignalData);
							logger.info("END :: Request For Re-Generate PolicyOTP :- " + serviceResp);
							speech = orignalData.get("Message");
							return new WebhookResponse(speech, speech, innerData);
						}
					} else if (!"".equalsIgnoreCase(cachePolicyNo) && cachePolicyNo != null && cachevalidOTP != null
							&& !cachevalidOTP.equalsIgnoreCase("")) {
						logger.info("Inside 2 Check :: PolicyNo & OTP Validation From ehcache");
						speech = resProp.getString("OTPVerification1") + cachePolicyNo
								+ resProp.getString("OTPVerification2");
						logger.info("Message Sent to Api :-" + speech);
					} else if (cachePolicyNo != null) {
						String otpSession = "";
						if (!"".equalsIgnoreCase(cacheOTP) && cacheOTP != null) {
							otpSession = cacheOTP;
						}
						if (!"".equalsIgnoreCase(otpSession) && otpSession != null) {
							if (otpSession.equals(policyNumber)) {
								String lastPremPmtDt = "";
								String actionWithOutHi = "";

								Map data = policyInfoHandlerService.getPolicyInfo(cachePolicyNo);
								try {
									String json = mapperObj.writeValueAsString(data);
									JSONObject jsonObject = new JSONObject(json);
									lastPremPmtDt = jsonObject.getJSONObject("PolicyData").get("lastPremPmtDt") + "";
								} catch (IOException e) {
									logger.info(e);
								}
								Map<String, Object> serviceResp = responsecacheOnSessionId.get(sessionId);
								Map<String, String> maturityData = maturityDate.getMaturityDate(cachePolicyNo);
								serviceResp.put("OverAllMaturityCashData", maturityData);
								serviceResp.put("ValidOTP", cachePolicyNo);
								serviceResp.put("lastPremPmtDt", lastPremPmtDt);
								serviceResp.put("PolData", data);
								serviceResp.remove("policyotp");

								responsecacheOnSessionId.put(sessionId, serviceResp);

								serviceResp.put("otp check", "otp matched");
								responsecacheOnSessionId.put(sessionId+"otp", serviceResp); 

								for (Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet()) {
									String key = entry.getKey();
									if (key.equalsIgnoreCase(sessionId)) {
										action = entry.getValue();
										actionWithOutHi = entry.getValue();
									}

								}
								speech="Hello I am Mili, your Max Life Assistant. Please select from the options below.";
								if ("".equalsIgnoreCase(actionWithOutHi) || actionWithOutHi.isEmpty()) {
									innerData = buttons.getButtonHello("AllButton");
								}

							} else {
								speech = resProp.getString("OTPnotmatch");
								serviceResp.put("otp check", "otp not matched");
								responsecacheOnSessionId.put(sessionId+"otp", serviceResp);
							}
						} else {
							speech = resProp.getString("GenerateOTP");
						}
					}
				} else {
					logger.info("User Enter First Time to Generate OTP");
					logger.info("START :: Request For Generate PolicyOTP");
					Map<String, String> orignalData = oTPHandlerService.getOtpMethod(policyNumber, sessionId, 0, otpEnvType);
					if (!orignalData.get("Message").contains("Oops")) {
						responsecacheOnSessionId.put(sessionId, orignalData);
						logger.info("END :: Request For Generate PolicyOTP :- " + serviceResp);
						speech = orignalData.get("Message");
					} else {
						speech = orignalData.get("Message");
					}
				}
				logger.info("CASE :: PolicyNumberValidation :: END");
			}
			break;
			case "OTPValidation": {
				logger.info("CASE :: OTPValidation :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Action Invoded:- OTPValidation");
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					String cachevalidOTP = responsecacheOnSessionId.get(sessionId).get("ValidOTP") + "";
					String cacheOTP = responsecacheOnSessionId.get(sessionId).get("policyotp") + "";
					if ("".equalsIgnoreCase(cachePolicyNo) || cachePolicyNo == null) {
						speech = resProp.getString("validPolicyMessage");
					} else if (!"".equalsIgnoreCase(cachevalidOTP) && cachevalidOTP != null) {
						speech = resProp.getString("OTPVerification1") + cachePolicyNo
								+  resProp.getString("OTPVerification2");
					} else {
						String otpSession = "";
						String oTPRequest = object.getJSONObject("result").getJSONObject("parameters")
								.getJSONObject("OTP").get("Provided-OTP") + "";
						otpSession = cacheOTP;
						if (!"".equalsIgnoreCase(otpSession) && otpSession != null) {
							if (otpSession.equals(oTPRequest)) {
								speech = "Mr. Arun. What information you want to know about your policy";
								Map data = policyInfoHandlerService.getPolicyInfo(cachePolicyNo);

								Map<String, String> serviceResponse = responsecacheOnSessionId.get(sessionId);
								serviceResponse.put("cachevalidOTP", oTPRequest);
								serviceResponse.remove("policyotp");
								responsecacheOnSessionId.put(sessionId, serviceResponse);
							} else {
								speech = "OTP did not match.Please provide correct OTP.";
							}
						} else {
							speech = "You have not generated OTP.Please provide valid policy to generate OTP";
						}
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: OTPValidation :: END");
			}
			break;
			case "ServiceExistingPolicy": 
			
				logger.info("Action :: ServiceExistingPolicy start");
				speech = "I'm happy to help you with the following options.";
				innerData = buttons.getButtonsHI(action);
				logger.info("Action :: ServiceExistingPolicy end");
			
			break;

			case "CheckoutNewProducts": 
			{
				action = "LIFE STAGE";
				logger.info("Action :: CheckoutNewProducts start");
				speech = "To help me assist you better, please choose your current life stage:";
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				innerData = buttons.getButtonFromDB(result);
				logger.info("Action :: CheckoutNewProducts end");
			}
			break;

			case "LifeStage": 
			{
				action = "GOALS";
				goalButtons.put("LifeStages", resolvedQuery);
				lifeStages=goalButtons.get("LifeStages");
				logger.info("Action :: LifeStage start");
				speech=lifeStage.getLifeStage(lifeStages);
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				innerData = buttons.getButtonFromDB(result);
				logger.info("Action :: LifeStage end");
			}
			break;

			case "Goals": 
			{
				logger.info("Action Invoded :: Goals start");
				action = "PRODUCT NAME";
				goalButtons.put("Goals", resolvedQuery);
				lifeStages=goalButtons.get("LifeStages");
				goals=goalButtons.get("Goals");
				logger.info("Inside Action :: Goals start");
				speech = "Here�s what I have to meet your specific goal:";
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				innerData = buttons.getButtonGoalDB(result);
				logger.info("Action :: Goals end");
			}
			break;

			case "OthersProductName":
			case "Others": 
			{
				logger.info("Action Invoded :: Others start");
				action = "OTHERS";
				lifeStages=goalButtons.get("LifeStages");
				goals=goalButtons.get("Goals");
				logger.info("Inside Action :: Goals start");
				speech = "Here are some more options for you:";
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				innerData = buttons.getButtonFromDB(result);
				logger.info("Action :: Others end");
			}
			break;

			case "ProductName": 
			{
				logger.info("Action Invoded :: ProductName start");
				action = "ONLINE OFFLINE";
				goalButtons.put(PRODUCT_NAME, resolvedQuery);
				lifeStages=goalButtons.get("LifeStages");
				goals=goalButtons.get("Goals");
				productName=goalButtons.get(PRODUCT_NAME);
				logger.info("Action :: ProductName start");
				speech = "It's a great choice! ";
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				action="DESCRIPTION";
				String description=addressDetailService.buttonService(action, lifeStages, goals, productName);
				String dbResponse=dbData.getDbData(description);
				speech=speech+"\n "+dbResponse;
				innerData = buttons.getButtonOnlineOffline(result);
				logger.info("Action Invoded:: ProductName end");
			}
			break;


			case "BuyNow": 
			
				logger.info("Action Invoded :: Buy Now start");
				speech = "Thank you for choosing Max Life Insurance. Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action Invoded :: Buy Now end");
			
			break;

			case "KnowMoreOnline": 
			{
				logger.info("Action Invoded :: KnowMoreOnline start");
				action = "KNOW MORE ONLINE";
				goals=goalButtons.get("Goals");
				lifeStages=goalButtons.get("LifeStages");
				productName=goalButtons.get(PRODUCT_NAME);
				logger.info(" Going to call service to fetch data rfom DB service");
				String result=addressDetailService.buttonService(action, lifeStages, goals, productName);
				String dbResponse=dbData.getDbData(result);
				speech = "Hope the information helped. <a href='"+dbResponse+"' target='_blank'> Click here </a> to buy now or is there anything else I can assist you with? ";
				innerData = buttons.getButtonsYesNo(result);
				logger.info("Action Invoded :: KnowMoreOnline end");
			}
			break;

			case "KnowMoreOffline": 
			
				logger.info("Action :: Know More Offline start");
				speech = "Hope the information helped. <a href='https://www.maxlifeinsurance.com/contact-us' target='_blank'> Click here </a> to request an agent or is there anything else I can assist you with? ";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action :: Know More Offline end");
			
			break;

			case "RequestanAgent": 
			
				logger.info("Action :: RequestanAgent start");
				speech = "Thank you for choosing Max Life Insurance. Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action :: RequestanAgent end");
			
			break;

			default:
			}
			switch (action) 
			{
			case "Input.ProposalStatus":
				logger.info("CASE :: input.ProposalStatus :: START");
				speech=inputProposalStatus.getProposalStatus(sessionId);
				logger.info("CASE :: input.ProposalStatus :: END");
			break;
			
			case "Input.ChangeofNFO":
				logger.info("CASE :: input.ChangeofNFO :: START");
				speech=inputChangeofNFO.getChangeOfNFO(sessionId);
				logger.info("CASE :: input.ChangeofNFO :: END");
			break;
			
			case "Input.ChangeofBonus":
				logger.info("CASE :: input.ChangeofBonus :: START");
				speech=inputChangeofBonus.getChangeOfBonus(sessionId);
				logger.info("CASE :: input.ChangeofBonus :: END");
			break;
			
			case "FurtherAssistant":
				logger.info("CASE :: input.ChangeofBonus :: START");
				speech=resProp.getString("further.option");
				innerData=buttons.getButtonsYesNo(action);
			break;
			
			case "input.CTP": // Premium Due
			
				logger.info("CASE :: input.CTP :: START");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.error(" otp check value is blank : : sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus))
					{
						speech=inputCTP.getInputCTP(sessionId, responsecacheOnSessionId);
						if (!speech.contains("You need to provide valid OTP number which has been sent to your registered mobile number for policy"))
						{
							speech = speech + "<Br/> Is there anything else I can assist you with?";
							innerData=buttons.getButtonsYesNo(action);
						}
					}
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: input.CTP :: END");
			
			break;
			case "input.Surrender": 
			
				logger.info("CASE :: input.Surrender :: START");

				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						speech=inputSurrender.getInputSurrender(sessionId, responsecacheOnSessionId);
						if (!speech.contains(resProp.getString("validateOTP"))) {
							speech = speech + resProp.getString("CTP_CON1_4");
							innerData=buttons.getButtonsYesNo(action);
						} 
					} 
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}
				else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: input.Surrender :: END");
			
			break;
			case "input.Receipt": 

				logger.info("CASE :: input.Receipt :: START");
				
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) 
					{
						speech=inputReceipt.getInputReceipt(sessionId, responsecacheOnSessionId);
						if (!speech.contains(resProp.getString("validateOTP")))
						{
							speech = speech + resProp.getString("CTP_CON1_4");
							innerData=buttons.getButtonsYesNo(action);
						}
					}
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}
				else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: input.Receipt :: END");
			
			break;
			case "input.Fund": 
				logger.info("CASE :: input.Fund :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						speech=inputFund.getInputFund(sessionId, responsecacheOnSessionId);
						if(!speech.contains("You need to provide valid OTP number which has been sent to your registered mobile number for policy"))
						{
							speech = speech + "\n Is there anything else I can assist you with?";
							innerData=buttons.getButtonsYesNo(action);
						}
					} 
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: input.Fund :: END");
			
			break;
			case "Input.Maturity": 
				logger.info("CASE :: Input.Maturity :: START");
				
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						speech=inputMaturity.getInputMaturity(sessionId, responsecacheOnSessionId);
						if(!speech.contains("You need to provide valid OTP number which has been sent to your registered mobile number for policy"))
						{
							speech = speech + "\n Is there anything else I can assist you with?";
							innerData=buttons.getButtonsYesNo(action);
						}
					} 
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: Input.Maturity :: END");
			
			break;
			case "Policy.PremiumPaymentTerm": 
				logger.info("CASE :: Policy.PremiumPaymentTerm :: START");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.error("OTP check value is not found :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						speech = premiumPaymentTerm.getPremiumPaymentTerm(sessionId, responsecacheOnSessionId);
						if (!speech.contains(resProp.getString("validateOTP"))) {
							speech = speech + resProp.getString("CTP_CON1_4");
							innerData = buttons.getButtonsYesNo(action);
						} 
					}
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}
				else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: Policy.PremiumPaymentTerm :: END");
			
			break;
			// For Mail Purpose
			case "Input.PolicyPack": 
				logger.info("CASE :: Input.PolicyPack :: START");

				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					otpStatus = otpStatusCheck(responsecacheOnSessionId, sessionId);
					/*try
					{
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.error("otp check value is not found :: sessionID :: "+sessionId+" :: "+ex);
					}*/
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						speech=inputPolicyPack.getInputPolicyPock(sessionId, responsecacheOnSessionId);
						if(!speech.contains(resProp.getString("validateOTP"))){
							innerData=buttons.getButtonsYesNo(action);
						}
					}
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}else{
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: Input.PolicyPack :: END");
			
			break;
			case "close.clear": 
				sessionTimeOut.removedSessionIdfromCash(serviceResp, responsecacheOnSessionId,
						mapforcashbeforevalidation, mapforrenewalPayment, removefromcash, personalDetailMap);
			
			break;
			case "close.conversation": 
				logger.info("Close.Conversation :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Inside Action :- close.conversation");
					for (Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet()) {
						String key = entry.getKey();
						if (key.equalsIgnoreCase(sessionId)) {
							mapforcashbeforevalidation.remove(sessionId);
						}
					}
					responsecacheOnSessionId.remove(sessionId);
					logger.info("Session_Id Removed :-" + sessionId);
					speech = "Thank you for contacting Max Life. Have a great day!";
				} else {
					speech = "Thank you for contacting Max Life. Have a great day!";
				}
				logger.info("Close.Conversation :: END");
			
			break;
			case "LocateUs": 
				if (true) {
					logger.info("Action Invoded:- Locate Us");
					speech = "Please enter 6 digit pin code to help you with the nearest Max Life office.";
				}
			
			break;
			case "locateuspincode": 
				logger.info("CASE :: locateuspincode :: START");
				try {
					String status=locateusPinCode.getLocateUsPinCode(pincode);
					if ("matched".equalsIgnoreCase(status)) {
						speech = addressDetail.getAddress(pincode);
						if ("".equalsIgnoreCase(speech) || speech.isEmpty()) {
							speech = " Looks like we don�t have any Max Life office situated near to the PIN code entered by you, "
									+ "<a href='https://bit.ly/2Gc5bLa' target='_blank'> Click Here </a>  to locate nearest office in your city."
									+ "\n Is there anything else I can assist you with?";
							innerData = buttons.getButtonsYesNo(action);
						} else {
							speech = speech.concat("\n Is there anything else I can assis you with?");
							innerData = buttons.getButtonsYesNo(action);
						}
					} else {
						speech = "Looks like you have entered incorrect PIN code, please enter valid PIN code.";
					}
				} catch (Exception ex) {
					logger.info("Exception occoured in Locateuspincode statement :: " + ex);
				}
				logger.info("CASE :: locateuspincode :: END");
			
			break;
			case "RenewalPaymentProcedure": 
				logger.info("CASE :: locateuspincode :: START");
				speech = "Please select one of the following options: ";
				innerData = buttons.getButtonsRenewalPaymentProcedure(action);
				mapforrenewalPayment.put(sessionId, sessionId);
				logger.info("CASE :: locateuspincode :: END");
			
			break;
			case "LoanInquiry": 
				logger.info("Action Invoded:- LoanInquiry :: START");
				speech = "Please select one of the following options: ";
				innerData = buttons.getButtonsLoanInquiry(action);
				logger.info("Action Invoded:- LoanInquiry :: END");
			
			break;
			case "loanegigibilitydetails": 
				logger.info("CASE :: loanegigibilitydetails :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					speech = " Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
							+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: loanegigibilitydetails :: END");
			
			break;
			case "outstandingloandetials": 
				logger.info("CASE :: outstandingloandetials :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					speech = " Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
							+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: outstandingloandetials :: END");
			
			break;
			case "dobvalidate": 
				logger.info("CASE :: dobvalidate :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)
						&& mapforcashbeforevalidation.containsKey(sessionId)) {
					boolean status = dateValidator.isThisDateValid(dob);
					if (status) {
						String intent = "";
						for (Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet()) {
							String key = entry.getKey();
							if (key.equalsIgnoreCase(sessionId)) {
								intent = entry.getValue();
							}
						}
						String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
						if ("loanegigibilitydetails".equalsIgnoreCase(intent)) {
							String flag1 = "loanegigibilitydetails";
							speech = policyLoan.policyLoanDetail(cachePolicyNo, dob, flag1);
						} else {
							String flag2 = "outstandingloandetials";
							speech = policyLoan.policyLoanDetail(cachePolicyNo, dob, flag2);
						}
					} else {
						speech = " Please enter policy holder's date of birth in DD-MM-YYYY format.\n"
								+ " Ex: For 3rd December 1987, please enter 03-12-1987.";
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("CASE :: dobvalidate :: END");
			
			break;
			case "UpdatePersonalDetails": 
				logger.info("Action Invoded:- UpdatePersonalDetails :: START");
				speech = "Please select one of the following options: ";
				innerData = buttons.getButtonsUpdatePersonalDetails(action);
				logger.info("Action Invoded:- UpdatePersonalDetails :: END");
			
			break;
			case "UpdateMobile": 
				logger.info("Action Invoded:- UpdateMobile :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}

					if("otp matched".equalsIgnoreCase(otpStatus)) {
						logger.info("Inside Action :- UpdateMobile");
						speech = "Kindly enter the new ten-digit mobile number to be registered with your Max Life policy. Please do not prefix the number with 91, 0, +91.";
					}
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- UpdateMobile :: END");
			
			break;
			case "UpdateEmail": 
				logger.info("Action Invoded:- UpdateEmail :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {

						logger.info("Inside Action :- UpdateEmail");
						speech = "Kindly enter the email id to be registered with your Max Life policy.";
					} 
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}
				else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- UpdateEmail :: END");
			
			break;

			case "UpdatePAN":
				logger.info("Action Invoded:- UpdatePAN :: START");
				
				if (responsecacheOnSessionId.containsKey(sessionId)) 
				{
					try {
						otpStatus=responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
					}
					catch(Exception ex)
					{
						otpStatus="";
						logger.info("otp check value is blank :: sessionID :: "+sessionId+" :: "+ex);
					}
					if("otp matched".equalsIgnoreCase(otpStatus)) {
						logger.info("Inside Action :- UpdatePAN");
						String policyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
						updateAadhaarService.getPolicy360(sessionId, policyNo);
						speech = "Please enter your PAN to update your policy records.";
					} 
					else if("otp not matched".equalsIgnoreCase(otpStatus)){
						speech = resProp.getString("OTPnotmatch");
					}
					else {
							speech=resProp.getString(POLICY_NUMBER_NOT_FOUND)+" "+resProp.getString("PolicyNumberNotFound1")+"";
					}
				}else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- UpdatePAN :: END");
			
			break;
			case "EnterPAN":
				logger.info("Action Invoded:- EnterPAN :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Inside Action :- EnterPAN");
					String policyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					Map<String, String> personalDetail = new ConcurrentHashMap<String, String>();
					personalDetail.put("policyNo", policyNo);
					personalDetail.put("pan",pan);
					personalDetailMap.put(sessionId, personalDetail);
					speech = updatePAN.getUpdatePan(sessionId, pan, personalDetailMap) ;
					if(speech.contains("Sorry the PAN you entered is invalid"))
					{
						innerData = buttons.getButtonsUpdatePersonalDetails(action);
					}
					else
					{
						innerData = buttons.getButtonsYesNo(action);
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- EnterPAN :: END");
			
			break;
			case "EnterPAN.EnterPAN-yes":
				logger.info("Action Invoded:- EnterPAN-yes :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					String policyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					String enteredPan=personalDetailMap.get(sessionId).get("pan")+"";
					speech = updatePAN.getUpdatePanYes(sessionId, policyNo, enteredPan);
					if(speech.contains("Thank you for updating your PAN"))
					{
						ticketId=updateAadhaar.getTicketId(sessionId);
					}
					else
					{
						ticketId="";
					}
					innerData = buttons.getButtonsYesNo(action);
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- EnterPAN-yes :: END");
			
			break;
			case "EnterPAN.EnterPAN-no":
				logger.info("Action Invoded:- EnterPAN-no :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					speech = "No problem! \n Is there anything else I can assist you with? ";
					innerData = buttons.getButtonsYesNo(action);
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- EnterPAN-no :: END");
			break;
			case "AddressChange": 
				logger.info("Action Invoded:- AddressChange :: START");
				logger.info("Inside Action :- AddressChange");
				speech = "Updating address is quick and simple. Please <a href='http://bit.ly/2QxJd6x' target='_blank'> click here </a> "
						+ " to initiate the process.\n Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action Invoded:- AddressChange :: END");
			
			break;
			case "NomineeChange": 
				logger.info("Action Invoded:- NomineeChange :: START");
				speech = "Updating nominee is quick and simple. Please <a href='https://www.maxlifeinsurance.com/customer-service/ServiceRequest/changeNomineeDetails.html' target='_blank'> click here </a> "
						+ " to initiate the process.\n Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action Invoded:- NomineeChange :: END");
			
			break;
			case "MobileEntered": 
				logger.info("Action Invoded:- MobileEntered :: START");
				try {
					if (responsecacheOnSessionId.containsKey(sessionId)) {
						try {
							otpStatus= responsecacheOnSessionId.get(sessionId+"otp").get("otp check")+"";
						}
						catch(Exception ex) {
							otpStatus="";
						}
						String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
						Map<String, String> personalDetail = new ConcurrentHashMap<>();
						if(!personalDetailMap.containsKey(sessionId)) {
							personalDetail.put("newMobileNumber", newMobileNumber);
							personalDetailMap.put(sessionId, personalDetail);
						}
						newMobileNumber=personalDetailMap.get(sessionId).get("newMobileNumber")+"";
						if(!"otp not matched".equalsIgnoreCase(otpStatus) && !"".equalsIgnoreCase(otpStatus)) {
							if (newMobileNumber.matches(regex)) {
								String intent = "MobileNo";

								speech = personalDetailUpdate.getCustomerInfo(cachePolicyNo, intent, newMobileNumber,sessionId);

								if (speech.contains("There is some communication glitch!")) {
									speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
								} else {
									innerData = buttons.getButtonsYesNo(action);
								}
							} else {
								speech = "Sorry! Looks like you've entered an incorrect mobile number. Please enter your mobile number again.";
							}
						}
						else {
							speech = resProp.getString("OTPnotmatch");
						}
					}
					else {
						speech = resProp.getString("validPolicyMessage");
					}
				} catch (Exception e) {
					newMobileNumber = "";
				}
				logger.info("Action Invoded:- MobileEntered :: END");
			
			break;
			case "MobileEntered.MobileEntered-yes": 
				logger.info("Action Invoded:- MobileEntered.MobileEntered-yes :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Inside Action :- MobileEntered.MobileEntered-yes");
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					String cacheMobile = personalDetailMap.get(sessionId).get("newMobileNumber") + "";
					speech = personalDetailUpdate.updateMobile(cachePolicyNo, cacheMobile);
					if (speech.contains("There is some communication glitch!")) {
						speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
					} else {
						innerData = buttons.getButtonsYesNo(action);
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- MobileEntered.MobileEntered-yes :: END");
			
			break;
			case "MobileEntered.MobileEntered-no": 
				logger.info("Action Invoded:- MobileEntered.MobileEntered-no :: START");
				speech = "No problem! \n" + 
						"Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action Invoded:- MobileEntered.MobileEntered-no :: END");
			
			break;
			case "EmailEntered": 
				logger.info("Action Invoded:- EmailEntered :: START");
				try {
					if (responsecacheOnSessionId.containsKey(sessionId)) {
						logger.info("Inside Action :- EmailEntered");
						String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
						Map<String, String> personalDetail = new ConcurrentHashMap<>();
						personalDetail.put("newEmail", newEmail);
						personalDetailMap.put(sessionId, personalDetail);
						boolean result = regexMatcher.isValidEmailAddress(newEmail);
						if (result) {
							String intent = "EmailId";
							speech = personalDetailUpdate.getCustomerInfo(cachePolicyNo, intent, newEmail,sessionId);
							if (speech.contains("There is some communication glitch!")) {
								speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
							} else {
								innerData = buttons.getButtonsYesNo(action);
							}
						} else {
							speech = " Sorry! Looks like you've entered an incorrect email id. Please enter your email id again.";
						}
					} else {
						speech = resProp.getString("validPolicyMessage");
					}
				} catch (Exception e) {
					newEmail = "";
				}
				logger.info("Action Invoded:- EmailEntered :: END");
			

			break;
			case "EmailEntered.EmailEntered-yes": 
				logger.info("Action Invoded:- EmailEntered.EmailEntered-yes :: START");
				if (responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Inside Action :- EmailEntered.EmailEntered-yes");
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					String cacheEmail = personalDetailMap.get(sessionId).get("newEmail") + "";
					speech = personalDetailUpdate.updateEmail(cachePolicyNo, cacheEmail);
					if (speech.contains("There is some communication glitch!")) {
						speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
					} else {
						innerData = buttons.getButtonsYesNo(action);
					}
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- EmailEntered.EmailEntered-yes :: END");
			
			break;
			case "EmailEntered.EmailEntered-no": 
				logger.info("Action Invoded:- EmailEntered.EmailEntered-no :: START");
				speech = "No problem! \n" + 
						"Is there anything else I can assist you with?";
				innerData = buttons.getButtonsYesNo(action);
				logger.info("Action Invoded:- EmailEntered.EmailEntered-no :: END");
			
			break;


			case "NAVRegistration":
			
				logger.info("NAV Registration action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					speech=navRegistration.getNavRegistartion(cachePolicyNo);
					innerData = buttons.getButtonsYesNo(action);
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			

			break;

			case "NAVDeregistration":
			
				logger.info("NAV Deregistration action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					speech=navDeregistration.getNavDeregistartion(cachePolicyNo);
					innerData = buttons.getButtonsYesNo(action);
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			
			break;

			case "NAVRegistration.NAVRegistration-yes": 
			
				logger.info("NAVRegistration.NAVRegistration-yes action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					String transactionType="Activate";
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					speech=navRegistration.navUpadte(cachePolicyNo,transactionType);
					if (speech.contains("There is some communication glitch!")) {
						speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
					} 
					else if(speech.contains("Sorry, I am unable to process your request."))
					{
						speech="Sorry, I am unable to process your request. Kindly try again after some time.</Br>" + 
								"Alternatively, you can call our customer care on 1860-120-5577 or write to us at "                                           
								+"service.helpdesk@maxlifeinsurance.com from your registered email id";
					}
					else {
						innerData = buttons.getButtonsYesNo(action);
					}
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			
			break;

			case "NAVRegistration.NAVRegistration-no": 
			
				logger.info("NAVRegistration.NAVRegistration-no action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					speech="No problem! </Br>" + 
							"Is there anything else I can assist you with? ";
					innerData = buttons.getButtonsYesNo(action);
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			
			break;
			case "NAVDeregistration.NAVDeregistration-yes": 
			
				logger.info("NAVDeregistration.NAVDeregistration-yes action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					String transactionType="Deactivate";
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					speech=navRegistration.navUpadte(cachePolicyNo,transactionType);
					if (speech.contains("There is some communication glitch!")) {
						speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
					} 
					else if(speech.contains("Sorry, I am unable to process your request."))
					{
						speech="Sorry, I am unable to process your request. Kindly try again after some time.</Br>" + 
								"Alternatively, you can call our customer care on 1860-120-5577 or write to us at "                                         
								+"service.helpdesk@maxlifeinsurance.com from your registered email id";
					}
					else {
						innerData = buttons.getButtonsYesNo(action);
					}
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			
			break;

			case "NAVDeregistration.NAVDeregistration-no": 
				logger.info("NAVDeregistration.NAVDeregistration-no action start: ");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					speech="No problem! </Br>" + 
							"Is there anything else I can assist you with? ";
					innerData = buttons.getButtonsYesNo(action);
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			
			break;

			case "SurrenderProcedure":
				logger.info("Action Invoded:- SurrenderProcedure :: START");
				if (responsecacheOnSessionId.containsKey(sessionId))
				{
					String cachePolicyNo = responsecacheOnSessionId.get(sessionId).get("PolicyNo") + "";
					logger.info("Inside Action :- SurrenderProcedure");
					speech=surrenderProcedureService.getSurrenderProcedure(cachePolicyNo);
					if (speech.contains("There is some communication glitch!")) {
						speech = "There is some communication glitch! Please try again after some time. Error Code -MAX00PLD";
					} else {
						innerData = buttons.getButtonsYesNo(action);
					}
				}
				else
				{
					speech = resProp.getString("validPolicyMessage");
				}
			

			break;
			case "PayOnline": 
				logger.info("Action Invoded:- PayOnline :: START");
				if (mapforrenewalPayment.containsKey(sessionId)) {
					logger.info("Inside Action :- PayOnline");
					speech = "We have host of online renewal payment options, you can pay renewal payment through Credit Card, EMI on Card, Net Banking, Debit Cards, Wallets /Cash card and UPI. Do you want to pay now?";
				} else {
					speech=resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- PayOnline :: END");
			
			break;
			case "CreditCardStandingInstruction": 
				logger.info("Action Invoded:- CreditCardStandingInstruction :: START");
				if (mapforrenewalPayment.containsKey(sessionId)) {
					logger.info("Inside Action :- CreditCardStandingInstruction");
					speech = "You simply need to fill up the credit card mandate form and send it to us along with the scanned copy of the front side of your credit card at service.helpdesk@maxlifeinsurance.com. "
							+ "To download the credit card mandate form <a href='https://goo.gl/CSWygD' target='_blank'> click here. </a>  \n Is there anything else I can assist you with?";
					innerData = buttons.getButtonsYesNo(action);
				} else {
					speech = resProp.getString("validPolicyMessage");
				}
				logger.info("Action Invoded:- CreditCardStandingInstruction :: END");
			
			break;
			case "DirectDebit": 
				logger.info("Action Invoded:- DirectDebit :: START");
				if (mapforrenewalPayment.containsKey(sessionId)) {
					logger.info("Inside Action :- DirectDebit");
					speech = "To opt for direct debit facility, please send the duly filled ECS Mandate form along with a cancelled cheque at least 30 days before your next premium due date to us from your registered mail ID to service.helpdesk@maxlifeinsurance.com, "
							+ "alternatively you can submit the same at any of our branch offices. "
							+ "To download the direct debit mandate form "
							+ "<a href='https://goo.gl/htCdWy' target='_blank'> click here </a> \n Is there anything else I can assist you with?";
					innerData = buttons.getButtonsYesNo(action);

				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
				logger.info("Action Invoded:- DirectDebit :: END");
			
			break;
			case "OtherProcedures": 
				logger.info("Action Invoded:- OtherProcedures :: START");
				if (mapforrenewalPayment.containsKey(sessionId)) {
					logger.info("Inside Action :- OtherProcedures");
					speech = "To know more about other payment options, <a href=' https://bit.ly/2fH8ITN' target='_blank'> click here </a> \n"
							+ "\n Is there anything else I can assist you with?";
					innerData = buttons.getButtonsYesNo(action);
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
				logger.info("Action Invoded:- OtherProcedures :: END");
			
			break;
			case "PayOnline.PayOnline-yes": 
				logger.info("Action Invoded:- PayOnline.PayOnline-yes :: START");
				if (mapforrenewalPayment.containsKey(sessionId)) {
					logger.info("Inside Action :- PayOnline.PayOnline-yes");
					speech = "<a href='https://bit.ly/1Wis1l9' target='_blank'> Click here </a> to pay your renewal payment \n Is there anything else I can assist you with?";
					innerData = buttons.getButtonsYesNo(action);
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
				logger.info("Action Invoded:- PayOnline.PayOnline-yes :: END");
			
			break;
			case "PayOnline.PayOnline-no":
			case "credit.credit-yes":
			case "directdebit.directdebit-yes":
			case "others.others-yes":
			case "PayOnline.PayOnline-yes.PayOnline-yes-yes": 
				if (mapforrenewalPayment.containsKey(sessionId)) {
					speech = "I can help you with following options on your policy.";
					innerData = buttons.getButtonsHI(action);
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			
			break;

			case "chatyes":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-yes": 
				speech = "Glad to serve you. Have a good Day.";
			
			break;

			case "chatno":
			case "PolicyCTP.PolicyCTP-no.PolicyCTP-no-no":
			case "PolicySurrenderValue.PolicySurrenderValue-no.PolicySurrenderValue-no-no":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no.PolicyPremiumReceipt-no-no":
			case "PolicyFundValue.PolicyFundValue-no.PolicyFundValue-no-no":
			case "InputMaturity.InputMaturity-no.InputMaturity-no-no":
			case "InputPPT.InputPPT-no.InputPPT-no-no":
			case "Policypolicydocument.Policypolicydocument-no.Policypolicydocument-no-no":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-no":
			case "Client-DOB.Client-DOB-no.Client-DOB-no-no":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no.EmailEntered-yes-no-no":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no.MobileEntered-yes-no-no":
			case "UpdateAadhar.UpdateAadhar-no.UpdateAadhar-no-no":
			case "BuyNow.BuyNow-no":
			case "RequestanAgent.RequestanAgent-no":
			case "KnowMoreOnline.KnowMoreOnline-no":
			case "KnowMoreOffline.KnowMoreOffline-no":
			case "AddressChange.AddressChange-no":
			case "NomineeChange.NomineeChange-no":
			case "NAVRegistration.NAVRegistration-yes.NAVRegistration-yes-no":
			case "NAVDeregistration.NAVDeregistration-yes.NAVDeregistration-yes-no":
			case "Final-no":

				logger.info("Inside final action :: START");
				speech = "Please let me know how helpful I was today?";
				innerData = buttons.getHelpfulSomeHelpful(action);
				logger.info("Final action :: END");
			
			break;
			case "helpful": 
				speech = "I am glad I was of help! Thank you for reaching out to me, good day!";
			
			break;

			case "notHelpful":
			case "SomewhatHelpful": 
				speech = "Sometimes, I may not have the information you need. I am a virtual assistant "
						+ "and I am still learning. However, thank you for your valuable feedback, "
						+ "it will help me service you better next time.\n Good day!";
			
			break;

			case "customerexperience": 
				speech = "Thank you for your feedback, will work on improving your experience.";
			
			break;
			case "others.others-no":
			case "credit.credit-no":
			case "directdebit.directdebit-no":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no":
			case "PolicyCTP.PolicyCTP-no":
				// code added
			case "PolicySurrenderValue.PolicySurrenderValue-no":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no":
			case "PolicyFundValue.PolicyFundValue-no":
			case "InputMaturity.InputMaturity-no":
			case "InputPPT.InputPPT-no":
			case "Policypolicydocument.Policypolicydocument-no":
			case "PolicyPolicyNumberValidation.PolicyPolicyNumberValidation-no":
			case "Client-DOB.Client-DOB-no":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no":
			case "UpdateAadhar.UpdateAadhar-no": 
			case "MobileEntered.MobileEntered-no.MobileEntered-no-no":
			case "EmailEntered.EmailEntered-no.EmailEntered-no-no":
			
				if (mapforrenewalPayment.containsKey(sessionId) || responsecacheOnSessionId.containsKey(sessionId)) {
					speech = "Please let me know how helpful I was today?";
					innerData = buttons.getHelpfulSomeHelpful(action);
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			
			break;
			case "locateus-pincode.locateus-pincode-no": 
				action = "instafeedback-2";
			
			break;
			case "main.options": 
				speech = resProp.getString("PolicyCTP.PolicyCTP-no");
				if (!"I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity."
						.equalsIgnoreCase(speech)) {
					innerData = buttons.getButtonsHI(action);
				}
			
			break;
			default:
			}
			switch (action) {
			case "instafeedback": 
				logger.info("Action Invoded:- InstaFeedBack");
				speech = "Thank you for contacting Max Life. Was the chat helpful to you ?(Yes/No)";
			
			break;
			case "instafeedback-2": 
				logger.info("Action Invoded:- InstaFeedBack");
				speech = "Thank you for contacting Max Life. Was the chat helpful to you?(Yes/No)";
			
			break;

			case "feedback.feedback-yes":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no.PayOnline-yes-no-yes":
			case "credit.credit-no.credit-no-yes":
			case "directdebit.directdebit-no.directdebit-no-yes":
			case "others.others-no.others-no-yes":
			case "PolicyCTP.PolicyCTP-no.PolicyCTP-no-yes":
				// code added
			case "PolicySurrenderValue.PolicySurrenderValue-no.PolicySurrenderValue-no-yes":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no.PolicyPremiumReceipt-no-yes":
			case "PolicyFundValue.PolicyFundValue-no.PolicyFundValue-no-yes":
			case "InputMaturity.InputMaturity-no.InputMaturity-no-yes":
			case "InputPPT.InputPPT-no.InputPPT-no-yes":
			case "Policypolicydocument.Policypolicydocument-no.Policypolicydocument-no-yes":
			case "Client-DOB.Client-DOB-no.Client-DOB-no-yes":
			case "EmailEntered.EmailEntered-yes.EmailEntered-yes-no.EmailEntered-yes-no-yes":
			case "MobileEntered.MobileEntered-yes.MobileEntered-yes-no.MobileEntered-yes-no-yes":
			case "UpdateAadhar.UpdateAadhar-no.UpdateAadhar-no-yes":
				//
			
				if (mapforrenewalPayment.containsKey(sessionId) || responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Action Invoded:- feedback.feedback-yes");
					instaCallBack(sessionId);
					speech = "Glad to serve you. Have a good Day.";
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
			
			break;
			case "chatyes":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-yes":
			
				speech = "Glad to serve you. Have a good Day.";
			
			break;

			case "chatno":
			case "PolicyCTP.PolicyCTP-no.PolicyCTP-no-no":
			case "PolicySurrenderValue.PolicySurrenderValue-no.PolicySurrenderValue-no-no":
			case "PolicyPremiumReceipt.PolicyPremiumReceipt-no.PolicyPremiumReceipt-no-no":
			case "PolicyFundValue.PolicyFundValue-no.PolicyFundValue-no-no":
			case "InputMaturity.InputMaturity-no.InputMaturity-no-no":
			case "InputPPT.InputPPT-no.InputPPT-no-no":
			case "Policypolicydocument.Policypolicydocument-no.Policypolicydocument-no-no":
			case "locateus-pincode.locateus-pincode-no.locateus-pincode-no-no":
			case "Client-DOB.Client-DOB-no.Client-DOB-no-no": 
				speech = "Please share your experience.";
			
			break;
			case "customerexperience": 

				speech = "Thank you for your feedback, will work on improving your experience.";
			
			break;
			case "feedback.feedback-no":
			case "PayOnline.PayOnline-yes.PayOnline-yes-no.PayOnline-yes-no-no":
			case "credit.credit-no.credit-no-no":
			case "directdebit.directdebit-no.directdebit-no-no":
			case "others.others-no.others-no-no":
			
				logger.info("Action Invoded :- feedback.feedback-no :: START");
				if (mapforrenewalPayment.containsKey(sessionId) || responsecacheOnSessionId.containsKey(sessionId)) {
					logger.info("Inside Action :- feedback.feedback-no");
					instaCallBack(sessionId);
					speech = "Thank you for your feedback, will work on improving your experience.";
				} else {
					speech = "I haven't recognized you yet. Let me know your Policy Number so that i can verify your identity.";
				}
				logger.info("Action Invoded :- feedback.feedback-no :: END");
			
			break;
			default:
			}
		} catch (Exception e) {
			logger.error("Error in CS bot controller :: "+e);
		}

		///for adoption logs code start
		try{
			String status;
			String dbSessionId=sessionId;
			String dbPolicyNumber="";
			String dbResolvedQuery=resolvedQuery;
			String db2PolicyNumber="";
			if(responsecacheOnSessionId.containsKey(sessionId))
			{
				String cachePolicyNo=responsecacheOnSessionId.get(sessionId).get("PolicyNo")+"";
				dbPolicyNumber=cachePolicyNo;
			}else
			{
				dbPolicyNumber=policyNumber;
			}
			String dbAction=action;
			if("EnterPAN.EnterPAN-yes".equalsIgnoreCase(action))
			{
				db2PolicyNumber=ticketId;
			}
			else
			{
				db2PolicyNumber=dbPolicyNumber;
			}
			String db3PolicyNumber=db2PolicyNumber;
			String dbspeech=speech;
			if("customerexperience".equalsIgnoreCase(action))
			{
			String ResolvedQuery=resolvedQuery.substring(19,(resolvedQuery.length()));
			dbResolvedQuery=ResolvedQuery;
			}
			else
			{
			dbResolvedQuery=resolvedQuery;
			}
			String db2ResolvedQuery=dbResolvedQuery;
			
			

			logger.info("Adoption Logs :: going to call adoption log api");

			Runnable runnable = () -> {
				logger.info("Run Method Start");
				String response = adoption.adoptionlogsCall(dbSessionId, db3PolicyNumber, dbAction, db2ResolvedQuery,
						dbspeech);
				logger.info("Adoption log status :: " + response);
			};
			Thread t1 = new Thread(runnable);
			t1.start();
			t1.join();
			logger.info("Adoption Logs :: END");
		
		}catch(Exception ex)
		{
			logger.info("Excption Occoured while saving data in to the database");
		}

		/// adoption call end

		logger.info("final Speech:-"+speech);
		return new WebhookResponse(speech, speech, innerData);
	}
	
	private String getResolvedQuery(JSONObject object) {
		String resolvedQuery=null;
		try {
			resolvedQuery = object.getJSONObject("result").get("resolvedQuery") + "";
			
		} catch (Exception ex) {
			logger.error("----Exception in Resolved Query----" + ex);
			resolvedQuery = "";
		}
		
		return resolvedQuery;
	}

	public String instaCallBack(String sessionId) {
		String speech = "";
		logger.info("Inside instaCallBAck method :: START");
		if (responsecacheOnSessionId.containsKey(sessionId) || mapforrenewalPayment.containsKey(sessionId)) {
			logger.info("Action Invoded:- close.conversation");
			for (Map.Entry<String, String> entry : mapforcashbeforevalidation.entrySet()) {
				String key = entry.getKey();
				if (key.equalsIgnoreCase(sessionId)) {
					mapforcashbeforevalidation.remove(sessionId);
					mapforrenewalPayment.remove(sessionId);
				}
			}
			responsecacheOnSessionId.remove(sessionId);
			mapforrenewalPayment.remove(sessionId);
			logger.info("Session_Id Removed :-" + sessionId);
			speech = "Thank you for contacting Max Life. Have a great day!";
		} else {
			speech = "Thank you for contacting Max Life. Have a great day!";
		}
		return speech;
	}
	
	private String otpStatusCheck(Map<String, Map> map, String sessionId){
		String otpStatus;
		try
		{
			otpStatus=map.get(sessionId+"otp").get("otp check")+"";
		}
		catch(Exception ex)
		{
			otpStatus="";
			logger.error("otp check value is not found :: sessionID :: "+sessionId+" :: "+ex);
		}
		
		return otpStatus;
	}


	@Scheduled(cron = "0 0/30 * * * ?")
	public void removeUnUsedSessionFromCache() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		logger.info("Spring Schedular START ::" + dtf.format(now));
		sessionTimeOut.removedSessionIdfromCash(serviceResp, responsecacheOnSessionId, mapforcashbeforevalidation,
				mapforrenewalPayment, removefromcash, personalDetailMap);
		logger.info("Spring Schedular END ::" + dtf.format(now));
	}

}
