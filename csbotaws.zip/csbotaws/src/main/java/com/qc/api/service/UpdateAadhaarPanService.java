package com.qc.api.service;

import java.util.Map;

public interface UpdateAadhaarPanService 
{
	public void getPolicy360(String sessionId, String policyNo);
	public Map getPanDetails(String sessionId);
	public String updateAadhaar(String sessionId, Map<String, Map> personal_detail);
	public String getPanNo(String SessionId);
	public String validatePAN(String sessionId, String pan,Map<String, Map> personal_detail);
	public String updatePan(String sessionId, String policyNo, String pan);
	public String getLeadIdForAadhaar(String sessionId);
	public String getTicketIdForPan(String sessionId);
}
