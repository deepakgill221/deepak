package com.qc.api.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.concurrent.ConcurrentHashMap;
import javax.net.ssl.HttpsURLConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.api.service.UpdateAadhaarPanService;
import com.qc.common.Commons;
import com.qc.common.Httpurl_Connection;

@Component
public class UpdateAadhaarPanServiceImpl implements UpdateAadhaarPanService{
	
	private static Logger logger = LogManager.getLogger(UpdateAadhaarPanServiceImpl.class);
	private static final Map<String, Map<String, String>> aadhaarPanMap = new ConcurrentHashMap<>();  
	public static final ResourceBundle res = ResourceBundle.getBundle("errorMessages");
	
	private static final String RESPONSE;
	private static final String RESPONSEDATA;
	private static final String VAR_POLICY_OWNER_ID;
	
	static
	{
		RESPONSE="response";
		RESPONSEDATA="responseData";
		VAR_POLICY_OWNER_ID="var_policyOwnerId";
	}
	
	@Autowired
	private Httpurl_Connection httpurlConnection;
	
	String varPolicyOwnerId = "";
	String result="";
	String emalId="";
	String mobNum="";
	String dob="";
	String lastName="";
	String policyNo="";
	String aadhaar="";
	String aadhaarStatus="";
	String panNo="";
	String firstName="";
	String panStatus="";
	String leadId="";
	String ticketId="";
	
	String output;
	HttpURLConnection conn = null;
	@Override
	public void getPolicy360(String sessionId, String policyNo) {
		try
		{
			String methodIdentifier = "PolicyInfo";
			String serviceResult = httpurlConnection.httpConnection_response(policyNo, methodIdentifier, "");
			Map resultData = Commons.getGsonData(serviceResult);
			JSONObject object = new JSONObject(resultData);
			varPolicyOwnerId = object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).getJSONObject("BasicDetails").get(VAR_POLICY_OWNER_ID).toString();
			Map<String, String> innerMap = new HashMap<>();
			innerMap.put("var_policyOwnerId", varPolicyOwnerId);
			aadhaarPanMap.put(sessionId,innerMap);
		}
		catch(Exception ex)
		{
			logger.info("Exception in method :: getPolicy360 for sessionId :: "+sessionId);
		}
	}
	
	@Override
	public Map getPanDetails(String sessionId)
	{
		logger.info("Start method :: getPanDetails");
		Map<String, String> innerMap=null;
		varPolicyOwnerId=aadhaarPanMap.get(sessionId).get(VAR_POLICY_OWNER_ID)+"";
		try
		{
			String serviceUrl = res.getString("get_PAN_Details");
			URL url = new URL(serviceUrl);
			StringBuilder resultData=new StringBuilder();
			logger.info("SERVICE URL CALLED ::  "+serviceUrl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder sb=new StringBuilder();
			sb.append("{");
			sb.append("\"request\": {");
			sb.append("\"header\": {");
			sb.append("\"soaCorrelationId\": \"225163708\",");
			sb.append("\"soaAppId\": \"NEO\"");
			sb.append(" }, ");
			sb.append("\"payload\": {");
			sb.append("\"clientId\": \""+varPolicyOwnerId+"\"");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			logger.info("START External API Call : getPANDetails");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try
			{writer.close();}
			catch(Exception ex)
			{}
			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode==200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("END External API Call : getPANDetails");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
					conn.disconnect();
					br.close();
				}
			}
			if(apiResponseCode==200)
			{
				result=resultData.toString();
				JSONObject object=new JSONObject(result);
				emalId=object.getJSONObject(RESPONSE).getJSONObject("payload").getJSONObject("clientPersonalDetails").get("emalId")+"";
				mobNum=object.getJSONObject(RESPONSE).getJSONObject("payload").getJSONObject("clientPersonalDetails").get("mobNum")+"";
				dob=object.getJSONObject(RESPONSE).getJSONObject("payload").get("dob")+"";
				lastName=object.getJSONObject(RESPONSE).getJSONObject("payload").get("lastName")+"";
				panNo=object.getJSONObject(RESPONSE).getJSONObject("payload").get("panNo")+"";
				firstName=object.getJSONObject(RESPONSE).getJSONObject("payload").get("firstName")+"";
				innerMap = new HashMap<>();
				innerMap.put("emalId", emalId);
				innerMap.put("mobNum", mobNum);
				innerMap.put("dob", dob);
				innerMap.put("lastName", lastName);
				innerMap.put("panNo", panNo);
				innerMap.put("firstName", firstName);
				innerMap.put(VAR_POLICY_OWNER_ID, varPolicyOwnerId);
				aadhaarPanMap.put(sessionId, innerMap);
			}
			else
			{
				panNo="";
				logger.info("Unsuccessful response from getPANDetails API for sessionID :: "+sessionId);
			}
		}
		catch(Exception ex)
		{
			logger.info("Exception in method :: getPanDetails :: "+ex);
		}
		return innerMap;
	}
	
	@Override
	public String getPanNo(String sessionId)
	{
		logger.info("Inside method :: getPanNo");
		try
		{
		panNo=aadhaarPanMap.get(sessionId).get("panNo");
		}
		catch(Exception ex)
		{
			panNo="";
			logger.info("Exception while getting value from aadhaarPanMap  :: "+ex);
			
		}
		logger.info("End method :: getPanNo");
		return panNo;
	}
	
	@Override
	public String validatePAN(String sessionId, String pan, Map<String, Map> personalDetail)
	{
		logger.info("START calling validate PAN API");
		String panResponse="";
		try
		{
			StringBuilder resultData=new StringBuilder();
			String serviceUrl = res.getString("validate_PAN_api");
			firstName=aadhaarPanMap.get(sessionId).get("firstName");
			lastName=aadhaarPanMap.get(sessionId).get("lastName");
			dob=aadhaarPanMap.get(sessionId).get("dob");
			mobNum=aadhaarPanMap.get(sessionId).get("mobNum");
			logger.info("SERVICE URL  CALLED :: "+serviceUrl);
			URL url = new URL(serviceUrl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder sb=new StringBuilder();
			sb.append("{");
			sb.append("\"Header\": {");
			sb.append("\"Version\": \"1.0\",");
			sb.append("\"CorrelId\": \"25897\",");
			sb.append("\"ConsumerId\": \"NEO\",");
			sb.append("\"UserID\": \"NEO123\",");
			sb.append("\"Password\": \"bmVvQDEyMw==\"");
			sb.append(" }, ");
			sb.append("\"Request\": {");
			sb.append("\"fname\": \""+firstName+"\",");
			sb.append("\"mname\": \"\",");
			sb.append("\"lname\": \""+lastName+"\",");
			sb.append("\"dob\": \""+dob+"\",");
			sb.append("\"gender\": \"\",");
			sb.append("\"email\": \"\",");
			sb.append("\"careOf\": \"\"," );
			sb.append("\"houseNo\": \"\"," );
			sb.append("\"street\": \"\",");
			sb.append("\"landmark\": \"\",");
			sb.append("\"location\": \"\",");
			sb.append("\"postOffice\": \"\",");
			sb.append("\"vill_city\": \"\",");
			sb.append("\"subDistrict\": \"\",");
			sb.append("\"district\": \"\",");
			sb.append("\"state\": \"\",");
			sb.append("\"stateCode\": \"\",");
			sb.append("\"postalCode\": \"\",");
			sb.append("\"mobileno\": \"\",");
			sb.append("\"pan\": \""+pan+"\",");
			sb.append("\"validationType\": \"PAN\",");
			sb.append("\"app_name\": \"TPP\"");
			sb.append("}");
			sb.append("}");
			logger.info("START External API Call : validate PAN API");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try
			{writer.close();}
			catch(Exception ex)
			{}
			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode==200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("END External API Call : validatePAN");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
					conn.disconnect();
					br.close();
				}
			}
			if(apiResponseCode==200)
			{
				result=resultData.toString();
				JSONObject object=new JSONObject(result);
				panResponse=object.getJSONObject("Response").getJSONObject(RESPONSE).get("pan")+"";
			}
			else
			{
				panResponse="failure";
				logger.info("Unsuccessful response from API  :: "+serviceUrl);
				logger.info("Aadhaar status for session ID :: "+sessionId +" is ::"+panResponse);
				
			}
		}
		catch(Exception ex)
		{
			logger.info("Excepton in method :: validatePAN :: "+ex);
		}
		
		return panResponse;
	}
	
		
	@Override
	public String updateAadhaar(String sessionId, Map<String, Map> personalDetail)
		{
		logger.info("START calling Update Aadhaar API");
		try
		{
			StringBuilder resultData=new StringBuilder();
			String serviceUrl = res.getString("update_aadhaar_api");
			emalId=aadhaarPanMap.get(sessionId).get("emalId");
			mobNum=aadhaarPanMap.get(sessionId).get("mobNum");
			dob=aadhaarPanMap.get(sessionId).get("dob");
			lastName=aadhaarPanMap.get(sessionId).get("lastName");
			policyNo=personalDetail.get(sessionId).get("policyNo")+"";
			aadhaar=personalDetail.get(sessionId).get("Aadhaar")+"";
			SimpleDateFormat dateTimeInGMT = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss.SSS");
			String date=dateTimeInGMT.format(new Date());
			logger.info("SERVICE URL CALLED :: "+serviceUrl);
			URL url = new URL(serviceUrl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder sb=new StringBuilder();
			sb.append("{");
			sb.append("\"request\": {");
			sb.append("\"header\": {");
			sb.append("\"soaCorrelationId\": \"221547fdfd2255dsds\",");
			sb.append("\"soaAppId\": \"CSBOT\"");
			sb.append(" }, ");
			sb.append("\"requestData\": {");
			sb.append("\"emailId\": \""+emalId+"\",");
			sb.append("\"mobileNumber\": \""+mobNum+"\",");
			sb.append("\"dob\": \""+dob+"\",");
			sb.append("\"policyNumber\": \""+policyNo+"\",");
			sb.append("\"adhaarNumber\": \""+aadhaar+"\",");
			sb.append("\"lastName\": \""+lastName+"\",");
			sb.append("\"alternateNumber\": \"\"," );
			sb.append("\"alternareEmail\": \"\"," );
			sb.append("\"moduleName\": \"Aadhar\",");
			sb.append("\"leadCreateDateTime\": \""+date+"\",");
			sb.append("\"queryType\": \"A\"");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			logger.info("START External API Call : getPANDetails");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try
			{writer.close();}
			catch(Exception ex)
			{
				logger.info("Excpetion in calling API :: getPANDetails :: "+serviceUrl);
			}
			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode==200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("END External API Call : getPANDetails");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
					conn.disconnect();
					br.close();
				}
			}
			if(apiResponseCode==200)
			{
				result=resultData.toString();
				JSONObject object=new JSONObject(result);
				aadhaarStatus=object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).get("soaMessage")+"";
				leadId=object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).get("leadId")+"";
				Map<String, String> innerMap = new HashMap<>();
				innerMap.put("leadId", leadId);
				aadhaarPanMap.put(sessionId, innerMap);
			}
			else
			{
				aadhaarStatus="failure";
				logger.info("Unsuccessful response from API :: "+serviceUrl);
				logger.info("Aadhaar status for session ID :: "+sessionId +" is :: "+aadhaarStatus);
			}
		}
		catch(Exception ex)
		{
			logger.info("Exception in method :: updateAadhaar" +ex);
		}
		
		return aadhaarStatus;
	}

	@Override
	public String updatePan(String sessionId, String policyNo, String pan) {

		logger.info("Start method :: updatePan");
		varPolicyOwnerId = aadhaarPanMap.get(sessionId).get(VAR_POLICY_OWNER_ID)+"";
		firstName = aadhaarPanMap.get(sessionId).get("firstName");
		lastName = aadhaarPanMap.get(sessionId).get("lastName");
		logger.info("START calling Update PAN API");
		try
		{
			StringBuilder resultData=new StringBuilder();
			String serviceUrl = res.getString("update_PAN_api");
			SimpleDateFormat dateTimeInGMT = new SimpleDateFormat("dd-MM-yyyy:hh:mm:ss");
			SimpleDateFormat dateTimeInGMT1 = new SimpleDateFormat("hh:mm:ss");
			SimpleDateFormat dateTimeInGMT2 = new SimpleDateFormat("dd-MM-yyyy");
			String date=dateTimeInGMT.format(new Date());
			String currentTime=dateTimeInGMT1.format(new Date());
			String currentDate=dateTimeInGMT2.format(new Date());
			logger.info("SERVICE URL CALLED :: "+serviceUrl);
			URL url = new URL(serviceUrl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder sb=new StringBuilder();
			sb.append("{");
			sb.append("\"request\": {");
			sb.append("\"header\": {");
			sb.append("\"soaCorrelationId\": \"225163708\",");
			sb.append("\"soaAppId\": \"CSBOT\"");
			sb.append(" }, ");
			sb.append("\"payload\": {");
			sb.append("\"policyNo\": \""+policyNo+"\",");
			sb.append("\"workTypeName\": \"Pan Updation\",");
			sb.append("\"caseIntroductionDateTime\": \""+date+"\",");
			sb.append("\"goReceivedTime\": \""+currentTime+"\",");
			sb.append("\"goReceivedDate\": \""+currentDate+"\",");
			sb.append("\"customerLetterDate\": \""+currentDate+"\",");
			sb.append("\"hoReceivedDate\": \""+currentDate+"\"," );
			sb.append("\"sourceApplication\": \"CSBOT\"," );
			sb.append("\"requestorType\": \"Customer\",");
			sb.append("\"ssoId\": \"\",");
			sb.append("\"requestedDateTime\": \""+date+"\",");
			sb.append("\"policyHolderName\": \""+firstName+" "+lastName+"\",");
			sb.append("\"clientIdPolicyOwner\": \""+varPolicyOwnerId+"\",");
			sb.append("\"panCardNumber\": \""+pan+"\",");
			sb.append("\"panCardSubmitted\": \"Y\"");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			logger.info("START External API Call : updatePAN");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			try
			{writer.close();}
			catch(Exception ex)
			{
				logger.info("Exception in calling API : updatePAN :: "+ex);
			}
			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode==200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("END External API Call : updatePAN");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				while((output=br.readLine()) != null)
				{
					resultData.append(output);
					conn.disconnect();
					br.close();
				}
			}
			if(apiResponseCode==200)
			{
				result=resultData.toString();
				JSONObject object=new JSONObject(result);
				panStatus=object.getJSONObject(RESPONSE).getJSONObject("msgInfo").get("msg")+"";
				ticketId=object.getJSONObject(RESPONSE).getJSONObject("payload").get("ticketId")+"";
				Map<String, String> innerMap = new HashMap<>();
				innerMap.put("ticketId", ticketId);
				aadhaarPanMap.put(sessionId, innerMap);
				logger.info("PAN status :: "+panStatus);
			}
			else
			{
				panStatus="failure";
				logger.info("PAN status for session ID :: "+sessionId +" is :: "+panStatus);
				logger.info("Unsuccessful response from API :: "+serviceUrl);
			}
		}
		catch(Exception ex)
		{
			logger.info("Error in updatePan method  :: "+ex);
		}
		
		return panStatus;		
	}
	
	@Override
	public String getLeadIdForAadhaar(String sessionId)
	{
		logger.info("Start method :: getLeadIdForAadhaar");
		try
		{
		leadId=aadhaarPanMap.get(sessionId).get("leadId");
		}
		catch(Exception ex)
		{
			panNo="";
			logger.info("Exception while getting value from aadhaarPanMap :: "+ex);
		}
		logger.info("End method :: getLeadIdForAadhaar");
		return leadId;
	}
	
	@Override
	public String getTicketIdForPan(String sessionId)
	{
		logger.info("Start method :: getTicketIdForPan");
		try
		{
			ticketId=aadhaarPanMap.get(sessionId).get("ticketId");
		}
		catch(Exception ex)
		{
			ticketId="";
			logger.info("Exception while getting value from aadhaarPanMap :: "+ex);
		}
		logger.info("End method :: getTicketIdForPan");
		return ticketId;
	}
	
}
