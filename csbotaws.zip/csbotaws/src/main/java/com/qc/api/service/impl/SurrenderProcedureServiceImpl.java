package com.qc.api.service.impl;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.qc.api.service.SurrenderProcedureService;
import com.qc.common.Commons;
import com.qc.common.DateValidator;
import com.qc.common.Httpurl_Connection;

@Component
public class SurrenderProcedureServiceImpl implements SurrenderProcedureService
{
	public static final ResourceBundle res = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(SurrenderProcedureServiceImpl.class);

	private static final String BASICDETAILS;
	private static final String RESPONSE;
	private static final String RESPONSEDATA;
	
	static
	{
		BASICDETAILS="BasicDetails";
		RESPONSE="response";
		RESPONSEDATA="responseData";
	}
	@Autowired
	DateValidator dateValidator;
	
	public String getSurrenderProcedure(String policyNo)
	{
		String result="";
		try
		{
			logger.info("CameInside Method :: getNavRegistartion :: START ");
			Httpurl_Connection connection = new Httpurl_Connection(); 
			String policyInfo = "PolicyInfo";
			String policyDetail ="PolicyDetail";
			String finaldate = "";
			Map resultData=null;
			String str = connection.httpConnection_response(policyNo, policyInfo, finaldate);
			logger.info("PolicyInfo360 API Response From Backend ::  " + str);

			resultData = Commons.getGsonData(str);
			String soaStatusCode = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA)).get("soaStatusCode")
					.toString();
			if (soaStatusCode != null && !"".equalsIgnoreCase(soaStatusCode) && soaStatusCode.equalsIgnoreCase("200"))
			{
				String policyInsuranceTypeCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyInsuranceTypeCd").toString();
				
				String policyStatusCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyStatusCd").toString();
				
				String policyBasePlanIdCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyBasePlanIdCd").toString();
				
				String policyPmtTerm = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyPmtTerm").toString();
				
				String policyIssueDt = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyIssueDt").toString();
				

				String fundValAsonDate = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get("PolicyMeasures")).get("fundValAsonDate").toString();
				
				String policyStatusDesc = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyStatusDesc").toString();		
				
				if("1".equalsIgnoreCase(policyStatusCd) || "2".equalsIgnoreCase(policyStatusCd) ||
						"1A".equalsIgnoreCase(policyStatusCd) || "3".equalsIgnoreCase(policyStatusCd)||"4".equalsIgnoreCase(policyStatusCd))
						{
					if("N".equalsIgnoreCase(policyInsuranceTypeCd) || "D".equalsIgnoreCase(policyInsuranceTypeCd)||
							"F".equalsIgnoreCase(policyInsuranceTypeCd) || "C".equalsIgnoreCase(policyInsuranceTypeCd))
					{
						if(!"0".equalsIgnoreCase(fundValAsonDate))
						{
							String flag=dateValidator.dateCheck1(policyIssueDt);
							
							if(flag.contains("There is some communication glitch!"))
							{
								result="There is some communication glitch! Please try again after some time. Error Code -MAX00Surrender";
							}
							else
							{
							int value=Integer.parseInt(flag);
							if(0<=value)
							{
							result="To proceed with this request, please visit your nearest Max Life office in-person along with the following documents:</Br> "
									+ "Surrender form duly signed by the policy holder (assignee if the policy is assigned ), "
									+ "Signature form duly signed by the policy holder & insured, Policy pack, Copy of self attested and OSVed id proof, "
									+ "Completely filled NEFT details - printed copy of cancelled cheque/passbook with account holder's name and account number, "
									+ "Copy of Adhaar card </Br></Br>Important points to remember:</Br> PAN should be mentioned in the surrender form itself. "
									+ "If the customer does not have a PAN, he should furnish a declaration for the same. </Br> "
									+ "If the customer is an NRI, the NRI questionnaire should be filled up. Under MWPA Policies - Request should be signed by the both, "
									+ "the policyholder and the nominee, along with KYC documents. "
									+ "Stamp is required in case a company is the policy holder.</Br></Br> I understand that the list of requirements is long, "
									+ "but they are necessary to a ensure smooth and hassle-free procedure.</Br></Br> "
									+ "Is there anything else I can assist you with?";
							}
							else
							{
							result="I can see that your policy is eligible for surrender. Kindly note that, as per the terms of the contract, "
									+ "you will not receive your payout right away.</Br> To proceed with this request, "
									+ "please visit your nearest Max Life office in-person along with the following documents:</Br> "
									+ "Surrender form duly signed by the policy holder (assignee if the policy is assigned), "
									+ "Signature form duly signed by the policy holder & Insured, Policy pack,Copy of self attested and OSVed id proof, "
									+ "Completely filled NEFT details-printed copy of cancelled cheque/passbook with account holder's name and account number, "
									+ "Copy of Adhaar card </Br></Br>Important points to remember </Br>PAN should be mentioned in the surrender form itself. "
									+ "If the customer does not have a PAN, he should furnish a declaration for the same.</Br> "
									+ "If the customer is an NRI, the NRI questionnaire should be filled up. "
									+ "Under MWPA Policies-Request should be signed by the both, the policyholder and the nominee, along with KYC documents. "
									+ "Stamp is required in case a company is the policy holder. </Br></Br>I understand that the list of requirements is long, "
									+ "but they are necessary to a ensure smooth and hassle-free procedure.</Br></Br> "
									+ "Is there anything else I can assist you with?";
							}
							}
						}
						else
						{
							result="Sorry, your policy is not eligible for surrender as there is no surrender value available.</Br>"+
									"Is there anything else I can assist you with? ";
						}
					}
					else
					{
						String surrenderApiData=connection.httpConnection_response(policyNo, policyDetail, finaldate);
						logger.info("Surrender API Response From Backend ::  " + surrenderApiData.toString());
						resultData = Commons.getGsonData(surrenderApiData);
						String mirDvPolCsvAmt = ((Map) ((Map) ((Map) resultData.get("response")).get("responseData"))
								.get("cashSurrenderValue")).get("MIR-DV-POL-CSV-AMT").toString();
						double value=Double.parseDouble(mirDvPolCsvAmt);
						if(0<value)
						{
							if("TGM6".equalsIgnoreCase(policyBasePlanIdCd) || "TGM11".equalsIgnoreCase(policyBasePlanIdCd))
							{
								
								String flag=dateValidator.dateCheck2(policyIssueDt,policyPmtTerm);
								
								if(flag.contains("There is some communication glitch!"))
								{
									result="There is some communication glitch! Please try again after some time. Error Code -MAX00Surrender";
								}
								else
								{
								int value2=Integer.parseInt(flag);
								if(0<=value2)
								{
								
								result="Sorry, your policy is not eligible for surrender as your premium payment term is completed.</Br>"
										+ "Is there anything else I can assist you with? ";
								}
								else
								{
									result="To proceed with this request, please visit your nearest Max Life office in-person along with the following documents:</Br> "
											+ "Surrender form duly signed by the policy holder (assignee if the policy is assigned ), "
											+ "Signature form duly signed by the policy holder & insured, Policy pack, Copy of self attested and OSVed id proof, "
											+ "Completely filled NEFT details - printed copy of cancelled cheque/passbook with account holder's name and account number, "
											+ "Copy of Adhaar card </Br></Br>Important points to remember:</Br> PAN should be mentioned in the surrender form itself. "
											+ "If the customer does not have a PAN, he should furnish a declaration for the same. </Br> "
											+ "If the customer is an NRI, the NRI questionnaire should be filled up. Under MWPA Policies-Request should be signed by the both, "
											+ "the policyholder and the nominee, along with KYC documents. "
											+ "Stamp is required in case a company is the policy holder.</Br></Br> I understand that the list of requirements is long, "
											+ "but they are necessary to a ensure smooth and hassle-free procedure.</Br></Br> "
											+ "Is there anything else I can assist you with?";	
								}
								}
							}
							else
							{
								result="To proceed with this request, please visit your nearest Max Life office in-person along with the following documents:</Br> "
										+ "Surrender form duly signed by the policy holder (assignee if the policy is assigned ), "
										+ "Signature form duly signed by the policy holder & insured, Policy pack, Copy of self attested and OSVed id proof, "
										+ "Completely filled NEFT details - printed copy of cancelled cheque/passbook with account holder's name and account number, "
										+ "Copy of Adhaar card </Br></Br>Important points to remember:</Br> PAN should be mentioned in the surrender form itself. "
										+ "If the customer does not have a PAN, he should furnish a declaration for the same. </Br> "
										+ "If the customer is an NRI, the NRI questionnaire should be filled up. Under MWPA Policies-Request should be signed by the both, "
										+ "the policyholder and the nominee, along with KYC documents. "
										+ "Stamp is required in case a company is the policy holder.</Br></Br> I understand that the list of requirements is long, "
										+ "but they are necessary to a ensure smooth and hassle-free procedure.</Br></Br> "
										+ "Is there anything else I can assist you with?";
							}
						}
						else
						{
							result="Sorry, your policy is not eligible for surrender as there is no surrender value available.</Br>"+
									"Is there anything else I can assist you with? ";
						}
					}
						}
				else
				{
					result="Sorry, your policy is not eligible for surrender as your policy satus is "+policyStatusDesc+".</Br>" + 
							"Is there anything else that I can help you with?";
				}
			}
			else
			{
				result="Getting error : while calling backend service:: soaStatusCode is :-"+soaStatusCode;
			}
         }catch(Exception ex)
		     {
        	 	logger.info("Exception in Surrender procedure service impl :: "+ex);
        	 
		     }
		return result;
        }
 }
