package com.qc.api.service;

public interface SurrenderProcedureService {

	public String getSurrenderProcedure(String policyNo);
}
