package com.qc.api.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ResourceBundle;
import javax.net.ssl.HttpsURLConnection;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.common.Utils;

@Service
public class CustomerInfoService {

	public static final ResourceBundle resourceProperty;
	private static Logger logger=null;
	static
	{
		resourceProperty = ResourceBundle.getBundle("errorMessages");
		logger = LogManager.getLogger(PersonalDetailUpdate.class);
	}
	
	@Autowired
	private Utils utils;
	
	public String customerInfo(String policyNo,String sessionId) {
		String  devMode = "N";
		String resultData = null;
		String output = "";
		HttpURLConnection conn = null;
		OutputStreamWriter writer=null;
		BufferedReader custRequest=null;
		int correlationId;
		String soaAppId="";
		String soaMsgVersion="";

		try {
			String serviceurl = resourceProperty.getString("getcustomer_info_url");
			logger.info("SERVICE URL :-"+serviceurl);
			correlationId=utils.getRandomNumber();
			logger.info("SessionId :: "+sessionId +" Policy No :: "+policyNo+" correlationId :: "+correlationId);
			soaAppId=resourceProperty.getString("cust.info.soa.app.id");
			soaMsgVersion=resourceProperty.getString("cust.info.soa.msg.version");
			URL url = new URL(serviceurl);
			if(devMode!=null && !"".equalsIgnoreCase(devMode) && "Y".equalsIgnoreCase(devMode))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			}else{
				conn = (HttpURLConnection) url.openConnection();
			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder sb=new StringBuilder();
			sb.append("{ ");
			sb.append("\"request\": { ");
			sb.append("\"header\": { ");
			sb.append("\"soaMsgVersion\": \""+soaMsgVersion+"\",");
			sb.append("\"soaCorrelationId\": \""+correlationId+"\",");
			sb.append("\"soaAppId\": \""+soaAppId+"\"");
			sb.append("}, ");
			sb.append("\"requestData\": { ");
			sb.append("\"policyNo\": \""+policyNo+"\" ");
			sb.append("}");
			sb.append("}");
			sb.append("}");
			logger.info("START External API Call : getcustomerinfo");
			writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(sb.toString());
			writer.flush();
			int apiResponseCode = conn.getResponseCode();
			logger.info("API Response Code : getcustomerinfo"+ apiResponseCode);
			//Format changed to remove duplicacy ---by sapna
			if(apiResponseCode == 200)
			{
				custRequest = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			}
			else
			{
				custRequest = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
			}
			StringBuilder temp = new StringBuilder();
			while ((output = custRequest.readLine()) != null) 
			{
				temp.append(output);
			}
			resultData = temp.toString();
			logger.info("END External API Call : getcustomerinfo");
		}
		catch(Exception ex) {
			logger.error("Exception in getting customer info by calling getcustomer api :: "+ex);
		}
		finally{
			try{
				
				if(custRequest!=null)
				{
					custRequest.close();
				}
				if(writer!=null)
				{
					writer.close(); 
				}
				if(conn!=null)
				{
					conn.disconnect();
				}
			}
			catch(Exception ex)
			{
				logger.error("Exception while closing connection :: "+ex);
			}
		}
		return resultData;
	}

}
