package com.qc.api.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.qc.common.Commons;
import com.qc.common.Httpurl_Connection;

@Component
public class PolicyInfoHandlerService {
	public static final ResourceBundle res = ResourceBundle.getBundle("errorMessages");
	private static Logger logger = LogManager.getLogger(PolicyInfoHandlerService.class);

	private static final String RESPONSE;
	private static final String RESPONSEDATA;
	private static final String BASICDETAILS;
	private static final String MESSAGE;
	private static final String CTPAMT;
	private static final String POLICYBASEPLANIDDESC;
	private static final String POLDUEDATE;

	static {
		RESPONSE = "response";
		RESPONSEDATA = "responseData";
		BASICDETAILS = "BasicDetails";
		MESSAGE = "Message";
		CTPAMT = "ctpAmt";
		POLICYBASEPLANIDDESC = "policyBasePlanIdDesc";
		POLDUEDATE = "polDueDate";
	}

	public Map getPolicyInfo(String policyNo) {
		logger.info("CameInside Method :: getPolicyInfo :: START ");
		Map<String, String> map = new HashMap();
		Map<String, Map> returnMap = new HashMap<>();
		JSONArray array = null;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDateTime now = LocalDateTime.now();
		logger.info(dtf.format(now));
		try {
			Httpurl_Connection connection = new Httpurl_Connection();
			String policyInfo = "PolicyInfo";
			String finaldate = "";
			double sum = 0;
			String result = connection.httpConnection_response(policyNo, policyInfo, finaldate);
			logger.info("PolicyInfo API Response From Backend ::  " + result);

			Map resultData = Commons.getGsonData(result);
			JSONObject object = new JSONObject(resultData);
			array = object.getJSONObject(RESPONSE).getJSONObject(RESPONSEDATA).getJSONArray("coverageDetailsArray");
			String soaStatusCode = ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA)).get("soaStatusCode")
					.toString();
			if (soaStatusCode != null && !"".equalsIgnoreCase(soaStatusCode) && soaStatusCode.equalsIgnoreCase("200")) {
				String polBasePlanIdDesc = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get(POLICYBASEPLANIDDESC).toString();
				String polCtpAmt = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA)).get(BASICDETAILS))
						.get(CTPAMT).toString();
				String policyDueDate = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get(POLDUEDATE).toString();

				String polStatusCode = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyStatusCd").toString();

				String polmodprem = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get("PolicyMeasures")).get("polModPrem").toString();

				String polStatusDesc = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyStatusDesc").toString();
				String lastPremPmtDt = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("lastPremPmtDt").toString();

				try {

					for (int i = 0; i < array.length(); i++) {
						String riderServTax = array.getJSONObject(i).getString("riderServTax") + "";
						sum += Double.parseDouble(riderServTax);

					}
				} catch (Exception ex) {

				}
				sum = sum + Double.parseDouble(polmodprem);
				Map<String, String> myPolicyData = new HashMap();

				myPolicyData.put("polStatusCode", polStatusCode);
				myPolicyData.put("polStatusDesc", polStatusDesc);
				myPolicyData.put(POLICYBASEPLANIDDESC, polBasePlanIdDesc);
				myPolicyData.put("lastPremPmtDt", lastPremPmtDt);

				returnMap.put("PolicyData", myPolicyData);

				policyDueDate = Commons.convertDateFormat(policyDueDate);
				map.put(POLICYBASEPLANIDDESC, polBasePlanIdDesc);
				map.put(CTPAMT, polCtpAmt);
				map.put(POLDUEDATE, policyDueDate);

				if ("".equalsIgnoreCase(polCtpAmt) || "".equalsIgnoreCase(policyDueDate)) {

					map.put(MESSAGE, res.getString("CTP_CON5_1"));
					returnMap.put("ErrorMessage", map);

				}
				String policyInsuranceTypeCd = ((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA))
						.get(BASICDETAILS)).get("policyInsuranceTypeCd").toString();

				if ("N".equals(policyInsuranceTypeCd) || "F".equals(policyInsuranceTypeCd)
						|| "D".equals(policyInsuranceTypeCd) || "C".equals(policyInsuranceTypeCd)) {
					Map<String, String> fvMap = new HashMap();
					fvMap.put("fundValAsonDate",
							((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA)).get("PolicyMeasures"))
									.get("fundValAsonDate").toString());
					fvMap.put("discontinuanceFund",
							((Map) ((Map) ((Map) resultData.get(RESPONSE)).get(RESPONSEDATA)).get("BasicDetails"))
									.get("discontinuanceFund").toString());

					if (!("1".equals(polStatusCode) || "2".equals(polStatusCode) || "3".equals(polStatusCode)
							|| "4".equals(polStatusCode) || "5".equals(polStatusCode) || "1A".equals(polStatusCode)))
						fvMap.put("FVErrorMessage", res.getString("FV_CON1_1") + " " + policyNo + " "
								+ res.getString("FV_CON1_2") + " " + polStatusDesc + " " + res.getString("FV_CON1_3"));
					else
						//// Manish
						fvMap.put(MESSAGE, res.getString("InquiringFVTrue") + dtf.format(now) + " "
								+ res.getString("InquiringFVTrue1") + ".");

					returnMap.put("FV", fvMap);
				} else {
					Map<String, String> fvMap = new HashMap<>();
					fvMap.put(MESSAGE,
							"I see from the records that fund value is not applicable for the policy number you have provided.");
					fvMap.put("Message", res.getString("InquiringFVfalse"));
					returnMap.put("FV", fvMap);
				}

				if ("8".equals(policyInsuranceTypeCd) || "1".equals(policyInsuranceTypeCd)) {
					logger.info("CSV not Applicable");
					Map<String, String> csv = new HashMap<>();
					csv.put(MESSAGE, res.getString("cashSurrenderNotApplicable1"));
					returnMap.put("CSV", csv);
				}
				try {
					if ("1".equals(policyInsuranceTypeCd)) {
						if (Double.parseDouble(polCtpAmt) == 0) {
							if (Commons.dateDiff(policyDueDate) < 0) {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE, res.getString("CTP_CON1_1") + " " +
								// polmodprem
										sum + " " + res.getString("CTP_CON1_5") + " " + res.getString("CTP_CON1_2")
										+ " " + policyDueDate + res.getString("CTP_CON1_3"));
								returnMap.put("CTP", fvMap);
							} else {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE,
										res.getString("CTP_CON6_1") + " " + policyNo + " " + res.getString("CTP_CON6_2")
												+ " " + polStatusDesc + " " + res.getString("CTP_CON6_3"));
								returnMap.put("CTP", fvMap);
							}
						} else if (Commons.dateDiff(policyDueDate) <= 30) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE,
									res.getString("CTP_CON2_1") + " " + policyDueDate + " "
											+ res.getString("CTP_CON2_2") + " " + polCtpAmt + " "
											+ res.getString("CTP_CON2_3"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 30 && Commons.dateDiff(policyDueDate) <= 90) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON3_1") + " (" + polStatusDesc + ") "
									+ res.getString("CTP_CON3_2") + " " + policyDueDate + res.getString("CTP_CON3_4")
									+ " " + polCtpAmt + res.getString("CTP_CON3_5") + res.getString("CTP_CON3_6"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 90 && Commons.dateDiff(policyDueDate) < 180) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE,
									res.getString("CTP_CON4_1") + polStatusDesc + res.getString("CTP_CON4_5")
											+ policyDueDate + res.getString("CTP_CON4_4") + res.getString("CTP_CON4_6")
											+ res.getString("CTP_CON4_7") + res.getString("CTP_CON4_8")
											+ res.getString("CTP_CON4_9"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 180) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON5_1"));
							returnMap.put("CTP", fvMap);
						} else {
							Map<String, String> fvMap = new HashMap<>();

							fvMap.put(MESSAGE,
									res.getString("dueAmountPolicy1") + " " + policyNo + " "
											+ res.getString("dueAmountPolicy2") + " " + polCtpAmt + " "
											+ res.getString("dueAmountPolicy3") + " " + policyDueDate);
							fvMap.put(CTPAMT, polCtpAmt);
							fvMap.put(POLDUEDATE, policyDueDate);
							returnMap.put("CTP", fvMap);
						}
					}

					///// new addition

					else if ("I".equals(policyInsuranceTypeCd)) {
						if (Double.parseDouble(polCtpAmt) == 0) {
							if (Commons.dateDiff(policyDueDate) < 0) {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE,
										res.getString("CTP_CON1_1") + " " + sum + " " + res.getString("CTP_CON1_5")
												+ " " + res.getString("CTP_CON1_2") + " " + policyDueDate
												+ res.getString("CTP_CON1_3"));
								returnMap.put("CTP", fvMap);
							} else {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE,
										res.getString("CTP_CON6_1") + " " + policyNo + " " + res.getString("CTP_CON6_2")
												+ " " + polStatusDesc + " " + res.getString("CTP_CON6_3"));
								returnMap.put("CTP", fvMap);
							}
						} else if (Commons.dateDiff(policyDueDate) <= 30) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE,
									res.getString("CTP_CON2_1") + " " + policyDueDate + " "
											+ res.getString("CTP_CON2_2") + " " + polCtpAmt + " "
											+ res.getString("CTP_CON2_3"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 30 && Commons.dateDiff(policyDueDate) <= 180) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON3_1") + " (" + polStatusDesc + ") "
									+ res.getString("CTP_CON3_2") + " " + policyDueDate + res.getString("CTP_CON3_4")
									+ " " + polCtpAmt + res.getString("CTP_CON3_5") + res.getString("CTP_CON3_6"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 180) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON5_1"));
							returnMap.put("CTP", fvMap);
						} else {
							Map<String, String> fvMap = new HashMap<>();

							fvMap.put(MESSAGE,
									res.getString("dueAmountPolicy1") + " " + policyNo + " "
											+ res.getString("dueAmountPolicy2") + " " + polCtpAmt + " "
											+ res.getString("dueAmountPolicy3") + " " + policyDueDate);
							fvMap.put(CTPAMT, polCtpAmt);
							fvMap.put(POLDUEDATE, policyDueDate);
							returnMap.put("CTP", fvMap);
						}
					} else {
						if (Double.parseDouble(polCtpAmt) == 0) {
							if (Commons.dateDiff(policyDueDate) < 0) {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE, res.getString("CTP_CON1_1") + " " +
								// polmodprem
										sum + " " + res.getString("CTP_CON1_5") + " " + res.getString("CTP_CON1_2")
										+ " " + policyDueDate + res.getString("CTP_CON1_3"));
								returnMap.put("CTP", fvMap);
							} else {
								Map<String, String> fvMap = new HashMap<>();
								fvMap.put(MESSAGE,
										res.getString("CTP_CON6_1") + " " + policyNo + " " + res.getString("CTP_CON6_2")
												+ " " + polStatusDesc + " " + res.getString("CTP_CON6_3"));
								returnMap.put("CTP", fvMap);
							}
						} else if (Commons.dateDiff(policyDueDate) <= 30) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE,
									res.getString("CTP_CON2_1") + " " + policyDueDate + " "
											+ res.getString("CTP_CON2_2") + " " + polCtpAmt + " "
											+ res.getString("CTP_CON2_3"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 30 && Commons.dateDiff(policyDueDate) <= 180) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON3_1") + " (" + polStatusDesc + ") "
									+ res.getString("CTP_CON3_2") + " " + policyDueDate + res.getString("CTP_CON3_4")
									+ " " + polCtpAmt + res.getString("CTP_CON3_5") + res.getString("CTP_CON3_6"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 180 && Commons.dateDiff(policyDueDate) < 1095) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE,
									res.getString("CTP_CON4_1") + polStatusDesc + res.getString("CTP_CON4_5")
											+ policyDueDate + res.getString("CTP_CON4_4") + res.getString("CTP_CON4_6")
											+ res.getString("CTP_CON4_7") + res.getString("CTP_CON4_8")
											+ res.getString("CTP_CON4_9"));
							returnMap.put("CTP", fvMap);
						} else if (Commons.dateDiff(policyDueDate) > 1095) {
							Map<String, String> fvMap = new HashMap<>();
							fvMap.put(MESSAGE, res.getString("CTP_CON5_1"));
							returnMap.put("CTP", fvMap);
						} else {
							Map<String, String> fvMap = new HashMap<>();

							fvMap.put(MESSAGE,
									res.getString("dueAmountPolicy1") + " " + policyNo + " "
											+ res.getString("dueAmountPolicy2") + " " + polCtpAmt + " "
											+ res.getString("dueAmountPolicy3") + " " + policyDueDate);
							fvMap.put(CTPAMT, polCtpAmt);
							fvMap.put(POLDUEDATE, policyDueDate);
							returnMap.put("CTP", fvMap);
						}
					}
				} catch (Exception ec) {
					logger.info(ec);
				}
			} else {

				Map<String, String> fvMap = new HashMap<>();
				fvMap.put(MESSAGE, "Getting error : ! 200  while calling backend service");

				returnMap.put("ErrorMessage", fvMap);
			}
		} catch (Exception e) {
			logger.error("We are in exception while calling API : " + e);
		}
		return returnMap;
	}
}
