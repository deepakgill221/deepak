package com.google.serviceimpl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.applicationproperties.ApplicationProperties;
import com.google.common.Commons;
import com.google.common.XTrustProvider;
import com.google.service.PunchRequest_Intf;
@Service
public class PunchRequest_impl implements PunchRequest_Intf
{
	@Autowired
	ApplicationProperties applicationProp;
	
	private static Logger logger = LogManager.getLogger(PunchRequest_impl.class);
	public String getPunchRequest(String ssoId)
	{
		System.out.println("Inside Leave Status SSO ID IS "+ssoId);
		logger.info("Inside Method:: httpConnection_response ");
		StringBuilder result = new StringBuilder();
		String output = new String();
		String soaCorrelationId = "CorelationId"+System.currentTimeMillis();
		HttpURLConnection conn = null;
		try {
			String extURL = applicationProp.punchRequest;
			URL url = new URL(extURL);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata = new StringBuilder();

			requestdata.append("	{  	");
			requestdata.append("	   \"request\":{  	");
			requestdata.append("	      \"header\":{  	");
			requestdata.append("	         \"soaMsgVersion\":\"1.0\",	");
			requestdata.append("	         \"soaAppId\":\"EmpApp\",	");
			requestdata.append("	         \"soaCorrelationId\":\""+soaCorrelationId+"\"	");
			requestdata.append("	      },	");
			requestdata.append("	      \"payload\":{  	");
			requestdata.append("	         \"empId\":\""+ssoId.replaceAll("\\s+","").toUpperCase()+"\",	");
			requestdata.append("	         \"requestType\":\"PunchRequest\"	");
			requestdata.append("	      }	");
			requestdata.append("	   }	");
			requestdata.append("	}	");


			logger.info("External API Call : START");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}

			int apiResponseCode = conn.getResponseCode();
			logger.info("API Response Code : - " + apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END");
			}
			else
			{

				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling API's " + e);
		}
		logger.info("OutSide Method:: httpConnection_response ");
		return result.toString();
	}
}
