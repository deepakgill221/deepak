package com.google.serviceimpl;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.botIntegration.BPMA_MIS_BOT;
import com.google.service.BizUpdate_Intf;

@Service
public class BizUpdate implements BizUpdate_Intf
{
	private static Logger logger = LogManager.getLogger(BizUpdate.class);
	
	@Autowired
	private BPMA_MIS_BOT bpma_mis_bot;
	
	String speech="";
	
	public String getBizUpdate(String ssoId, Map<String,String> map) throws JSONException
	{
		ssoId=map.get("botssoId");
		speech=bpma_mis_bot.BPMA_MIS_Integration(ssoId);
		return speech;
	}

}
