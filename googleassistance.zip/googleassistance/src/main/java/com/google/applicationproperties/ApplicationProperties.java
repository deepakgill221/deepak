package com.google.applicationproperties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:application.properties")
public class ApplicationProperties 
{
	@Value("${GetUserDetail}")
	public String getUserDetail;
	
	@Value("${PunchRequest}")
	public String punchRequest;
	
	
	@Value("${BREBalance}")
	public String breStatus;
	
	@Value("${LeaveStatus}")
	public String leaveStatus;

	@Value("${BPMAMISBOT}")
	public String bpmaMisBOT;
	

}
