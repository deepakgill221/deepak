package com.google.service;

public interface PunchRequest_Intf {
	public String getPunchRequest(String ssoId);

}
