package com.google.service;

import java.util.Map;

import org.json.JSONException;

public interface BizUpdate_Intf 
{
	public String getBizUpdate(String ssoId, Map<String,String> map) throws JSONException;
}
