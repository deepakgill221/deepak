package com.google.service;

public interface BREStatus_Intf 
{
	public String getBREStatus(String ssoId);

}
