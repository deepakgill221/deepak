package com.google.service;

public interface SSOAuthenticate_Intf {
	public String getUserDetail(String ssoId);

}
