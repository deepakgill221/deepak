package com.google.botIntegration;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.applicationproperties.ApplicationProperties;
import com.google.serviceimpl.BREStatusimpl;

@Service
public class BPMA_MIS_BOT 
{
	private static Logger logger = LogManager.getLogger(BREStatusimpl.class);

	@Autowired
	ApplicationProperties applicationProp;
	String sessionId="";
	String speech="", botIdentifier="";

	public String BPMA_MIS_Integration(String ssoId) throws JSONException
	{
		logger.info("Inside Method:: BPMA_MIS_Integration ");
		StringBuilder result = new StringBuilder();
		String output = new String();
		HttpURLConnection conn = null;
		try {
			String UniqueId = "UniqueId"+System.currentTimeMillis();
			URL url = new URL(applicationProp.bpmaMisBOT);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			String query = ssoId+" "+"authorize_ecube_002_2017_BOT_certificate idiosyncratic_key web ecube";
			StringBuilder requestdata = new StringBuilder(); 
			requestdata.append("	{	");
			requestdata.append("	  \"query\": \""+query+"\",	");
			requestdata.append("	  \"randomString\": \""+UniqueId+"\",	");
			requestdata.append("	  \"botName\": \"EAPPBOT\"	");
			requestdata.append("	}	");
			logger.info("External API Call : START");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}
			int apiResponseCode = conn.getResponseCode();
			logger.info("API Response Code : - " + apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling API's " + e);
		}
		JSONObject objects = new JSONObject(result.toString());
		try{
			try{
			String jsonObject = objects.getJSONObject("result").getJSONObject("fulfillment").getJSONObject("data")
					.getJSONObject("facebook").getJSONArray("buttons").get(0)+"";
			JSONObject object2 = new JSONObject(jsonObject);
			botIdentifier = object2.get("text")+"";
			}
			catch(Exception ex)
			{
				botIdentifier="NOT_AUTH";
				logger.error("NOT_Authroize to access the bot");
			}
			if(!"Business Numbers".equalsIgnoreCase(botIdentifier))
			{
				speech="You are not authorize to access M I S Bot";
				return speech;
			}
			sessionId = objects.getString("sessionId")+"";
		}catch(Exception ex)
		{
			logger.error("Exception Occoured while getting response from bot");
		}
		speech=BPMA_MIS_Integration2(ssoId, sessionId);
		return speech;
	}
	public String BPMA_MIS_Integration2(String ssoId, String sessionId) throws JSONException
	{
		logger.info("Inside Method:: BPMA_MIS_Integration ");
		StringBuilder result = new StringBuilder();
		String output = new String();
		HttpURLConnection conn = null;
		try {
			URL url = new URL(applicationProp.bpmaMisBOT);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			String query = "misbot_validated_key_bot_2017"+" "+ssoId;
			StringBuilder requestdata = new StringBuilder(); 
			requestdata.append("	{	");
			requestdata.append("	  \"query\": \""+query+"\",	");
			requestdata.append("	  \"randomString\": \""+sessionId+"\",	");
			requestdata.append("	  \"botName\": \"Business Numbers\"	");
			requestdata.append("	}	");
			logger.info("External API Call : START");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}

			int apiResponseCode = conn.getResponseCode();
			logger.info("API Response Code : - " + apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling API's " + e);
		}
		JSONObject objects = new JSONObject(result.toString());
		try{
			speech = objects.getJSONObject("result").getJSONObject("fulfillment").getString("speech")+"";
			sessionId = objects.getString("sessionId")+"";
		}catch(Exception ex)
		{
			logger.error("Exception Occoured while getting response from bot");
		}
		speech=BPMA_MIS_Integration3(sessionId);
		return speech;
	}
	public String BPMA_MIS_Integration3(String sessionId) throws JSONException
	{
		logger.info("Inside Method:: BPMA_MIS_Integration ");
		StringBuilder result2 = new StringBuilder();
		String output = new String();
		HttpURLConnection conn = null;
		try {
			String UniqueId = "UniqueId"+System.currentTimeMillis();
			URL url = new URL(applicationProp.bpmaMisBOT);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata = new StringBuilder(); 
			requestdata.append("	{	");
			requestdata.append("	  \"query\": \"Numbers\",	");
			requestdata.append("	  \"randomString\": \""+sessionId+"\",	");
			requestdata.append("	  \"botName\": \"Business Numbers\"	");
			requestdata.append("	}	");
			logger.info("External API Call : START");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}
			int apiResponseCode = conn.getResponseCode();
			logger.info("API Response Code : - " + apiResponseCode);
			if (apiResponseCode == 200) 
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result2.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END");
			}
			else
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				while ((output = br.readLine()) != null) {
					result2.append(output);
				}
				conn.disconnect();
				br.close();
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling API's " + e);
		}
		JSONObject objects2 = new JSONObject(result2.toString());
		try{
			speech = objects2.getJSONObject("result").getJSONObject("fulfillment").getString("speech")+"";
			System.out.println("----Final Speech----"+speech);
		}catch(Exception ex)
		{
			logger.error("Exception Occoured while getting response from bot");
		}
		return speech;
	}
}
