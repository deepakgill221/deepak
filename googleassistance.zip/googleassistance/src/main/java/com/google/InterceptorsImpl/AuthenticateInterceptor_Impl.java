package com.google.InterceptorsImpl;

import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.Interceptors.AuthenticateInterceptor_Intf;
import com.google.service.SSOAuthenticate_Intf;

@Service
public class AuthenticateInterceptor_Impl implements AuthenticateInterceptor_Intf
{
	@Autowired
	private SSOAuthenticate_Intf authenticate;
	
	String displayName="", speech="", ssoIds="";
	@Override
	public String authenciateSSOID(String ssoId, Map<String, String> map) throws JSONException 
	{
		if(ssoId.contains("2801"))
		{
			ssoId = "KDHOM2801";
		}
		else if(ssoId.contains("1417"))
		{
			ssoId="PTHOM1417";
		}
		else if(ssoId.contains("1164"))
		{
			ssoId="VBHOM1164";
		}
		else if(ssoId.contains("3321"))
		{
			ssoId="MMHOM3321";
		}
		else if(ssoId.contains("0103"))
		{
			ssoId="VVCHE0103";
		}
		else if(ssoId.contains("0520"))
		{
			ssoId="MNHOM0520";
		}
		else if(ssoId.contains("2626"))
		{
			ssoId="SKSHOM2626";
		}
		else if(ssoId.contains("3847"))
		{
			ssoId="VSHOM3847";
		}
		else if(ssoId.contains("4053"))
		{
			ssoId="SAHOM4053";
		}
		if(!"VVCHE0103".equalsIgnoreCase(ssoId))
		{
			map.put("botssoId", ssoId);
			ssoIds=ssoId;
			String [] splits = ssoIds.split("HOM");
			ssoIds=splits[1];
			map.put("ssoId", "HOM"+ssoIds);
		}
		else
		{
			if("VVCHE0103".equalsIgnoreCase(ssoId))
			{
				ssoIds="VVCHE0103";
				map.put("ssoId", ssoIds);
				map.put("botssoId", ssoId);
			}
		}
		String orignalData = authenticate.getUserDetail(ssoId);
		JSONObject objects = new JSONObject(orignalData.toString());
		try{
			String jsonobject = objects.getJSONObject("Response").getJSONObject("ResponseInfo").getJSONArray("Transactions").get(0)+"";
			JSONObject object2 = new JSONObject(jsonobject);
			displayName = object2.get("mnyldisplayname")+"";
			speech = "Hello "+displayName +" welcome to Max Life. "
					+ "What would you like to do from following menu,"
					+ " Check Business Update ."
					+ " Find attendance status ."
					+ " Manage Leave status ."
					+ " Know B R E Status .";
					
		}catch(Exception ex)
		{
			speech="Your SSOID is invalid, Please Validate it again";
		}
		return speech;
	}
}
