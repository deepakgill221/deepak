package com.google.controller;

public class test 
{
	public static void main(String[] args) {
		String str = "kthm 2801";
		if(str.contains("2801"))
		{
			String strnew = "KDHOM2801";
			System.out.println("New id is "+strnew);
		}
		if(str.contains("1417"))
		{
			String strnew2="PTHOM1417";
			System.out.println("New Id is "+strnew2);
		}
		else
		{
			System.out.println("Dones not match");
		}

	}
		
	
}
