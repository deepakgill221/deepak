package com.google.controller;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.Interceptors.AuthenticateInterceptor_Intf;
import com.google.Interceptors.BREBalanceInterceptor_Intf;
import com.google.Interceptors.LeaveStatusInterceptor_Intf;
import com.google.Interceptors.PunchRequestInterceptor_Intf;
import com.google.common.Response;
import com.google.serviceimpl.BizUpdate;

@Controller
@RequestMapping("/webhook")
public class GoogleAssistance {
	
	static Map<String, String> map  = new ConcurrentHashMap<>();
	private static Logger logger = LogManager.getLogger(GoogleAssistance.class.getName());
	@Autowired
	private PunchRequestInterceptor_Intf punchRequestInterceptor;
	@Autowired
	private BREBalanceInterceptor_Intf bREBalanceInterceptor;
	@Autowired
	private BizUpdate bizUpdate;
	@Autowired
	private LeaveStatusInterceptor_Intf leaveStatusInterceptor;
	@Autowired
	AuthenticateInterceptor_Intf authenticateInterceptor;
	@Autowired
	private Response response;
	
	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody String webhook(@RequestBody String obj)
	{
		System.out.println("Request comes ---"+obj);
		String speech = null;
		String sessionId="";
		String action="";
		String ssoIds="";

		try {
			JSONObject object = new JSONObject(obj.toString());
			sessionId = object.get("responseId")+"";
			try{
				action = object.getJSONObject("queryResult").get("action")+"";
			}catch(Exception ex)
			{
				action="";
			}
			try{
				ssoIds = object.getJSONObject("queryResult").getJSONObject("parameters").get("ssoId")+"";
				ssoIds=ssoIds.replaceAll("\\s+","").toUpperCase();
			}catch(Exception ex)
			{
				ssoIds="";
			}
			switch(action.toUpperCase())
			{
			case "AUTHENTICATE":
			{
				speech=authenticateInterceptor.authenciateSSOID(ssoIds, map);
			}
			break;
			case "PUNCH_REQUEST":
			{
				speech=punchRequestInterceptor.punchRequest(ssoIds, map);
			}
			break;
			case "LEAVE_STATUS":
			{
				speech=leaveStatusInterceptor.leaveStatus(ssoIds, map);
			}
			break;
			case "BRE_STATUS":
			{
				speech=bREBalanceInterceptor.breBalance(ssoIds, map);
			}
			break;
			case "BIZ_UPDATE":
			{
				String orignalData = bizUpdate.getBizUpdate(ssoIds, map);
				speech=orignalData;
			}
			break;
			default:
			}
		} 
		catch (Exception e) {
			logger.error("Exception occoured in controller logic");
		}
		if(!"AUTHENTICATE".equalsIgnoreCase(action))
		{
			speech=speech+". Is there any thing i can help you";
		}
		System.out.println();
		return response.googleAssistanceResponse(speech);
	}
}
