package com.google.Interceptors;

import java.util.Map;

import org.json.JSONException;

public interface PunchRequestInterceptor_Intf 
{
	public String punchRequest(String ssoId, Map<String, String> map) throws JSONException;

}
