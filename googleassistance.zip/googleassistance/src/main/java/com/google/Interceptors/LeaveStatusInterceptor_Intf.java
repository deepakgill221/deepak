package com.google.Interceptors;

import java.util.Map;

import org.json.JSONException;

public interface LeaveStatusInterceptor_Intf {
	public String leaveStatus(String ssoId, Map<String,String> map) throws JSONException;
}
