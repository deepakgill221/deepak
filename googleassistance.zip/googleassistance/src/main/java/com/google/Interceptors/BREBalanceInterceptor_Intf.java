package com.google.Interceptors;

import java.util.Map;

import org.json.JSONException;

public interface BREBalanceInterceptor_Intf {
	public String breBalance(String ssoId, Map<String,String> map) throws JSONException;

}
