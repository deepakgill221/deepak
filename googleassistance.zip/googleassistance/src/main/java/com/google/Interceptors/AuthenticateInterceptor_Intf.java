package com.google.Interceptors;

import java.util.Map;

import org.json.JSONException;

public interface AuthenticateInterceptor_Intf 
{
	public String authenciateSSOID(String ssoId, Map<String, String> map) throws JSONException;

}
