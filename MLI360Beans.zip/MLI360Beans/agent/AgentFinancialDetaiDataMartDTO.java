package com.qc.api.dto.agent;

import java.io.Serializable;

public class AgentFinancialDetaiDataMartDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7135922967717479122L;
	private	String	mtdFyp	;
	private	String	fytdFyp	;
	private	String	mtdNoPdCases	;
	private	String	fmtdNoPdCases	;
	private	String	mtdFyc	;
	private	String	fytdFyc	;
	private	String	mtdAfyp	;
	private	String	fytdAfyp	;
	private	String	mtdRyp	;
	private	String	fytdRyp	;
	private	String	mtdRyc	;
	private	String	fytdRyc	;
	private	String	adjAfyp	;
	private	String	adjFyp	;
	private	String	bounsDtl	;
	private	String	agtRefFee	;
	public String getMtdFyp() {
		return mtdFyp;
	}
	public void setMtdFyp(String mtdFyp) {
		this.mtdFyp = mtdFyp;
	}
	public String getFytdFyp() {
		return fytdFyp;
	}
	public void setFytdFyp(String fytdFyp) {
		this.fytdFyp = fytdFyp;
	}
	public String getMtdNoPdCases() {
		return mtdNoPdCases;
	}
	public void setMtdNoPdCases(String mtdNoPdCases) {
		this.mtdNoPdCases = mtdNoPdCases;
	}
	public String getFmtdNoPdCases() {
		return fmtdNoPdCases;
	}
	public void setFmtdNoPdCases(String fmtdNoPdCases) {
		this.fmtdNoPdCases = fmtdNoPdCases;
	}
	public String getMtdFyc() {
		return mtdFyc;
	}
	public void setMtdFyc(String mtdFyc) {
		this.mtdFyc = mtdFyc;
	}
	public String getFytdFyc() {
		return fytdFyc;
	}
	public void setFytdFyc(String fytdFyc) {
		this.fytdFyc = fytdFyc;
	}
	public String getMtdAfyp() {
		return mtdAfyp;
	}
	public void setMtdAfyp(String mtdAfyp) {
		this.mtdAfyp = mtdAfyp;
	}
	public String getFytdAfyp() {
		return fytdAfyp;
	}
	public void setFytdAfyp(String fytdAfyp) {
		this.fytdAfyp = fytdAfyp;
	}
	public String getMtdRyp() {
		return mtdRyp;
	}
	public void setMtdRyp(String mtdRyp) {
		this.mtdRyp = mtdRyp;
	}
	public String getFytdRyp() {
		return fytdRyp;
	}
	public void setFytdRyp(String fytdRyp) {
		this.fytdRyp = fytdRyp;
	}
	public String getMtdRyc() {
		return mtdRyc;
	}
	public void setMtdRyc(String mtdRyc) {
		this.mtdRyc = mtdRyc;
	}
	public String getFytdRyc() {
		return fytdRyc;
	}
	public void setFytdRyc(String fytdRyc) {
		this.fytdRyc = fytdRyc;
	}
	public String getAdjAfyp() {
		return adjAfyp;
	}
	public void setAdjAfyp(String adjAfyp) {
		this.adjAfyp = adjAfyp;
	}
	public String getAdjFyp() {
		return adjFyp;
	}
	public void setAdjFyp(String adjFyp) {
		this.adjFyp = adjFyp;
	}
	public String getBounsDtl() {
		return bounsDtl;
	}
	public void setBounsDtl(String bounsDtl) {
		this.bounsDtl = bounsDtl;
	}
	public String getAgtRefFee() {
		return agtRefFee;
	}
	public void setAgtRefFee(String agtRefFee) {
		this.agtRefFee = agtRefFee;
	}

}
