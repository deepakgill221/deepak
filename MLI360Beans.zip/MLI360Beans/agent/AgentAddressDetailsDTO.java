package com.qc.api.dto.agent;

import java.io.Serializable;

public class AgentAddressDetailsDTO implements Serializable
{
	private static final long serialVersionUID = 1253137271817182813L;
	
	private String AddrLine1 ;
	private String AddrLine2 ;
	private String AddrLine3 ;
	private String city ;
	private String stateCd ;
	private String stateDesc;
	private String pinCode ;
	private String AddrCategoryCd ;
	private String AddrCategoryDesc;
	
	public String getAddrLine1() {
		return AddrLine1;
	}
	public void setAddrLine1(String addrLine1) {
		AddrLine1 = addrLine1;
	}
	public String getAddrLine2() {
		return AddrLine2;
	}
	public void setAddrLine2(String addrLine2) {
		AddrLine2 = addrLine2;
	}
	public String getAddrLine3() {
		return AddrLine3;
	}
	public void setAddrLine3(String addrLine3) {
		AddrLine3 = addrLine3;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStateCd() {
		return stateCd;
	}
	public void setStateCd(String stateCd) {
		this.stateCd = stateCd;
	}
	public String getStateDesc() {
		return stateDesc;
	}
	public void setStateDesc(String stateDesc) {
		this.stateDesc = stateDesc;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getAddrCategoryCd() {
		return AddrCategoryCd;
	}
	public void setAddrCategoryCd(String addrCategoryCd) {
		AddrCategoryCd = addrCategoryCd;
	}
	public String getAddrCategoryDesc() {
		return AddrCategoryDesc;
	}
	public void setAddrCategoryDesc(String addrCategoryDesc) {
		AddrCategoryDesc = addrCategoryDesc;
	}


}
