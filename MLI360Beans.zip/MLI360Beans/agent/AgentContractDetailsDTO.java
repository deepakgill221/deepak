package com.qc.api.dto.agent;

import java.io.Serializable;

import com.qc.utils.MultiFormatDate;

public class AgentContractDetailsDTO implements Serializable
{

	private static final long serialVersionUID = -1730609069061299776L;
	
	private String licenceNum ;
	private String licenceDt ;
	private String licenceExpiryDt ;
	private String dtOfJoining ;
	private String terminationDt ;
	
	public String getLicenceNum() {
		return licenceNum;
	}
	public void setLicenceNum(String licenceNum) {
		this.licenceNum = licenceNum;
	}
	public String getLicenceDt() {
		return licenceDt;
	}
	public void setLicenceDt(String licenceDt) {
		this.licenceDt = MultiFormatDate.getSoaFormattedDate(licenceDt);
	}
	public String getLicenceExpiryDt() {
		return licenceExpiryDt;
	}
	public void setLicenceExpiryDt(String licenceExpiryDt) {
		this.licenceExpiryDt = MultiFormatDate.getSoaFormattedDate(licenceExpiryDt);
	}
	public String getDtOfJoining() {
		return dtOfJoining;
	}
	public void setDtOfJoining(String dtOfJoining) {
		this.dtOfJoining = MultiFormatDate.getSoaFormattedDate(dtOfJoining);
	}
	public String getTerminationDt() {
		return terminationDt;
	}
	public void setTerminationDt(String terminationDt) {
		this.terminationDt = MultiFormatDate.getSoaFormattedDate(terminationDt);
	}

	

}
