package com.qc.api.dto.agent;

import java.io.Serializable;

import com.qc.utils.MultiFormatDate;

public class AgentMovementDetailsDTO implements Serializable 
{
	private static final long serialVersionUID = -8935966262488056386L;
	
	private String date;
	private String movementType  ;
	private String oldBranchCode  ;
	private String newBranchCode  ;
	private String oldDesignation ;
	private String newDesignation ;
	private String reportingTo ;
	private String reportingName ;
	private String reason   ;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = MultiFormatDate.getSoaFormattedDate(date);
	}
	public String getMovementType() {
		return movementType;
	}
	public void setMovementType(String movementType) {
		this.movementType = movementType;
	}
	public String getOldBranchCode() {
		return oldBranchCode;
	}
	public void setOldBranchCode(String oldBranchCode) {
		this.oldBranchCode = oldBranchCode;
	}
	public String getNewBranchCode() {
		return newBranchCode;
	}
	public void setNewBranchCode(String newBranchCode) {
		this.newBranchCode = newBranchCode;
	}
	public String getOldDesignation() {
		return oldDesignation;
	}
	public void setOldDesignation(String oldDesignation) {
		this.oldDesignation = oldDesignation;
	}
	public String getNewDesignation() {
		return newDesignation;
	}
	public void setNewDesignation(String newDesignation) {
		this.newDesignation = newDesignation;
	}
	public String getReportingTo() {
		return reportingTo;
	}
	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
	public String getReportingName() {
		return reportingName;
	}
	public void setReportingName(String reportingName) {
		this.reportingName = reportingName;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

	
}
