package com.qc.api.dto.agent;

import java.io.Serializable;

import com.qc.utils.MultiFormatDate;

public class AgentReferralDetailsDTO implements Serializable {

	private static final long serialVersionUID = -1015156513634663366L;

	private String agentCode ;
	private String agentName;
	private String dtOfJoning;
	private String designation ;
	private String status ;
	private String agencyBranchCode ;
	private String agencyBranchName ;
	private String reportingTo ;
	private String reportingName ;
	
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getDtOfJoning() {
		return dtOfJoning;
	}
	public void setDtOfJoning(String dtOfJoning) {
		this.dtOfJoning = MultiFormatDate.getSoaFormattedDate(dtOfJoning);
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAgencyBranchCode() {
		return agencyBranchCode;
	}
	public void setAgencyBranchCode(String agencyBranchCode) {
		this.agencyBranchCode = agencyBranchCode;
	}
	public String getAgencyBranchName() {
		return agencyBranchName;
	}
	public void setAgencyBranchName(String agencyBranchName) {
		this.agencyBranchName = agencyBranchName;
	}
	public String getReportingTo() {
		return reportingTo;
	}
	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
	public String getReportingName() {
		return reportingName;
	}
	public void setReportingName(String reportingName) {
		this.reportingName = reportingName;
	}
}
