package com.qc.api.dto.agent;

import java.io.Serializable;

public class AgentContactDetailsDTO implements Serializable
{

	private static final long serialVersionUID = -8733388189200033961L;
	
	private String contactNum ;
	private String emailId ;
	private String agentHomephone ;
	private String agentMobile1 ;
	private String agentMobile2 ;
	public String getContactNum() {
		return contactNum;
	}
	public void setContactNum(String contactNum) {
		this.contactNum = contactNum;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAgentHomephone() {
		return agentHomephone;
	}
	public void setAgentHomephone(String agentHomephone) {
		this.agentHomephone = agentHomephone;
	}
	public String getAgentMobile1() {
		return agentMobile1;
	}
	public void setAgentMobile1(String agentMobile1) {
		this.agentMobile1 = agentMobile1;
	}
	public String getAgentMobile2() {
		return agentMobile2;
	}
	public void setAgentMobile2(String agentMobile2) {
		this.agentMobile2 = agentMobile2;
	}

	
}
