package com.qc.api.dto.agent;

import java.io.Serializable;

public class AgentCommisionDetailsDTO implements Serializable
{
	private static final long serialVersionUID = -8162743811854303163L;
	private	String	polLvlComm	;
	private	String	yOnYrAdMoOnMoOerfReq	;
	public String getPolLvlComm() {
		return polLvlComm;
	}
	public void setPolLvlComm(String polLvlComm) {
		this.polLvlComm = polLvlComm;
	}
	public String getyOnYrAdMoOnMoOerfReq() {
		return yOnYrAdMoOnMoOerfReq;
	}
	public void setyOnYrAdMoOnMoOerfReq(String yOnYrAdMoOnMoOerfReq) {
		this.yOnYrAdMoOnMoOerfReq = yOnYrAdMoOnMoOerfReq;
	}

}
