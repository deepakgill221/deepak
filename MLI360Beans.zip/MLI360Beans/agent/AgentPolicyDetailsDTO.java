package com.qc.api.dto.agent;

import java.io.Serializable;

import com.qc.utils.MultiFormatDate;

public class AgentPolicyDetailsDTO implements Serializable
{
	private static final long serialVersionUID = -1076904010641336890L;
	
	private String policyId ;
	private String policyholderName ;
	private String policyStatus ;
	private String policyIssueDt ;
	private String agentSplit ;
	private String basePlanName ;
	private String premiumMode ;
	private String sumAssured ;
	private String grossAnnualPremium ;
	private String policyTerm ;
	private String policyInforceDt ;
	private String lastStatusChangeDt ;
	private String polDueDt;
	public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
	public String getPolicyholderName() {
		return policyholderName;
	}
	public void setPolicyholderName(String policyholderName) {
		this.policyholderName = policyholderName;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getPolicyIssueDt() {
		return policyIssueDt;
	}
	public void setPolicyIssueDt(String policyIssueDt) {
		this.policyIssueDt = MultiFormatDate.getSoaFormattedDate(policyIssueDt);
	}
	public String getAgentSplit() {
		return agentSplit;
	}
	public void setAgentSplit(String agentSplit) {
		this.agentSplit = agentSplit;
	}
	public String getBasePlanName() {
		return basePlanName;
	}
	public void setBasePlanName(String basePlanName) {
		this.basePlanName = basePlanName;
	}
	public String getPremiumMode() {
		return premiumMode;
	}
	public void setPremiumMode(String premiumMode) {
		this.premiumMode = premiumMode;
	}
	public String getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getGrossAnnualPremium() {
		return grossAnnualPremium;
	}
	public void setGrossAnnualPremium(String grossAnnualPremium) {
		this.grossAnnualPremium = grossAnnualPremium;
	}
	public String getPolicyTerm() {
		return policyTerm;
	}
	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}
	public String getPolicyInforceDt() {
		return policyInforceDt;
	}
	public void setPolicyInforceDt(String policyInforceDt) {
		this.policyInforceDt = MultiFormatDate.getSoaFormattedDate(policyInforceDt);
	}
	public String getLastStatusChangeDt() {
		return lastStatusChangeDt;
	}
	public void setLastStatusChangeDt(String lastStatusChangeDt) {
		this.lastStatusChangeDt = MultiFormatDate.getSoaFormattedDate(lastStatusChangeDt);
	}
	public String getPolDueDt() {
		return polDueDt;
	}
	public void setPolDueDt(String polDueDt) {
		this.polDueDt = MultiFormatDate.getSoaFormattedDate(polDueDt);
	}

	
}
