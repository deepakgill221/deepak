package com.qc.api.dto.agent;

import java.io.Serializable;

import com.qc.utils.MultiFormatDate;

public class AgentBasicDetailsDTO implements Serializable
{
	
	private static final long serialVersionUID = -4513473599297086252L;
	
	private String agentId ;
	private String title ;
	private String agentName ;
	private String designation ;
	private String branchAddr ;
	private String isEmp ;
	private String goLocality ;
	private String agencyName ;
	private String dob ;
	private String gender ;
	private String categoryCd ;
	private String categoryDesc;
	private String staffCode ;
	private String eduQufication ;
	private String panNum ;
	private String agentSegmentCd ;
	private String agentSegmentDesc;
	private String agentClientID ;
	private String maritalStatus ;
	private String fhName ;
	private String nomineeName ;
	private String perShrOfNominee ;
	private String nomineeAgentRelation ;
	private String channelType ;
	private String panUpdateDt ;
	private String eligyForMaxOne ;
	private String supensionReason ;
	private String recruitedBy ;
	private String recruitedByName ;
	private String reportingTo ;
	private String reportingToName ;
	private String rdcBonusReduction ;
	private String referringAgentCode ;
	private String referringAgentName ;
	private String managingBranch ;
	private String ssnCodes ;
	private String agentStatus ;
	private String servBrId ;
	private String agentSegamentationCd ;
	private String agentSegamentationDesc  ;
	private String areaMgr ;
	private String centreMgr ;
	private String role ;
	private String agentActiveCode ;
	private String commissionableFlag ;
	private String channelName ;
	private String branchName ;
	private String reason ;
	

	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getBranchAddr() {
		return branchAddr;
	}
	public void setBranchAddr(String branchAddr) {
		this.branchAddr = branchAddr;
	}
	public String getIsEmp() {
		return isEmp;
	}
	public void setIsEmp(String isEmp) {
		this.isEmp = isEmp;
	}
	public String getGoLocality() {
		return goLocality;
	}
	public void setGoLocality(String goLocality) {
		this.goLocality = goLocality;
	}
	public String getAgencyName() {
		return agencyName;
	}
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = MultiFormatDate.getSoaFormattedDate(dob);
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCategoryCd() {
		return categoryCd;
	}
	public void setCategoryCd(String categoryCd) {
		this.categoryCd = categoryCd;
	}
	public String getCategoryDesc() {
		return categoryDesc;
	}
	public void setCategoryDesc(String categoryDesc) {
		this.categoryDesc = categoryDesc;
	}
	public String getStaffCode() {
		return staffCode;
	}
	public void setStaffCode(String staffCode) {
		this.staffCode = staffCode;
	}
	public String getEduQufication() {
		return eduQufication;
	}
	public void setEduQufication(String eduQufication) {
		this.eduQufication = eduQufication;
	}
	public String getPanNum() {
		return panNum;
	}
	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}
	public String getAgentSegmentCd() {
		return agentSegmentCd;
	}
	public void setAgentSegmentCd(String agentSegmentCd) {
		this.agentSegmentCd = agentSegmentCd;
	}
	public String getAgentSegmentDesc() {
		return agentSegmentDesc;
	}
	public void setAgentSegmentDesc(String agentSegmentDesc) {
		this.agentSegmentDesc = agentSegmentDesc;
	}
	public String getAgentClientID() {
		return agentClientID;
	}
	public void setAgentClientID(String agentClientID) {
		this.agentClientID = agentClientID;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getFhName() {
		return fhName;
	}
	public void setFhName(String fhName) {
		this.fhName = fhName;
	}
	public String getNomineeName() {
		return nomineeName;
	}
	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}
	public String getPerShrOfNominee() {
		return perShrOfNominee;
	}
	public void setPerShrOfNominee(String perShrOfNominee) {
		this.perShrOfNominee = perShrOfNominee;
	}
	public String getNomineeAgentRelation() {
		return nomineeAgentRelation;
	}
	public void setNomineeAgentRelation(String nomineeAgentRelation) {
		this.nomineeAgentRelation = nomineeAgentRelation;
	}
	public String getChannelType() {
		return channelType;
	}
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}
	public String getPanUpdateDt() {
		return panUpdateDt;
	}
	public void setPanUpdateDt(String panUpdateDt) {
		this.panUpdateDt = MultiFormatDate.getSoaFormattedDate(panUpdateDt);
	}
	public String getEligyForMaxOne() {
		return eligyForMaxOne;
	}
	public void setEligyForMaxOne(String eligyForMaxOne) {
		this.eligyForMaxOne = eligyForMaxOne;
	}
	public String getSupensionReason() {
		return supensionReason;
	}
	public void setSupensionReason(String supensionReason) {
		this.supensionReason = supensionReason;
	}
	public String getRecruitedBy() {
		return recruitedBy;
	}
	public void setRecruitedBy(String recruitedBy) {
		this.recruitedBy = recruitedBy;
	}
	public String getRecruitedByName() {
		return recruitedByName;
	}
	public void setRecruitedByName(String recruitedByName) {
		this.recruitedByName = recruitedByName;
	}
	public String getReportingTo() {
		return reportingTo;
	}
	public void setReportingTo(String reportingTo) {
		this.reportingTo = reportingTo;
	}
	public String getReportingToName() {
		return reportingToName;
	}
	public void setReportingToName(String reportingToName) {
		this.reportingToName = reportingToName;
	}
	public String getRdcBonusReduction() {
		return rdcBonusReduction;
	}
	public void setRdcBonusReduction(String rdcBonusReduction) {
		this.rdcBonusReduction = rdcBonusReduction;
	}
	public String getReferringAgentCode() {
		return referringAgentCode;
	}
	public void setReferringAgentCode(String referringAgentCode) {
		this.referringAgentCode = referringAgentCode;
	}
	public String getReferringAgentName() {
		return referringAgentName;
	}
	public void setReferringAgentName(String referringAgentName) {
		this.referringAgentName = referringAgentName;
	}
	public String getManagingBranch() {
		return managingBranch;
	}
	public void setManagingBranch(String managingBranch) {
		this.managingBranch = managingBranch;
	}
	public String getSsnCodes() {
		return ssnCodes;
	}
	public void setSsnCodes(String ssnCodes) {
		this.ssnCodes = ssnCodes;
	}
	public String getAgentStatus() {
		return agentStatus;
	}
	public void setAgentStatus(String agentStatus) {
		this.agentStatus = agentStatus;
	}
	public String getServBrId() {
		return servBrId;
	}
	public void setServBrId(String servBrId) {
		this.servBrId = servBrId;
	}
	public String getAgentSegamentationCd() {
		return agentSegamentationCd;
	}
	public void setAgentSegamentationCd(String agentSegamentationCd) {
		this.agentSegamentationCd = agentSegamentationCd;
	}
	public String getAgentSegamentationDesc() {
		return agentSegamentationDesc;
	}
	public void setAgentSegamentationDesc(String agentSegamentationDesc) {
		this.agentSegamentationDesc = agentSegamentationDesc;
	}
	public String getAreaMgr() {
		return areaMgr;
	}
	public void setAreaMgr(String areaMgr) {
		this.areaMgr = areaMgr;
	}
	public String getCentreMgr() {
		return centreMgr;
	}
	public void setCentreMgr(String centreMgr) {
		this.centreMgr = centreMgr;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAgentActiveCode() {
		return agentActiveCode;
	}
	public void setAgentActiveCode(String agentActiveCode) {
		this.agentActiveCode = agentActiveCode;
	}
	public String getCommissionableFlag() {
		return commissionableFlag;
	}
	public void setCommissionableFlag(String commissionableFlag) {
		this.commissionableFlag = commissionableFlag;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}

	
	
}
