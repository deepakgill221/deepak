package com.lead.agent.interceptor;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface Welcome {
	/**
	 * @param name
	 * @return
	 */
	public String getWelcome(String name);
}
