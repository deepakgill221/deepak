package com.lead.agent.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lead.agent.button.Facebook;
import com.lead.agent.button.InnerButton;
import com.lead.agent.button.InnerData;
import com.lead.agent.commons.BeanProperty;
import com.lead.agent.service.Button;

/**
 * @author ad01084
 *
 */
@Service
public class ButtonImpl implements Button 
{
	@Autowired
	private BeanProperty bean;
	private static final String APINAME="API.AI"; 
	private static final String CHATBOTNAME="Chatbot";
	private static final String MLICHATBOTNAME="MLIChatBot";
	private static final String IMAGEURL = "BOT";
	
	private void setInnerButtons(
			List<InnerButton> buttonList,
			String text,
			String postback,
			String link
			)
	{
		InnerButton button = new InnerButton();
		button.setText(text);
		button.setPostback(postback);
		button.setLink(link);		
		buttonList.add(button);
	}
	
	private void setFacebook(
			List<InnerButton> buttonList,
			Facebook fb
			)
	{
		fb.setButtons(buttonList);
		fb.setTitle(MLICHATBOTNAME);
		fb.setPlatform(APINAME);
		fb.setType(CHATBOTNAME);
		fb.setImageUrl(IMAGEURL);		
	}
	
	/** (non-Javadoc)
	 * @see com.lead.agent.service.Button#getButtonsYesNo()
	 * @return com.lead.agent.button.InnerData
	 */
	@Override
	public InnerData getButtonsYesNo() 
	{
		InnerData innerData=new InnerData();
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Yes","yes","");
		setInnerButtons(innerbuttonlist,"No","no","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	/** (non-Javadoc)
	 * @see com.lead.agent.service.Button#getButtonsGender()
	 * @return com.lead.agent.button.InnerData
	 */
	public InnerData getButtonsGender() 
	{
		InnerData innerData=new InnerData();
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Male","male","");
		setInnerButtons(innerbuttonlist,"Female","female","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	/** (non-Javadoc)
	 * @see com.lead.agent.service.Button#letsProceed()
	 * @return com.lead.agent.button.InnerData
	 */
	public InnerData letsProceed() 
	{
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		InnerData innerData=new InnerData();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Lets Proceed","Hi","");
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	
	
	/** 
	 * @param map
	 * @param sessionId
	 * @return com.lead.agent.button.InnerData
	 */
	public InnerData proceed(Map<String, Map<String,String>> map, String sessionId) 
	{
		String link=bean.getReDirectURL();
		String leadId=map.get(sessionId).get("leadId");
		List<InnerButton> innerbuttonlist=new ArrayList<>();
		InnerData innerData=new InnerData();
		Facebook fb = new Facebook();
		setInnerButtons(innerbuttonlist,"Proceed","proceed",link+leadId);
		setFacebook(innerbuttonlist,fb);
		innerData.setFacebook(fb);
		return innerData;
	}
	
	
}
