package com.lead.agent.service;

import java.util.Map;

import com.lead.agent.button.InnerData;

/**
 * @author ad01084
 *
 */
public interface Button 
{
	/**
	 * @return
	 */
	public InnerData getButtonsYesNo();
	/**
	 * @return
	 */
	public InnerData getButtonsGender();
	/**
	 * @return
	 */
	public InnerData letsProceed();
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public InnerData proceed(Map<String,Map<String,String>> map, String sessionId);
}
