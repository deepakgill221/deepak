package com.lead.agent.commons;

import java.security.AccessController;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.PrivilegedAction;
import java.security.Security;
import java.security.cert.X509Certificate;

import javax.net.ssl.ManagerFactoryParameters;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactorySpi;
import javax.net.ssl.X509TrustManager;

/**
 * @author ad01084
 *
 */
public final class XTrustProvider extends java.security.Provider {
	private static final long serialVersionUID = 1L;
	private static final String NAME = "XTrustJSSE";
	private static final String XTRUST509 = "XTrust509";
	private static final String INFO = "XTrust JSSE Provider (implements trust factory with truststore validation disabled)";
	private static final double VERSION = 1.0D;

	/**
	 * Default Constructor
	 */
	@SuppressWarnings("unchecked")
	public XTrustProvider() {
		super(NAME, VERSION, INFO);
		PrivilegedAction privilegedAction= () ->{
			put("TrustManagerFactory." + TrustManagerFactoryImpl.getAlgorithm(),TrustManagerFactoryImpl.class.getName());
			return null;
		};
		AccessController.doPrivileged(privilegedAction);
	}

	/**
	 * Install this
	 */
	public static void install() {
		if (Security.getProvider(NAME) == null) {
			Security.insertProviderAt(new XTrustProvider(), 2);
			Security.setProperty("ssl.TrustManagerFactory.algorithm", TrustManagerFactoryImpl.getAlgorithm());
		}
	}

	/**
	 * @author ad01084
	 *
	 */
	public static final class TrustManagerFactoryImpl extends TrustManagerFactorySpi {
		/**
		 * default constructor
		 */
		public TrustManagerFactoryImpl() {
			// Do nothing : Not required to do anything 
		}

		/**
		 * @return
		 */
		public static String getAlgorithm() {
			return XTRUST509;
		}

		@Override
		protected void engineInit(KeyStore keystore) throws KeyStoreException {
			// Do nothing : Not required to do anything
		}
		@Override
		protected void engineInit(ManagerFactoryParameters mgrparams) throws InvalidAlgorithmParameterException {
			throw new InvalidAlgorithmParameterException(
					XTrustProvider.NAME + " does not use ManagerFactoryParameters");
		}
		@Override
		protected TrustManager[] engineGetTrustManagers() {
			return new TrustManager[] { new X509TrustManager() {
				@Override
				public X509Certificate[] getAcceptedIssuers() {
					// Do nothing : Not required to do anything
					return new X509Certificate[0];
				}
				@Override
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
					// Do nothing : Not required to do anything
				}
				@Override
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
					// Do nothing : Not required to do anything
				}
			} };
		}
	}
}
