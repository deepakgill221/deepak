package com.lead.agent.response;

import java.io.Serializable;

import com.lead.agent.button.InnerData;

/**
 * @author ad01084
 *
 */
public class WebhookResponse implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String speech;
    private String displayText;
    private InnerData data;
    private String source = "java-webhook";

    /**
     * Default constructor
     */
    public WebhookResponse() {
		super();
	}

	/**
	 * @param speech
	 * @param displayText
	 * @param data
	 */
	public WebhookResponse(String speech, String displayText,InnerData data) {
		super();
		this.speech = speech;
		this.displayText = displayText;
		this.data=data;
	}		

	public String getSpeech() {
        return speech;
    }

    public String getDisplayText() {
        return displayText;
    }

    public String getSource() {
        return source;
    }

	public InnerData getData() {
		return data;
	}

	public void setData(InnerData data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "WebhookResponse [speech=" + speech + ", displayText=" + displayText + ", data=" + data + ", source="
				+ source + "]";
	}
	
}
