package com.lead.agent.service;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface GetMessageService 
{
	/**
	 * @param botName
	 * @return
	 */
	public String getMessageAPI(String botName);

}
