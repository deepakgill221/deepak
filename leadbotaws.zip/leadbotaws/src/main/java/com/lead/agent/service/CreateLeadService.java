package com.lead.agent.service;

import java.util.Map;

/**
 * @author ad01084
 *
 */
@FunctionalInterface
public interface CreateLeadService 
{
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String createLeadAPI(Map<String, Map<String, String>> map, String sessionId);

}
