package com.test.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.domain.User;

public interface UserRepository extends JpaRepository<User, Long>{

	User findByUsername(String username);
	User findByUsernameAndEnabled(String userName,boolean enabled);
	
	List<User> findByEmail(String email);

	User findByUsernameIgnoreCase(String userName);
	
	List<User> findByUsernameIn(List<String> userNameList);

	

}
