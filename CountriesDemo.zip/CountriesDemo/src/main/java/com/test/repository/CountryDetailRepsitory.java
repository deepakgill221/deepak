package com.test.repository;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.test.domain.CountryDetail;

public interface CountryDetailRepsitory extends JpaRepository<CountryDetail, Long>{

	CountryDetail findByName(String countryName);
	CountryDetail findByCapital(String capital);
	
	Page<CountryDetail> findAll(Pageable page);
	
	@Transactional
	void  deleteById(Long id);
}
