package com.test.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.test.config.ContentAuthProvider;
import com.test.domain.CountryDetail;
import com.test.domain.User;
import com.test.dto.UserDTO;
import com.test.service.CountryService;
import com.test.service.UserService;


@Controller
public class LoginController {
	
	Logger log =LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserDetailsService userDetailsService;
	
	@Autowired
	ContentAuthProvider contentAuthProvider;
	
	@Autowired
	CountryService countryService;
	
	 @RequestMapping("/login")
	    public String login(@ModelAttribute("userForm")UserDTO userDTO, Model model) {
	    	SecurityContextHolder.getContext().setAuthentication(null);
	        return "login";
	    }

	    @RequestMapping("/home")
	    public String home(Model model) {
	    	List<CountryDetail> countryDetailList=countryService.findAll();
    	    model.addAttribute("countryDetailList", countryDetailList);
	        return "index";
	    }

		@RequestMapping("/403")
	    public String accessDeniedPage(Model model) {
			return "403";
		}
	
	    @RequestMapping(value = "/customlogin", method = RequestMethod.POST)
	    public String loginPost(@ModelAttribute("userForm") UserDTO userVo,BindingResult result, Model model, HttpServletResponse response) {
	    Authentication auth = contentAuthProvider.authenticate(userVo);
	       if(auth != null)
	        {
	    	    List<CountryDetail> countryDetailList=countryService.findAll();
	    	    model.addAttribute("countryDetailList", countryDetailList);
	            return "index";
	        }
	        else
	        {
	            log.error("unauthorized");
	            return "login";
	        }

	    }


	    @RequestMapping(value="/AddUserAsAdmin",method=RequestMethod.POST)
	    public @ResponseBody User addUserAsAdmin(@RequestBody UserDTO user, Model model){

	        User newUser = new User(user.getUsername(),user.getPassword(),user.getUsername());

	        return userService.save(newUser);
	    }
	    @RequestMapping(value="/AddUser",method=RequestMethod.POST)
	    public @ResponseBody String addUser(@RequestParam String userName,@RequestParam String password,@RequestParam String role, Model model){

	        userService.createOrEditUser(userName,password,role);
	        return "OK";
	    }

	  
}

