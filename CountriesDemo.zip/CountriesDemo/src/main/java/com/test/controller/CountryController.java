package com.test.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.test.domain.CountryDetail;
import com.test.dto.ResponseVO;
import com.test.repository.CountryDetailRepsitory;
import com.test.service.CountryService;

@Controller
@RequestMapping("/api")
public class CountryController {

	@Autowired
	CountryService countryService;
	
	@Autowired
	CountryDetailRepsitory countryDetailRepsitory;
	
	@RequestMapping("/countries/web")
	@ResponseBody
	public void getCountryDetails(){
		countryService.getCountriesDetailsFromWebServiceAndAddItToDatabase();
	}
	
	
	/*@PostMapping("/country")
	public CountryDetail createCountry(@RequestBody CountryDetail countryDetail){
		return countryService.createOrUpdate(countryDetail);
	}
	
	@PutMapping("/country")
	public CountryDetail updateCountry(@RequestBody CountryDetail countryDetail){
		return countryService.createOrUpdate(countryDetail);
	}
	@GetMapping("/countries")
	public Page<CountryDetail> getCountriesByPage(Pageable pageable){
		return countryService.listAllCountries(pageable);
	}
	
	@GetMapping("/country/{id}")
	public CountryDetail getCountryById(@PathVariable Long id){
		return countryService.findById(id);
	}*/
	
	@RequestMapping(value="/country/{id}",method=RequestMethod.DELETE)
	@ResponseBody
	public ResponseVO deleteCountryById(@PathVariable Long id){
		return countryService.deleteCountryById(id);
	}
	
	@RequestMapping(value={"/manage/addCountry/{id}","/manage/addCountry"},method=RequestMethod.GET)
	public String addOrEditCountry(@PathVariable(required = false) Long id, @ModelAttribute("countryDetail") CountryDetail countryDetail,Model model){
		if(id != null){
	    countryDetail = countryService.findById(id);	
		model.addAttribute("countryDetail", countryDetail);
		}
	    return "countrydetails";
	}
	@RequestMapping(value="/manage/addOrEditCountry",method=RequestMethod.POST)
	public String addOrEditCountry(@ModelAttribute CountryDetail countryDetail,BindingResult result,Model model){
	    System.out.println(countryDetail);
	    try{
	    	countryDetail = countryService.createOrUpdate(countryDetail);
	    	model.addAttribute("STATUS", "SUCCESS");
	    }
	    catch(Exception e){
	    	model.addAttribute("STATUS", "ERROR");
	    	e.printStackTrace();
	    }
		return "countrydetails";
	}
	
}
