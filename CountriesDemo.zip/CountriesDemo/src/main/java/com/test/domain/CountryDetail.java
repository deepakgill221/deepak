package com.test.domain;

import java.util.List;
import java.util.Map;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="country_detail")
public class CountryDetail{

 @Id
 @GeneratedValue(strategy = GenerationType.AUTO)
 private Long id;
 
 private String name;
 @ElementCollection
 private List<String> topLevelDomain;
 private String alpha2Code;
 private String alpha3Code;

 @ElementCollection
 private List<String> callingCodes;
 private String capital;

 @ElementCollection
 private List<String> altSpellings;
 private String region;
 private String subregion;
 private Long population;
 
 @ElementCollection
 private List<Long> latlng;
 private String demonym;
 private Long area;
 private Float gini;
 
 @ElementCollection
 private List<String> timezones;
 
 @ElementCollection
 private List<String> borders;
 private String nativeName;
 private String numericCode;
 
 @ElementCollection
 private List<String> currencies;
 
 @ElementCollection
 private List<String> languages;
 
 @ElementCollection
 private Map<String,String> translations;
 private String relevance;

 
 public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<String> getTopLevelDomain() {
	return topLevelDomain;
}
public void setTopLevelDomain(List<String> topLevelDomain) {
	this.topLevelDomain = topLevelDomain;
}
public String getAlpha2Code() {
	return alpha2Code;
}
public void setAlpha2Code(String alpha2Code) {
	this.alpha2Code = alpha2Code;
}
public String getAlpha3Code() {
	return alpha3Code;
}
public void setAlpha3Code(String alpha3Code) {
	this.alpha3Code = alpha3Code;
}
public List<String> getCallingCodes() {
	return callingCodes;
}
public void setCallingCodes(List<String> callingCodes) {
	this.callingCodes = callingCodes;
}
public String getCapital() {
	return capital;
}
public void setCapital(String capital) {
	this.capital = capital;
}
public List<String> getAltSpellings() {
	return altSpellings;
}
public void setAltSpellings(List<String> altSpellings) {
	this.altSpellings = altSpellings;
}
public String getRegion() {
	return region;
}
public void setRegion(String region) {
	this.region = region;
}
public String getSubregion() {
	return subregion;
}
public void setSubregion(String subregion) {
	this.subregion = subregion;
}
public Long getPopulation() {
	return population;
}
public void setPopulation(Long population) {
	this.population = population;
}
public List<Long> getLatlng() {
	return latlng;
}
public void setLatlng(List<Long> latlng) {
	this.latlng = latlng;
}
public String getDemonym() {
	return demonym;
}
public void setDemonym(String demonym) {
	this.demonym = demonym;
}
public Long getArea() {
	return area;
}
public void setArea(Long area) {
	this.area = area;
}
public Float getGini() {
	return gini;
}
public void setGini(Float gini) {
	this.gini = gini;
}
public List<String> getTimezones() {
	return timezones;
}
public void setTimezones(List<String> timezones) {
	this.timezones = timezones;
}
public List<String> getBorders() {
	return borders;
}
public void setBorders(List<String> borders) {
	this.borders = borders;
}
public String getNativeName() {
	return nativeName;
}
public void setNativeName(String nativeName) {
	this.nativeName = nativeName;
}
public String getNumericCode() {
	return numericCode;
}
public void setNumericCode(String numericCode) {
	this.numericCode = numericCode;
}
public List<String> getCurrencies() {
	return currencies;
}
public void setCurrencies(List<String> currencies) {
	this.currencies = currencies;
}
public List<String> getLanguages() {
	return languages;
}
public void setLanguages(List<String> languages) {
	this.languages = languages;
}
public Map<String, String> getTranslations() {
	return translations;
}
public void setTranslations(Map<String, String> translations) {
	this.translations = translations;
}
public String getRelevance() {
	return relevance;
}
public void setRelevance(String relevance) {
	this.relevance = relevance;
}
@Override
public String toString() {
	return "CountryDetail [id=" + id + ", name=" + name + ", topLevelDomain=" + topLevelDomain + ", alpha2Code="
			+ alpha2Code + ", alpha3Code=" + alpha3Code + ", callingCodes=" + callingCodes + ", capital=" + capital
			+ ", altSpellings=" + altSpellings + ", region=" + region + ", subregion=" + subregion + ", population="
			+ population + ", latlng=" + latlng + ", demonym=" + demonym + ", area=" + area + ", gini=" + gini
			+ ", timezones=" + timezones + ", borders=" + borders + ", nativeName=" + nativeName + ", numericCode="
			+ numericCode + ", currencies=" + currencies + ", languages=" + languages + ", translations=" + translations
			+ ", relevance=" + relevance + "]";
}
 
 
 
 
 
}
