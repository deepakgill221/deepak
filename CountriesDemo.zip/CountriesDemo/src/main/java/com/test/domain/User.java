package com.test.domain;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name="user")
public class User implements UserDetails {
	private static final long serialVersionUID = 1L;
	private Long id;
    private String username;                    // required
    private String password;                    // required
    private String fullName;
    private String firstName;                   
    private String lastName;                    
    private String email;                       // required; unique
    private String phoneNumber;
    private Set<Role> roles = new HashSet<Role>();
    private List<Role> authorities;
    private boolean accountExpired;
    private boolean accountLocked;
    private boolean credentialsExpired;
    private boolean enabled;

   
    
    public User() {}

    public User(String username, String password,String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }

    public User(User u) {
        super();
        this.id = u.id;
        this.username = u.username;
        this.password = u.password;
        this.fullName = u.fullName;
        this.firstName = u.firstName;
        this.lastName = u.lastName;
        this.email = u.email;
        this.phoneNumber = u.phoneNumber;
        this.roles = u.roles;
        this.authorities = u.authorities;
        this.enabled = u.enabled;
        this.accountExpired = u.accountExpired;
        this.accountLocked = u.accountLocked;
        this.credentialsExpired = u.credentialsExpired;
    }


    public User(final String username) {
        this.username = username;
    }

    @Id @GeneratedValue(strategy=GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    @Column(nullable=false,length=50,unique=true)
    public String getUsername() {
        return username;
    }


    @Column(nullable=false)
    public String getPassword() {
    	return password;
    }


    public String getFullName() {
		return fullName;
	}

	@Column(name="first_name",length=50)
    public String getFirstName() {
        return firstName;
    }

    @Column(name="last_name",length=50)
    public String getLastName() {
        return lastName;
    }

    @Column(nullable=false,unique=true)
    public String getEmail() {
        return email;
    }

    @Column(name="phone_number",length=20)
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Transient
    public String getUserFullName() {
    	if(getFullName()==null || getFullName().isEmpty())
    		return firstName + ' ' + lastName;
    	else
    		return getFullName();
    }


    @ManyToMany(fetch = FetchType.EAGER) 
    @JoinTable(
            name="user_role",
            joinColumns = { @JoinColumn( name="user_id") },
            inverseJoinColumns = @JoinColumn( name="role_id")
    )    
    public Set<Role> getRoles() {
        return roles;
    }

  

    public void addRole(Role role) {
        getRoles().add(role);
    }
    

    @Transient
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorities;
    }


    @Column(name="account_expired")
    public boolean isAccountExpired() {
        return accountExpired;
    }


    @Transient
    public boolean isAccountNonExpired() {
        return !isAccountExpired();
    }

    @Column(name="account_locked")
    public boolean isAccountLocked() {
        return accountLocked;
    }


    @Transient
    public boolean isAccountNonLocked() {
        return !isAccountLocked();
    }

    @Column(name="credentials_expired")
    public boolean isCredentialsExpired() {
        return credentialsExpired;
    }

    @Transient
    public boolean isCredentialsNonExpired() {
        return !credentialsExpired;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }


    public void setId(Long id) {
        this.id = id;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    

    public void setPassword(String password) {
        this.password = password;
    }

    public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

   

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public void setAccountExpired(boolean accountExpired) {
        this.accountExpired = accountExpired;
    }

    public void setAccountLocked(boolean accountLocked) {
        this.accountLocked = accountLocked;
    }

    public void setCredentialsExpired(boolean credentialsExpired) {
        this.credentialsExpired = credentialsExpired;
    }



	/**
     * {@inheritDoc}
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof User)) {
            return false;
        }

        final User user = (User) o;

        return !(username != null ? !username.equals(user.getUsername()) : user.getUsername() != null);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        return (username != null ? username.hashCode() : 0);
    }

    


}

