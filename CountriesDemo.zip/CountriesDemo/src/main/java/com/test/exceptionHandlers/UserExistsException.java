/**
 * @author fazia
 */
package com.test.exceptionHandlers;

public class UserExistsException extends Exception {

	private static final long serialVersionUID = 8433231663237149268L;

	public UserExistsException(final String message) {
        super(message);
    }
}
