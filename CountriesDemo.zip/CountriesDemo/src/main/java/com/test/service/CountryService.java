package com.test.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.test.domain.CountryDetail;
import com.test.dto.ResponseVO;

public interface CountryService {

	public void getCountriesDetailsFromWebServiceAndAddItToDatabase();
	
	public CountryDetail createOrUpdate(CountryDetail countryDetail);
	public CountryDetail findById(Long id);
	public Page<CountryDetail> listAllCountries(Pageable pageable);
	public CountryDetail deleteCountry(Long id);
	List<CountryDetail> findAll();
	public ResponseVO deleteCountryById(Long id);
	
	
	
}
