package com.test.service;

import com.test.domain.User;

import java.util.List;

public interface UserService {

	public User save(User user);
	public List<User> findAll();
	public void createOrEditUser(String username,String password,String role);
	
	
}
