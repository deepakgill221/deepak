package com.test.service;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.domain.CountryDetail;
import com.test.dto.ResponseVO;
import com.test.repository.CountryDetailRepsitory;

@Service
public class CountryServiceImpl implements CountryService{

	
	@Autowired
	CountryDetailRepsitory countryDetailRepsitory;
	
	private void trustHttps(){
		try {

			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			}
			};

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);

		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (KeyManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	@Override
	public void getCountriesDetailsFromWebServiceAndAddItToDatabase() {
		// TODO Auto-generated method stub
		RestTemplate restTemplate=new RestTemplate();
		trustHttps();
		String response =restTemplate.getForObject("https://restcountries.eu/rest/v1/all",String.class);
		
		ObjectMapper objectMapper=new ObjectMapper();
		List<CountryDetail> countryDetails=new ArrayList<>();
		try {
				countryDetails=objectMapper.readValue(response,new TypeReference<List<CountryDetail>>(){});
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(countryDetails.size());
		countryDetailRepsitory.save(countryDetails);
	}

	@Override
	public CountryDetail createOrUpdate(CountryDetail countryDetail) {
		// TODO Auto-generated method stub
		return countryDetailRepsitory.save(countryDetail);
	}

	@Override
	public CountryDetail findById(Long id) {
		// TODO Auto-generated method stub
		CountryDetail countryDetail=countryDetailRepsitory.findOne(id);
		if(countryDetail == null){
			throw new ResourceNotFoundException("No country found with given Id");
		}
		return countryDetail;
	}

	@Override
	public Page<CountryDetail> listAllCountries(Pageable pageable) {
		// TODO Auto-generated method stub
		Page<CountryDetail> page=countryDetailRepsitory.findAll(pageable);
		System.out.println(page);
		return page;
	}

	@Override
	public CountryDetail deleteCountry(Long id) {
		// TODO Auto-generated method stub
		CountryDetail countryDetail=countryDetailRepsitory.findOne(id);
		if(countryDetail == null){
			throw new ResourceNotFoundException("No Country found with given id");
		}
		countryDetailRepsitory.delete(countryDetail);
		return countryDetail;
	}

	@Override
	public List<CountryDetail> findAll() {
		// TODO Auto-generated method stub
		return countryDetailRepsitory.findAll();
	}

	@Override
	public ResponseVO deleteCountryById(Long id) {
		// TODO Auto-generated method stub
		CountryDetail countryDetail =countryDetailRepsitory.findOne(id);
		 ResponseVO returnStatus=new ResponseVO();
	      if(countryDetail == null){
	    	returnStatus.setStatusCode(500); 
			returnStatus.setMessage("No Country Exists");
			return returnStatus;
	      }
	      countryDetailRepsitory.delete(countryDetail);
	      returnStatus.setStatusCode(200); //error
		  returnStatus.setMessage("Delete Successfull!");
		  return returnStatus;
	}

	
}
