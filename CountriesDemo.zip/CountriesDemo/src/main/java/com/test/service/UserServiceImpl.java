package com.test.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.test.domain.*;
import com.test.domain.User;
import com.test.repository.RoleRepository;
import com.test.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService ,UserDetailsService{

	Logger log=Logger.getLogger(this.getClass());
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	RoleRepository roleRepo;

	@Override
	public User save(User u) {
		Role role =roleRepo.findByName("ROLE_ADMIN");
		if(role == null ) {
			Role adminRole =new Role();
			adminRole.setName("ROLE_ADMIN");
			adminRole.setDescription("Administration Role");
			roleRepo.save(adminRole);
		}
		String pass = u.getPassword();
		u.setPassword(passwordEncoder.encode(pass));
		u.addRole(roleRepo.findByName("ROLE_ADMIN"));
		return userRepository.save(u);
	}

	@Override
	public List<User> findAll() {
		
		return userRepository.findAll();
	}

	@Override
	public void createOrEditUser(String username,String password,String role) {
		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(username);
		user.addRole(roleRepo.findByName(role));

		List<User> userList = userRepository.findByEmail(user.getEmail());
		if((userList == null) || (userList.isEmpty())){
			try {
				save(user);
			} catch (Exception e) {
				log.error(e);
			}
		}

	}
   	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		  User user = userRepository.findByUsername(username);
	        if(user == null) {
	        	return null;
	        }
	        else
	        return new CustomUserDetails(user);
	}
	    private final static class CustomUserDetails extends User implements UserDetails {
	
	        private CustomUserDetails(User user) {
	            super(user);
	        }
	
	    }
}
