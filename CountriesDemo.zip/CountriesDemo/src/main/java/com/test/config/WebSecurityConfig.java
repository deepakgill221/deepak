package com.test.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.data.repository.query.SecurityEvaluationContextExtension;



@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

  
  

    //By defining this object as a Bean, Spring Security is exposed as SpEL expressions for creating Spring Data queries
    @Bean
    public SecurityEvaluationContextExtension securityEvaluationContextExtension() {
        return new SecurityEvaluationContextExtension();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();
    }



    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
        .authorizeRequests()
        .antMatchers("/resources/**","/login","/logout","/loginPost","/forgotPassword","/changePasswordOnRequest","/changeDefaultPassword").permitAll()
        .antMatchers("/logindo","/customlogin","/AddUserAsAdmin/**").permitAll()
        
        .anyRequest().authenticated()
        .and()
        .csrf().disable() 
        .formLogin().loginPage("/login").failureUrl("/login").defaultSuccessUrl("/home")
        .and()
        .exceptionHandling().accessDeniedPage("/403")
        .and().httpBasic();
 

    }


}