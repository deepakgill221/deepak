package com.test.config;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;



@Service
public class ContentAuthProvider implements  AuthenticationManager, AuthenticationProvider {


	@Autowired
	UserDetailsService userDetailsService;

	@Autowired
	private PasswordEncoder passwordEncoder;


	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		Authentication auth=null;
        String username = authentication.getName();
		String password=authentication.getCredentials().toString();
		System.out.println("Attempting auth! " + username + "---" + password);
		UserDetails userDetails= userDetailsService.loadUserByUsername(username);
		if(userDetails != null)
		{


			if(passwordEncoder.matches(password,userDetails.getPassword())){
				
				auth = new UsernamePasswordAuthenticationToken(userDetails,password,userDetails.getAuthorities() );
				System.out.println("role -> "+userDetails.getAuthorities());
				SecurityContext securityContext = SecurityContextHolder.getContext();
		        securityContext.setAuthentication(auth);
				
			   
			
			    
				
				
				return auth;
			}

			else {
				System.out.println("*****************Authentication failed******* wrong password**********");
				return null;
			}
		}
		else
		{
			System.out.println("*****************Authentication failed*********wrong username*********userdetailsnull");
			return null;
		}
	}

	public boolean supports(Class<?> authentication) {
		
		return true;
	}



}
