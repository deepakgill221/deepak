

 //populateSidebar();

 $.contextMenu({
	        selector: '.context-menu-package',
	        trigger:'left',
	      build: function ($trigger, e) {
	            return {
	            	callback: function(key, options) {
	                   if(key == 'add')
	                   {
                            redirectUrl(context+"/package/addPackage");
	                   }
	                },
	                items:  {
                                    "add": { name: "Add Package"}
                                   }
	            };
	        }

	    });

 $.contextMenu({
	        selector: '.context-menu-one',
	        
	      build: function ($trigger, e) {
	            return {
	            	callback: function(key, options) {
	                   var id = $(this).attr('id');
	                   if(key == 'add')
	                   {
                            
                            redirectUrl(context+"/topic/addTopic/"+id);
	                    }
	                    if(key == 'manage')
    	                {
                            
                             redirectUrl(context+"/package/managePackage/"+id);
    	           	    }


	                },
	                items: loadMe($trigger.attr("id"))
	            };
	        }

	    });


function loadMe(id)
{
//alert(id);
return {
         "add": { name: "Add Topic"},
         "manage": { name: "Manage"},
        }
}

$.contextMenu({
	        selector: '.context-menu-topic',
	        trigger:'left',
	      build: function ($trigger, e) {
	            return {
	            	callback: function(key, options) {
	                   var id = $(this).attr('id');

	                   if(key == 'add')
	                   {
	                	   
	                	   redirectUrl(context+"/video/UploadVideos/"+id);
	            	    }
	                    if(key == 'manage')
    	                   {
                            
                            redirectUrl(context+"/topic/manageTopic/"+id);
    	            	    }


	                },
	                items: loadMeTopic($trigger.attr("id"))
	            };
	        }

	    });


function loadMeTopic(id)
{
//alert(id);
return {
         "add": { name: "Upload Video"},
         "manage": { name: "Manage"},
        }
}


function redirectUrl(url){
location.href = url;
}

function populateSidebar(){
$.ajax({

	url: contextPath+"/api/getHierarchyMap",
	success:function(result){
		var mainMen='';

		$.each(result, function(index, menu) {
			var menuItem = "";
			 if(menu != null)
				{
				var mapsize = Object.keys(menu.topicDTOMap).length;
				console.log("size "+mapsize);
				 if(mapsize > 0)
					 {
					 menuItem = '<li class="treeview">'+
                                           '<a href="#"  class="context-menu-one" id="'+menu.id+'"><i class="fa fa-link"></i> <span>'+menu.packageName+'</span>'+
                                             '<span class="pull-right-container">'+
                                               '<i class="fa fa-angle-left pull-right"></i>'+
                                             '</span>'+
                                           '</a>'+
                                           '<ul class="treeview-menu">';
                                            var sub="";
                                            $.each(menu.topicDTOMap, function(i, v) {

                                            sub+= ' <li><a href="#"  class="context-menu-topic" id="'+v.id+'">'+v.topicName+'</a></li>';

                                            });
			        mainMen += menuItem + sub + '</ul></li>';
					 }
				 else
					 {
					 mainMen += '<li><a href="#"  class="context-menu-one" id="'+menu.id+'" ><i class="fa fa-link"></i> <span>'+menu.packageName+'</span></a></li>';
					 }
		    }

        });
		finalMenu = '<li class="header context-menu-package">Packages</li>'+mainMen;
		$('#sidemenu').html(finalMenu);

	}
});
}



var bodyHeight = $('body').height();
var finalH = bodyHeight - (71);
$('.main-sidebar').height(finalH);