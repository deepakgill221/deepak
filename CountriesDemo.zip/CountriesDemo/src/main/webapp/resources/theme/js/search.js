$(document).ready(function() {
 /* $(".search").keyup(function () {
    var searchTerm = $(".search").val();
    var listItem = $('.results tbody').children('tr');
    var searchSplit = searchTerm.replace(/ /g, "'):containsi('")
    if(searchTerm.length > 3)
    	{
    	
  $.extend($.expr[':'], {'containsi': function(elem, i, match, array){
	  console.log("in"+elem.textContent);
        return (elem.textContent || elem.innerText || '').toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
  });
    
  $(".results tbody tr").not(":containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','false');

  });

  $(".results tbody tr:containsi('" + searchSplit + "')").each(function(e){
    $(this).attr('visible','true');
	$(".results tbody tr td.searchtable tr").attr('visible','true');
	
	});

  var jobCount = $('.results tbody tr[visible="true"]').length;
    $('.counter').text(jobCount + ' item');

  if(jobCount == '0') {$('.no-result').show();}
    else {$('.no-result').hide();}
    	}
    else
    	{
    	 $(".results tbody tr").each(function(e){
    		    $(this).attr('visible','true');

    		  });
    	}
		  });
  
  
  */
  
	var isOpera = (!!window.opr && !!opr.addons) || !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
    // Firefox 1.0+
var isFirefox = typeof InstallTrigger !== 'undefined';
    // At least Safari 3+: "[object HTMLElementConstructor]"
var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0;
    // Internet Explorer 6-11
var isIE = /*@cc_on!@*/false || !!document.documentMode;
    // Edge 20+
var isEdge = !isIE && !!window.StyleMedia;
    // Chrome 1+
var isChrome = !!window.chrome && !!window.chrome.webstore;
    // Blink engine detection
var isBlink = (isChrome || isOpera) && !!window.CSS;

 $(".search").keyup(function () {
	  var value = "";
	  if(isIE)
		  value = this.value;
	  else
		  value = this.value.toLowerCase().trim();
	  if(value.length>3)
		  {
	    $("table tr").each(function (index) {
	        if (!index) return;
	        $(this).find("td").each(function () {
	            var id = "";
	            if(isIE)
	      		  id = $(this).text();
	            else
	            	 id = $(this).text().toLowerCase().trim();
	            var not_found = (id.indexOf(value) == -1);
	            $(this).closest('tr').toggle(!not_found);
	            return not_found;
	        });
	    });
	    
	    
 }
	  else if(value.length == 0)
  	{
		  $("table tr").each(function (index) {
			  $(this).find("td").each(function () {
			  $(this).closest('tr').toggle();																																																																																																																																														
			  });
  		  });
		  $("#tabel1").tablesorter().tablesorterPager({container: $("#pager")});
  	}
	});
  
  
  
  
  
});