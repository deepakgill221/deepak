package com.mli.leadfirst.interceptor;

import java.util.Map;
/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface GenderIntent {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String genderResponse(Map<String,Map<String,String>> map, String sessionId);

}
