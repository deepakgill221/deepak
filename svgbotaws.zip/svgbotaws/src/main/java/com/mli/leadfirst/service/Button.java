package com.mli.leadfirst.service;

import com.mli.leadfirst.button.InnerData;

/**
 * @author sc05216
 *
 */
public interface Button 
{
	/**
	 * @return
	 */
	public InnerData getButtonsYesNo();
	/**
	 * @return
	 */
	public InnerData getButtonsGender();
	/**
	 * @return
	 */
	public InnerData resendOtp();
}
