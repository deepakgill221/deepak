package com.mli.leadfirst.service;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface GetMessageService 
{
	/**
	 * @param botName
	 * @return
	 *
	 */

	public String getMessageAPI(String botName);

}
