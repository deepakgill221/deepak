package com.mli.leadfirst.interceptor;

import java.util.Map;

/**
 * @author sc05216
 *
 */
@FunctionalInterface
public interface MobileNumberIntent {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String mobileNumberResponse(Map<String,Map<String,String>> map, String sessionId);

}
