package com.mli.leadfirst.service;

import java.util.Map;

public interface SendSmsService {
	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String sendSmsServiceCall(Map<String, Map<String, String>> map, String sessionId);

}
