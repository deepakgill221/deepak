package com.mli.leadfirst.commons;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.mli.leadfirst.serviceimpl.SmokerServiceImpl;

/**
 * @author sc05216
 *
 */
@Service
public class CalculateAge {

	private static Logger logger = LogManager.getLogger(SmokerServiceImpl.class);
	
	public int getAge(Map<String, Map<String, String>> map, String sessionId){
	String userDate = map.get(sessionId).get("date");
	logger.info("User Date :- "+userDate);
	SimpleDateFormat sdfFormat = new SimpleDateFormat("dd-MM-yyyy");
	Date datef = new Date();
	int finalage;
	String currentDate = sdfFormat.format(datef);
	logger.info("SMOKER API : - Current Date :- "+currentDate);
	String[] str1 = userDate.split("-");
	String[] str2 = currentDate.split("-");
	int dob1= Integer.parseInt(str1[2]);
	int dob2= Integer.parseInt(str2[2]);

	int month1= Integer.parseInt(str1[1]);
	int month2= Integer.parseInt(str2[1]);
	int date1 = Integer.parseInt(str1[0]);
	int date2 = Integer.parseInt(str2[0]);

	if(month2>=month1){
		if(date2>=date1){
			finalage = dob2-dob1;
		}
		else
		{
			finalage=dob2-dob1-1;
		}
	}
	else
	{
		finalage=dob2-dob1-1;
	}
	return finalage;
}

}