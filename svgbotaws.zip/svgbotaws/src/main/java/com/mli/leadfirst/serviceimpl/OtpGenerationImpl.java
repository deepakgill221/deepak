package com.mli.leadfirst.serviceimpl;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mli.leadfirst.commons.BeanProperty;
import com.mli.leadfirst.service.OtpGeneration;
import com.mli.leadfirst.utils.CommonUtility;
import com.mli.leadfirst.utils.HttpCaller;

/**
 * @author sc05216
 *
 */

@Service
public class OtpGenerationImpl implements OtpGeneration {
	
	private static Logger logger = LogManager.getLogger(OtpGenerationImpl.class);
	
	@Autowired
	private BeanProperty bean;
	@Autowired
	private HttpCaller httpCaller;
	@Autowired
	private CommonUtility commonUtility;
	
	/**
	 * (non-Javadoc)
	 * @param java.util.Map
	 * @param java.lang.String
	 * @return java.lang.String
	 */
	
	@Override
	public String generateOtp(Map<String, Map<String, String>> map, String sessionId)
	{
		logger.info("SendSMSservicecall method start :: sessionId :: " + sessionId);
		
		StringBuilder result = new StringBuilder();
		try{
			String extURL = bean.getGenerateOtp(); 
			String soaAppId=bean.getGenerateOtpAppId();
			int correlationId = commonUtility.getRandomNumber();
			
			logger.info("SessionId :: " + sessionId + " :: API :: " + "Generate OTP :: CorrelationId :: " +correlationId);
			StringBuilder requestData = new StringBuilder();
			
			requestData.append("	{	");
			requestData.append("	   \"header\": {	");
			requestData.append("	      \"soaCorrelationId\": \""+correlationId+"\",	");
			requestData.append("	      \"soaMsgVersion\": \"1.0\",	");
			requestData.append("	      \"soaAppId\": \""+soaAppId+"\"	");
			requestData.append("	   },	");
			requestData.append("	   \"payload\": {	");
			requestData.append("	      \"stepId\": \"\",	");
			requestData.append("	      \"unqTokenNo\": \"\"	");
			requestData.append("	   }}	");
			httpCaller.callHttp(extURL, requestData, result);

		}
		catch(Exception ex)
		{
			logger.error("Exception in getting otp "+ex);
		}
		logger.info("SendSMSservicecall method end :: sessionId :: " + sessionId);
		return result.toString();
	}
}
