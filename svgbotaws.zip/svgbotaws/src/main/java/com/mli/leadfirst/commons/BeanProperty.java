package com.mli.leadfirst.commons;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author sc05216
 *
 */

@Component
public class BeanProperty 
{
	@Value("${env.productpremium}")
	private String productpremium;
	
	@Value("${env.createLead}")
	private String createLead;
	
	@Value("${env.createGetLead}")
	private String getLead;
	
	@Value("${env.reDirectURL}")
	private String reDirectURL;
	
	@Value("${env.soaUserId}")
	private String soaUserId;
	
	@Value("${env.soaPassword}")
	private String soaPassword;
	
	@Value("${env.adoptionlogs}")
	private String adoptionlogs;
	
	@Value("${env.svgURL}")
	private String svgURL;
	
	@Value("${env.svgUserId}")
	private String svgUserId;
	
	@Value("${env.svgPassword}")
	private String svgPassword;
	
	@Value("${env.getMessageAPI}")
	private String getMessageAPI;
	
	@Value("${session.expire.message}")
	private String sessionExpireMsg;
	
	@Value("${cache.clear}")
	private String chacheClear;
	
	@Value("${env.generateOtp}")
	private String generateOtp;
	
	@Value("${env.generateOtpAppId}")
	private String generateOtpAppId;
	
	@Value("${env.validateOtp}")
	private String validateOtp;
	
	@Value("${env.validateOtpAppId}")
	private String validateOtpAppId;
	
	@Value("${env.send.sms.api}")
	private String sendSmsApi;
	
	@Value("${env.sendsms.consumerid}")
	private String sendSmsConsumerId;
	
	@Value("${env.sendsms.appAccId}")
	private String sendSmsAppAccId;
	
	@Value("${env.sendsms.appAccPass}")
	private String sendSmsAppAccPass;
	
	@Value("${env.sendsms.appId}")
	private String sendSmsAppId;
	
	public String getSoaUserId() {
		return soaUserId;
	}

	public void setSoaUserId(String soaUserId) {
		this.soaUserId = soaUserId;
	}

	public String getSoaPassword() {
		return soaPassword;
	}

	public void setSoaPassword(String soaPassword) {
		this.soaPassword = soaPassword;
	}

	public String getProductpremium() {
		return productpremium;
	}

	public void setProductpremium(String productpremium) {
		this.productpremium = productpremium;
	}

	public String getCreateLead() {
		return createLead;
	}

	public void setCreateLead(String createLead) {
		this.createLead = createLead;
	}

	public String getGetLead() {
		return getLead;
	}

	public void setGetLead(String getLead) {
		this.getLead = getLead;
	}

	public String getReDirectURL() {
		return reDirectURL;
	}

	public void setReDirectURL(String reDirectURL) {
		this.reDirectURL = reDirectURL;
	}

	public String getAdoptionlogs() {
		return adoptionlogs;
	}

	public void setAdoptionlogs(String adoptionlogs) {
		this.adoptionlogs = adoptionlogs;
	}

	public String getSvgURL() {
		return svgURL;
	}

	public void setSvgURL(String svgURL) {
		this.svgURL = svgURL;
	}

	public String getSvgUserId() {
		return svgUserId;
	}

	public void setSvgUserId(String svgUserId) {
		this.svgUserId = svgUserId;
	}

	public String getSvgPassword() {
		return svgPassword;
	}

	public void setSvgPassword(String svgPassword) {
		this.svgPassword = svgPassword;
	}

	public String getGetMessageAPI() {
		return getMessageAPI;
	}

	public void setGetMessageAPI(String getMessageAPI) {
		this.getMessageAPI = getMessageAPI;
	}

	public String getSessionExpireMsg() {
		return sessionExpireMsg;
	}

	public void setSessionExpireMsg(String sessionExpireMsg) {
		this.sessionExpireMsg = sessionExpireMsg;
	}

	public String getChacheClear() {
		return chacheClear;
	}

	public void setChacheClear(String chacheClear) {
		this.chacheClear = chacheClear;
	}

	public String getGenerateOtp() {
		return generateOtp;
	}

	public void setGenerateOtp(String generateOtp) {
		this.generateOtp = generateOtp;
	}
	
	public String getGenerateOtpAppId() {
		return generateOtpAppId;
	}

	public void setGenerateOtpAppId(String generateOtpAppId) {
		this.generateOtpAppId = generateOtpAppId;
	}
	
	public String getValidateOtp() {
		return validateOtp;
	}

	public void setValidateOtp(String validateOtp) {
		this.validateOtp = validateOtp;
	}

	public String getValidateOtpAppId() {
		return validateOtpAppId;
	}

	public void setValidateOtpAppId(String validateOtpAppId) {
		this.validateOtpAppId = validateOtpAppId;
	}
	
	public String getSendSmsApi() {
		return sendSmsApi;
	}

	public void setSendSmsApi(String sendSmsApi) {
		this.sendSmsApi = sendSmsApi;
	}

	public String getSendSmsConsumerId() {
		return sendSmsConsumerId;
	}

	public void setSendSmsConsumerId(String sendSmsConsumerId) {
		this.sendSmsConsumerId = sendSmsConsumerId;
	}

	public String getSendSmsAppAccId() {
		return sendSmsAppAccId;
	}

	public void setSendSmsAppAccId(String sendSmsAppAccId) {
		this.sendSmsAppAccId = sendSmsAppAccId;
	}

	public String getSendSmsAppAccPass() {
		return sendSmsAppAccPass;
	}

	public void setSendSmsAppAccPass(String sendSmsAppAccPass) {
		this.sendSmsAppAccPass = sendSmsAppAccPass;
	}
	
	public String getSendSmsAppId() {
		return sendSmsAppId;
	}

	public void setSendSmsAppId(String sendSmsAppId) {
		this.sendSmsAppId = sendSmsAppId;
	}

	@Override
	public String toString() {
		return "BeanProperty [productpremium=" + productpremium + ", createLead=" + createLead + ", getLead=" + getLead
				+ ", reDirectURL=" + reDirectURL + ", soaUserId=" + soaUserId + ", soaPassword=" + soaPassword
				+ ", adoptionlogs=" + adoptionlogs + ", svgURL=" + svgURL + ", svgUserId=" + svgUserId
				+ ", svgPassword=" + svgPassword + ", getMessageAPI=" + getMessageAPI + ", sessionExpireMsg="
				+ sessionExpireMsg + ", chacheClear=" + chacheClear + ", generateOtp=" + generateOtp
				+ ", generateOtpAppId=" + generateOtpAppId + ", validateOtp=" + validateOtp + ", validateOtpAppId="
				+ validateOtpAppId + ", sendSmsApi=" + sendSmsApi + ", sendSmsConsumerId=" + sendSmsConsumerId
				+ ", sendSmsAppAccId=" + sendSmsAppAccId + ", sendSmsAppAccPass=" + sendSmsAppAccPass
				+ ", sendSmsAppId=" + sendSmsAppId + "]";
	}

	

}
