package com.mli.leadfirst.interceptor;

import java.util.Map;


/**
 * @author sc05216
 *
 */

public interface OtpValidateIntent {

	/**
	 * @param map
	 * @param sessionId
	 * @return
	 */
	public String otpValidate(Map<String, Map<String, String>> map, String sessionId);
	
}
