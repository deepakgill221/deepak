package com.csg.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;
@Component
public class CommonUtility {

	public String getCurrentDateAndTime() {
	Date date = new Date();
	String pattern = "MM/dd/yyyy HH:mm:ss";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	return  simpleDateFormat.format(date);
}
	
	public String nullThenBlank(String str) {
		
		if(str!=null && !"".equalsIgnoreCase(str)) {
			
			return str.trim();
		}
		return "";
	}
	
}
