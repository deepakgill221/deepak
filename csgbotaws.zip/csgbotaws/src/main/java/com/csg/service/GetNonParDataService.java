package com.csg.service;

public interface GetNonParDataService {

	public String getNonPerData(String age,String term,String pocket,String plan);
	
}
