package com.csg.service;

public interface GetMessageService 
{
	public String getCsgMessages(String botName);

}
