package com.csg.response;

import org.springframework.stereotype.Service;

@Service
public class GenericResponse 
{
	String speech="";
	public String genericResponse( String speech)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ]	");
		sb.append("	 }	");
		return sb.toString();
	}
}
