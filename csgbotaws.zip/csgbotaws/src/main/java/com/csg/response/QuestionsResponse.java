package com.csg.response;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class QuestionsResponse 
{
	String speech="";
	public String questionsResponse(String sessionId, String speech, String action, Map<String,Map<String,String>> questionAswerMap)
	{
		String speeches=speech.replaceAll("[-+^/]\"]*", "");
		speech=speeches.replaceAll("\"", "");
		StringBuilder sb = new StringBuilder();
		
		
		if("Q3".equalsIgnoreCase(action))
		{
			sb=q3Response(speech);
			
		}
		else if("Q4".equalsIgnoreCase(action) && "PG".equalsIgnoreCase(questionAswerMap.get(sessionId).get("Q3")+""))
		{
			sb=q4WithPG(speech);
			
			
		}
		else if("Q4".equalsIgnoreCase(action) && "UG".equalsIgnoreCase(questionAswerMap.get(sessionId).get("Q3")+""))
		{
			sb=q4WithUG(speech);
			
			
		}
		else if("Q5".equalsIgnoreCase(action) && !"FilmMaking".equalsIgnoreCase(questionAswerMap.get(sessionId).get("Q4")))
		{
			sb=q5WithOutFilmMaking(speech);
			
			
		}
		else if("Q5".equalsIgnoreCase(action) && "FilmMaking".equalsIgnoreCase(questionAswerMap.get(sessionId).get("Q4")))
		{
			sb=q5WithFilmMaking(speech);
			
			
		}
		else if("Q26".equalsIgnoreCase(action))
		{
			sb=q26Response(speech);
			
			
		}
		else
		{
			sb.append("	{	");
			sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
			sb.append("	  \"fulfillmentMessages\": [	");
			sb.append("	    {	");
			sb.append("	      \"text\": {	");
			sb.append("	        \"text\": [\""+speech+"\"]	");
			sb.append("	      }	");
			sb.append("	    }	");
			sb.append("	  ]	");
			sb.append("	 }	");
		}
		return sb.toString();
	}
	private StringBuilder q26Response(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		
		sb.append("	      \"buttons\": [	");
		
		sb.append("	        {	");
		sb.append("	          \"text\": \" Low\",	");
		sb.append("	          \"postback\": \"Low\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		
		sb.append("	        {	");
		sb.append("	          \"text\": \"Medium\",	");
		sb.append("	          \"postback\": \"Medium\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		
		sb.append("	        {	");
		sb.append("	          \"text\": \"High\",	");
		sb.append("	          \"postback\": \"High\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");
		
		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");
		return sb;
	}
	private StringBuilder q5WithFilmMaking(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" India\",	");
		sb.append("	          \"postback\": \"India\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" US\",	");
		sb.append("	          \"postback\": \"US\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" UK\",	");
		sb.append("	          \"postback\": \"UK\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Australia\",	");
		sb.append("	          \"postback\": \"Australia\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");

		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");
		return sb;
	}
	private StringBuilder q5WithOutFilmMaking(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" India\",	");
		sb.append("	          \"postback\": \"India\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" US\",	");
		sb.append("	          \"postback\": \"US\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" UK\",	");
		sb.append("	          \"postback\": \"UK\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Australia\",	");
		sb.append("	          \"postback\": \"Australia\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Singapore\",	");
		sb.append("	          \"postback\": \"Singapore\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");
		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");
		return sb;
	}
	private StringBuilder q4WithUG(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" Arts\",	");
		sb.append("	          \"postback\": \"Arts\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" Science\",	");
		sb.append("	          \"postback\": \"Science\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Commerce\",	");
		sb.append("	          \"postback\": \"Commerce\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Law\",	");
		sb.append("	          \"postback\": \"Law\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Engineering\",	");
		sb.append("	          \"postback\": \"Engineering\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Fashion\",	");
		sb.append("	          \"postback\": \"Fashion\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"Medical\",	");
		sb.append("	          \"postback\": \"MedicalUG\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");
		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");
		return sb;
	}
	private StringBuilder q4WithPG(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" Management\",	");
		sb.append("	          \"postback\": \"Management\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" Medical\",	");
		sb.append("	          \"postback\": \"Medical\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" MTech/Msc\",	");
		sb.append("	          \"postback\": \"MTechMsc\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" FilmMaking(2Year)\",	");
		sb.append("	          \"postback\": \"FilmMaking\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");
		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");
		return sb;
	}
	private StringBuilder q3Response(String speech) {
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");
		sb.append("	        {	");
		sb.append("	          \"text\": \"PostGraduation\",	");
		sb.append("	          \"postback\": \"PG\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        },	");
		sb.append("	        {	");
		sb.append("	          \"text\": \" Graduation\",	");
		sb.append("	          \"postback\": \"UG\",	");
		sb.append("	          \"link\": \"\"	");
		sb.append("	        }	");
		sb.append("	      ]	");
		sb.append("	    }	");
		sb.append("	  },	");
		sb.append("	  \"source\": \"java-webhook\"	");
		sb.append("	}	");

		return sb;
	}
}
