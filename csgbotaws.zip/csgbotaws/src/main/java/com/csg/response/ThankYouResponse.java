package com.csg.response;

import org.springframework.stereotype.Service;
@Service
public class ThankYouResponse {
	String speech="";
	public String thankyouResponse(String speech)
	{
		
		StringBuilder sb = new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");

		
		StringBuilder sb3 = new StringBuilder();
		sb3.append("	      ]	");
		sb3.append("	    }	");
		sb3.append("	  },	");
		sb3.append("	  \"source\": \"java-webhook\"	");
		sb3.append("	}	");
		sb.append(sb3.toString());
		return sb.toString();
	}
}
