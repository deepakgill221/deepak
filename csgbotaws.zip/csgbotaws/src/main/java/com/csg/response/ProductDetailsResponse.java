package com.csg.response;

import java.util.Map;

import org.springframework.stereotype.Service;
@Service
public class ProductDetailsResponse {
	String speech="";
	public String productResponse(Map<String,Map<String,String>> ExternalMap, String sessionId)
	{
		speech=ExternalMap.get(sessionId+"Msg").get("ProductRecoMsg");
		StringBuffer sb = new StringBuffer();
		sb.append("	{	");
		sb.append("	  \"fulfillmentText\": \"displayed&spoken response\",	");
		sb.append("	  \"fulfillmentMessages\": [	");
		sb.append("	    {	");
		sb.append("	      \"text\": {	");
		sb.append("	        \"text\": [\""+speech+"\"]	");
		sb.append("	      }	");
		sb.append("	    }	");
		sb.append("	  ],	");
		sb.append("	  \"payload\": {	");
		sb.append("	    \"facebook\": {	");
		sb.append("	      \"type\": \"Chatbot\",	");
		sb.append("	      \"platform\": \"API.AI\",	");
		sb.append("	      \"title\": \"MLIChatBot\",	");
		sb.append("	      \"imageUrl\": \"BOT\",	");
		sb.append("	      \"buttons\": [	");

		StringBuffer sb2= new StringBuffer();
		String productDetails = ExternalMap.get(sessionId+"ProductMsg").get("ProductDetailsQuestion")+"";
			
				sb2.append("	        {	");
				sb2.append("	          \"text\": \" "+productDetails+"\",	");
				sb2.append("	          \"postback\": \"\",	");
				sb2.append("	          \"link\": \"\"	");
				sb2.append("	        },	");
			
				sb2.append("	        {");
				sb2.append("	          \"text\": \"Know More\",");
				sb2.append("	          \"postback\": \"\",	");
				sb2.append("	          \"link\": \"\"	");
				sb2.append("	        },	");
				sb2.append("	        {");
				sb2.append("	          \"text\": \"Get Quote\",");
				sb2.append("	          \"postback\": \"\",	");
				sb2.append("	          \"link\": \"\"	");
				sb2.append("	        }	");
			
		
		sb.append(sb2.toString());
		StringBuffer sb3 = new StringBuffer();
		sb3.append("	      ]	");
		sb3.append("	    }	");
		sb3.append("	  },	");
		sb3.append("	  \"source\": \"java-webhook\"	");
		sb3.append("	}	");
		sb.append(sb3.toString());
		
		return sb.toString();
	}
}
