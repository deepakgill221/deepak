package com.csg.serviceimpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.csg.commons.BeanProperty;
import com.csg.service.GetNonParDataService;
@Service
public class GetNonParDataImpl implements GetNonParDataService{

	@Autowired
	private BeanProperty bean;

	String textResponse="";
	private static Logger logger = LogManager.getLogger(GetNonParDataImpl.class);
     
	@Override
	public String getNonPerData(String age, String term, String pocket, String plan)
	{
		logger.info("GetNonParDataImpl :: Start getNonPerData ...");
		try{
		String url=bean.getGetNonParData();
		ResponseEntity<String> response=null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder sb=new StringBuilder();
		sb.append("	{	");
		sb.append("	  \"age\":\""+age+"\",	");
		sb.append("	  \"term\":\""+term+"\",	");
		sb.append("	  \"pocket\":\""+pocket+"\",	");
		sb.append("	  \"plan\":\""+plan+"\"	");
		sb.append("	}	");

		HttpEntity<String> entity=new HttpEntity<>(sb.toString(),	headers);
		RestTemplate restTemplate=new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
		
		response = restTemplate.exchange(url, HttpMethod.POST, entity,String.class);
		if(response.getStatusCodeValue() == 200)
		{
			textResponse = response.getBody();

		}
		}catch(Exception e)
		{
			textResponse="";
		  logger.info("creating exception GetNonParDataImpl :  getNonPerData "+e);	
		}
		logger.info("GetNonParDataImpl :: End  getNonPerData ...with Response  "+textResponse);
		return textResponse;
	}
}
