package com.csg.modelimpl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.csg.model.EmailQuestion;

@Service
public class EmailQuestionServiceImpl implements EmailQuestion {

	@Override
	public String emailQuestion(Map<String, Map<String, String>> externalMap, String sessionId, String action,
			String questions) {
		return null;
	}

}
