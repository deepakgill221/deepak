package com.csg.commons;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.csg.service.NeedAnalysisService;
import com.csg.utils.CommonUtility;


@Service
public class SessionTimeOut {
	
	private static Logger logger = LogManager.getLogger(SessionTimeOut.class);	
	@Autowired
	private CalculateTimeDiff calculateTimeDiff;
	
	@Autowired
	CommonUtility commonUtility;
	@Autowired
	NeedAnalysisService needAnalysisService;
	
	
	
	/**
	 * @param externalMap
	 * Used for removing sessions from cache
	 */
	public void cashRemovetimeout(Map<String, Map<String,String>> externalMap, Map<String, Map<String,String>> questionAswerMap,
			Map<String, Map<String,String>> response ,Map<String,String> tokenCache)
	{
		logger.info("start cashRemovetimeout ..");
		
		setTokenInCachse(tokenCache);
		
		try 
		{
		for(Map.Entry<String, Map<String, String>> entry : externalMap.entrySet())
		{
			String keytoremove = entry.getKey();
			Map<String,String> valueMap = entry.getValue();
			
			for(Map.Entry<String,String> getKeyValueMap : valueMap.entrySet())
			{
				if(getKeyValueMap.getKey().contains(keytoremove))
				{
					String logntimevalue = getKeyValueMap.getValue();
					long diffminutes = calculateTimeDiff.timeDiffInMinute(commonUtility.getCurrentDateAndTime(), logntimevalue);
					if(diffminutes >=9)
					{
						callArciseApiWhileSessionTimeOut(needAnalysisService.callArciseServices(keytoremove.replace("sessionRemove","")));
						externalMap.remove(keytoremove);
						questionAswerMap.remove(keytoremove);
						response.remove(keytoremove);
						externalMap.remove(keytoremove+"Msg");
					}
					break;
				}
			}
			
		}
		}catch(Exception e)
		{
			logger.error("creating exception while going to session time out "+e);
			
		}
		logger.info("End cashRemovetimeout ..");
	}
	
	private void callArciseApiWhileSessionTimeOut(String callArciseServices)
	{
		logger.info("start callArciseApiWhileSessionTimeOut .. ");
		
		logger.info("Session Id for pushing Data in to Arcis Api through Sechedular "+callArciseServices);
		try 
		{
		 needAnalysisService.callArciseServices(callArciseServices);
		
		}catch(Exception e)
		{
		logger.error("creating exception in callArciseApiWhileSessionTimeOut "+e);	
		}
		logger.info("End callArciseApiWhileSessionTimeOut .. ");
	}

	private void setTokenInCachse(Map<String,String> tokenCache) 
	{
		logger.info("start setTokenInCachse .. ");
		try
		{
			
		String token=needAnalysisService.getArciseToken();
		
		
	    tokenCache.put("token",token);
	    logger.info("End setTokenInCachse .. ");
		}catch(Exception e) 
		{
		logger.error("creating exception in Session Time Out while getting token.."+e);	
		}
	}
}
