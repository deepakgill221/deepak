package com.csg.calculator;

import java.util.Map;

public interface ChildEducation 
{
	public String childEducation(Map<String,Map<String,String>> questionAswerMap, String sessionId);
}
