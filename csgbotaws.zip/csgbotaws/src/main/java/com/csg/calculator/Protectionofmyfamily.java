package com.csg.calculator;

import java.util.Map;

public interface Protectionofmyfamily 
{
	public String protectionOfMyFamily(Map<String,Map<String,String>> questionAswerMap, String sessionId);
}
