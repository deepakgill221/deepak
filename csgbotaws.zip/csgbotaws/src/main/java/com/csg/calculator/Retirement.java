package com.csg.calculator;

import java.util.Map;

public interface Retirement
{
	public String retirement(Map<String,Map<String,String>> questionAswerMap, String sessionId);
}
