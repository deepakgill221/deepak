package com.csg.calculator;

import java.util.Map;

public interface ChildMarriage 
{
	public String childMarriage(Map<String,Map<String,String>> questionAswerMap, String sessionId);
}
