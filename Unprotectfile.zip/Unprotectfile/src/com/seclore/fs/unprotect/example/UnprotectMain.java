package com.seclore.fs.unprotect.example;

import java.io.File;
import java.util.Scanner;

import com.seclore.fs.helper.library.FSHelperLibrary;
import com.seclore.fs.unprotect.example.config.InitializeWSClient;

public class UnprotectMain 
{
	static
	{
		try
		{
			// This Seclore Library specific configuration
			//In case of web application it can be initialize within Context Listener on application startup
			//InitializeWSClient.initialize("config"+File.separator+"config.xml");
			InitializeWSClient.initialize("config/config.xml");
			FSHelperLibrary.getPSConnection();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args)
	{
		Scanner scanner = null; 
		try
		{
//			scanner = new Scanner(System.in);
			
			System.out.println("Enter absolute path of the file to be unprotected:");
			//String filePath = scanner.nextLine();
//			String filePath = "C:\\Users\\ad01084\\Desktop\\Daksh SIC\\Seclored_TrialBalance_Report2018-02-09-10-30-21.xls";
			String filePath = "C:/Users/ad01084/Desktop/Daksh SIC/Seclored_TrialBalance_Report2018-02-09-10-30-21.xls";
//			File destinationFileForSummary= new File(filePath);
//			if(destinationFileForSummary.exists()){
//				System.out.println("find");
//			}
			
			unprotectDocument( filePath );
			System.out.println("File has unprotected successfully");
					
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
		}
		finally
		{
			if( scanner != null )
			{
				scanner.close();
			}
		}
	}
	
	public static void unprotectDocument( String filePath ) throws Exception
	{
		if( !FSHelperLibrary.isSupportedFile(filePath) )
		{
			String fileExt = filePath.substring( filePath.lastIndexOf(".")+1 );
			throw new Exception("File with extention '"+fileExt+"' is not supported by selcore FS Helper Library");
		}
		
		if( !FSHelperLibrary.isProtectedFile(filePath) )
		{
			throw new Exception("File '"+filePath+"' is not seclore protected");
		}

		// create the request xml
		String actvityComments = "Unprotected by <Application Name> using Seclore FS Helper Library";
		String pDispFileName = "Seclored_TrialBalance_Report_Unprotected.xls";
		
		FSHelperLibrary.unprotectX( null, filePath, pDispFileName, actvityComments );
	}
}
