package com.seclore.fs.unprotect.example.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config 
{
	private static Properties props = null;
	//private static String 
	public static void initConfig(String confiPath)
	{
		InputStream lInputStream = null;
		try
    	{
    		Properties lProps = new Properties();       
    		lInputStream = new FileInputStream(confiPath);
        	lProps.load(lInputStream);
        	props = lProps;	
    	}
    	catch(Exception lEx)
    	{
    		lEx.printStackTrace();
    	}
		finally
		{
			if( lInputStream != null)
			{
				try
				{
					lInputStream.close();
				}
				catch(IOException ioException)
				{
					// Ignore
				}
			}
		}
	}
	
	public static String getProperty(String key, String defaultValue)
	{
		return props.getProperty(key, defaultValue);
	}
	
	public static String getHotFolderId()
	{
		return getProperty("com.seclore.hotfolder.id", "");
	}
}
